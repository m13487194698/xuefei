
FizzleDB = {
	["namespaces"] = {
		["Inspect"] = {
		},
	},
	["profileKeys"] = {
		["三聚氰胺 - 安娜丝塔丽"] = "三聚氰胺 - 安娜丝塔丽",
	},
	["profiles"] = {
		["三聚氰胺 - 安娜丝塔丽"] = {
		},
	},
}
