
orbSellAndRepair_settings = {
	["VendorWhites"] = true,
	["ReputationRepairLimit"] = 4,
	["AutoRepair"] = true,
	["UseGuildRepair"] = false,
	["VendorGreys"] = true,
}
