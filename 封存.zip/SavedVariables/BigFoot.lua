
BF_Frames_Config = {
}
BigFoot_Character = {
	["Region"] = "cn0",
	["Gender"] = 2,
	["Race"] = "人类",
	["Name"] = "三聚氰胺",
	["Faction"] = 0,
	["Class"] = "牧师",
	["Level"] = 28,
	["VCode"] = "11592103024290293890904146075303191746",
	["Realm"] = "安娜丝塔丽",
}
BigFoot_SysTemSetTab = {
	["DoEmote_stand"] = true,
	["SpellActivations"] = true,
	["Dismount"] = true,
	["BigFoot_LoadBefore"] = 1,
	["UtilsPatchVersion"] = "2020-03-26",
}
