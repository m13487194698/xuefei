
Heart_Config = nil
Heart_SavedProfiles = nil
