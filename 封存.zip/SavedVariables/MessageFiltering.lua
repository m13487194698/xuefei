
HuaJieInit = {
	["a"] = 1,
	["colorstr"] = "ffff0007",
	["b"] = 0.0274509803921569,
	["yellck"] = false,
	["g"] = 0,
	["friend"] = "",
	["sayck"] = false,
	["r"] = 1,
	["key"] = false,
	["Filter"] = "",
	["ShowFilter"] = "stsm||STSM",
	["mode"] = false,
	["wsck"] = false,
	["djck"] = true,
}
