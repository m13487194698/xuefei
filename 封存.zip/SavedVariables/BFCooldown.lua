
BFCooldownDB = {
	["BUFF"] = {
		["config"] = true,
		["hidecooldown"] = false,
		["font"] = "Fonts\\ARKai_T.ttf",
		["max"] = 0,
		["point"] = "CENTER",
		["alpha"] = 0.8,
		["size"] = 30,
	},
	["ACTION"] = {
		["hidecooldown"] = false,
		["scale"] = 4,
		["special"] = false,
		["alpha"] = 0.8,
		["min"] = 2.99,
		["config"] = true,
		["style"] = -1,
		["shine"] = true,
		["font"] = "Fonts\\ARKai_T.ttf",
		["size"] = 35,
	},
	["short"] = {
		["r"] = 1,
		["g"] = 0.1,
		["s"] = 1.2,
		["b"] = 0.1,
	},
	["spellCache"] = {
		["精神鞭笞"] = {
			36, -- [1]
			"spell", -- [2]
		},
		["心灵震爆"] = {
			26, -- [1]
			"spell", -- [2]
		},
		["神圣之火"] = {
			57, -- [1]
			"spell", -- [2]
		},
		["暗言术：痛"] = {
			30, -- [1]
			"spell", -- [2]
		},
		["回馈"] = {
			9, -- [1]
			"spell", -- [2]
		},
		["真言术：盾"] = {
			14, -- [1]
			"spell", -- [2]
		},
		["恢复"] = {
			42, -- [1]
			"spell", -- [2]
		},
		["心灵尖啸"] = {
			23, -- [1]
			"spell", -- [2]
		},
		["射击"] = {
			4, -- [1]
			"spell", -- [2]
		},
		["祛病术"] = {
			56, -- [1]
			"spell", -- [2]
		},
		["真言术：韧"] = {
			18, -- [1]
			"spell", -- [2]
		},
	},
	["isChangeFont"] = true,
	["secs"] = {
		["r"] = 1,
		["g"] = 0.8,
		["s"] = 0.9,
		["b"] = 0,
	},
	["center"] = {
		["r"] = 0,
		["b"] = 1,
		["text"] = true,
		["alpha"] = 0.65,
		["width"] = 67,
		["config"] = false,
		["font"] = "Fonts\\ARKai_T.ttf",
		["time"] = 1.2,
		["position"] = {
			["y"] = 78,
			["p"] = "CENTER",
			["x"] = -52,
			["r"] = "CENTER",
		},
		["g"] = 1,
		["mode"] = true,
		["style"] = 1,
		["size"] = 30,
	},
	["mins"] = {
		["r"] = 0.8,
		["g"] = 0.6,
		["s"] = 0.7,
		["b"] = 0,
	},
	["hrs"] = {
		["r"] = 0.6,
		["g"] = 0.4,
		["s"] = 0.6,
		["b"] = 0,
	},
	["days"] = {
		["r"] = 0.4,
		["g"] = 0.4,
		["s"] = 0.6,
		["b"] = 0.4,
	},
	["bar"] = false,
}
