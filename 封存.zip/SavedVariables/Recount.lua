
RecountPerCharDB = {
	["version"] = "1.3",
	["combatants"] = {
		["蜂花护发素"] = {
			["GUID"] = "Player-4829-0163CCA0",
			["LastEventHealth"] = {
				3081, -- [1]
				3081, -- [2]
				3081, -- [3]
				3081, -- [4]
				3081, -- [5]
				3081, -- [6]
				3081, -- [7]
				3081, -- [8]
				3081, -- [9]
				3081, -- [10]
				3081, -- [11]
				3081, -- [12]
				3081, -- [13]
				3081, -- [14]
				3081, -- [15]
				3081, -- [16]
				3081, -- [17]
				3081, -- [18]
				3081, -- [19]
				3081, -- [20]
				3081, -- [21]
				3081, -- [22]
				3081, -- [23]
				3081, -- [24]
				3081, -- [25]
				3081, -- [26]
				3081, -- [27]
				3081, -- [28]
				3081, -- [29]
				3081, -- [30]
				3081, -- [31]
				3081, -- [32]
				3081, -- [33]
				3081, -- [34]
				3081, -- [35]
				3081, -- [36]
				3081, -- [37]
				3081, -- [38]
				3081, -- [39]
				3081, -- [40]
				3081, -- [41]
				3081, -- [42]
				3081, -- [43]
				3081, -- [44]
				3081, -- [45]
				3081, -- [46]
				3081, -- [47]
				3081, -- [48]
				3081, -- [49]
				3081, -- [50]
			},
			["LastAttackedBy"] = "骷髅守护者",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["TimeHeal"] = {
					30.57, -- [1]
				},
				["DamageTaken"] = {
					8457, -- [1]
				},
				["Absorbs"] = {
					5119, -- [1]
				},
				["HealingTaken"] = {
					5146, -- [1]
				},
				["TimeDamage"] = {
					294.32, -- [1]
				},
				["ActiveTime"] = {
					324.89, -- [1]
				},
				["ManaGain"] = {
					4729, -- [1]
				},
				["DOT_Time"] = {
					12147, -- [1]
				},
				["Damage"] = {
					771955, -- [1]
				},
			},
			["enClass"] = "MAGE",
			["unit"] = "蜂花护发素",
			["level"] = 60,
			["LastDamageAbility"] = "暗影箭",
			["LastFightIn"] = 12,
			["LastHealTime"] = 51172.132,
			["type"] = "Grouped",
			["FightsSaved"] = 5,
			["LastDamageTaken"] = 74,
			["TimeLast"] = {
				["TimeHeal"] = 51171.213,
				["OVERALL"] = 51205.212,
				["DamageTaken"] = 51171.213,
				["Absorbs"] = 51171.213,
				["HealingTaken"] = 51171.213,
				["TimeDamage"] = 51205.212,
				["ActiveTime"] = 51205.212,
				["ManaGain"] = 51168.215,
				["DOT_Time"] = 51205.212,
				["Damage"] = 51205.212,
			},
			["Owner"] = false,
			["LastEventHealthMax"] = {
				3500, -- [1]
				3500, -- [2]
				3500, -- [3]
				3500, -- [4]
				3500, -- [5]
				3500, -- [6]
				3500, -- [7]
				3500, -- [8]
				3500, -- [9]
				3500, -- [10]
				3500, -- [11]
				3500, -- [12]
				3500, -- [13]
				3500, -- [14]
				3500, -- [15]
				3500, -- [16]
				3500, -- [17]
				3500, -- [18]
				3500, -- [19]
				3500, -- [20]
				3500, -- [21]
				3500, -- [22]
				3500, -- [23]
				3500, -- [24]
				3500, -- [25]
				3500, -- [26]
				3500, -- [27]
				3500, -- [28]
				3500, -- [29]
				3500, -- [30]
				3500, -- [31]
				3500, -- [32]
				3500, -- [33]
				3500, -- [34]
				3500, -- [35]
				3500, -- [36]
				3500, -- [37]
				3500, -- [38]
				3500, -- [39]
				3500, -- [40]
				3500, -- [41]
				3500, -- [42]
				3500, -- [43]
				3500, -- [44]
				3500, -- [45]
				3500, -- [46]
				3500, -- [47]
				3500, -- [48]
				3500, -- [49]
				3500, -- [50]
			},
			["NextEventNum"] = 17,
			["LastDamageTime"] = 51205.714,
			["LastEvents"] = {
				"蜂花护发素 暴风雪 (伤害/跳) 被撕裂的死尸 Tick -176 (Frost)", -- [1]
				"蜂花护发素 暴风雪 (伤害/跳) 被毁坏的死尸 Tick -176 (Frost)", -- [2]
				"蜂花护发素 暴风雪 (伤害/跳) 被毁坏的死尸 Tick -176 (Frost)", -- [3]
				"蜂花护发素 暴风雪 (伤害/跳) 被撕裂的死尸 Tick -176 (Frost)", -- [4]
				"蜂花护发素 暴风雪 (伤害/跳) 恶疫食尸鬼 Tick -176 (Frost)", -- [5]
				"蜂花护发素 暴风雪 (伤害/跳) 恶疫食尸鬼 Tick -176 (Frost)", -- [6]
				"蜂花护发素 暴风雪 (伤害/跳) 被撕裂的死尸 Tick -176 (Frost)", -- [7]
				"蜂花护发素 暴风雪 (伤害/跳) 恶疫食尸鬼 Tick -175 (Frost)", -- [8]
				"蜂花护发素 暴风雪 (伤害/跳) 恶疫食尸鬼 Tick -176 (Frost)", -- [9]
				"蜂花护发素 暴风雪 (伤害/跳) 被毁坏的死尸 Tick -176 (Frost)", -- [10]
				"蜂花护发素 暴风雪 (伤害/跳) 恶疫食尸鬼 Tick -176 (Frost)", -- [11]
				"蜂花护发素 暴风雪 (伤害/跳) 破碎的死尸 Tick -175 (Frost)", -- [12]
				"蜂花护发素 暴风雪 (伤害/跳) 破碎的死尸 Tick -176 (Frost)", -- [13]
				"蜂花护发素 暴风雪 (伤害/跳) 恶疫食尸鬼 Tick -176 (Frost)", -- [14]
				"蜂花护发素 暴风雪 (伤害/跳) 恶疫食尸鬼 Tick -176 (Frost)", -- [15]
				"蜂花护发素 暴风雪 (伤害/跳) 破碎的死尸 Tick -176 (Frost)", -- [16]
				"蜂花护发素 暴风雪 (伤害/跳) 被毁坏的死尸 Tick -176 (Frost)", -- [17]
				"蜂花护发素 暴风雪 (伤害/跳) 被撕裂的死尸 Tick -176 (Frost)", -- [18]
				"蜂花护发素 暴风雪 (伤害/跳) 被撕裂的死尸 Tick -176 (Frost)", -- [19]
				"蜂花护发素 暴风雪 (伤害/跳) 被撕裂的死尸 Tick -176 (Frost)", -- [20]
				"蜂花护发素 暴风雪 (伤害/跳) 被撕裂的死尸 Tick -176 (Frost)", -- [21]
				"蜂花护发素 暴风雪 (伤害/跳) 被撕裂的死尸 Tick -176 (Frost)", -- [22]
				"蜂花护发素 暴风雪 (伤害/跳) 被毁坏的死尸 Tick -176 (Frost)", -- [23]
				"蜂花护发素 暴风雪 (伤害/跳) 被毁坏的死尸 Tick -176 (Frost)", -- [24]
				"蜂花护发素 暴风雪 (伤害/跳) 被毁坏的死尸 Tick -176 (Frost)", -- [25]
				"蜂花护发素 暴风雪 (伤害/跳) 恶疫食尸鬼 Tick -176 (Frost)", -- [26]
				"蜂花护发素 暴风雪 (伤害/跳) 恶疫食尸鬼 Tick -176 (Frost)", -- [27]
				"蜂花护发素 暴风雪 (伤害/跳) 恶疫食尸鬼 Tick -176 (Frost)", -- [28]
				"蜂花护发素 暴风雪 (伤害/跳) 被撕裂的死尸 Tick -176 (Frost)", -- [29]
				"蜂花护发素 暴风雪 (伤害/跳) 恶疫食尸鬼 Tick -176 (Frost)", -- [30]
				"蜂花护发素 暴风雪 (伤害/跳) 恶疫食尸鬼 Tick -176 (Frost)", -- [31]
				"蜂花护发素 暴风雪 (伤害/跳) 破碎的死尸 Tick -176 (Frost)", -- [32]
				"蜂花护发素 暴风雪 (伤害/跳) 破碎的死尸 Tick -176 (Frost)", -- [33]
				"蜂花护发素 暴风雪 (伤害/跳) 被毁坏的死尸 Tick -176 (Frost)", -- [34]
				"蜂花护发素 暴风雪 (伤害/跳) 被毁坏的死尸 Tick -176 (Frost)", -- [35]
				"蜂花护发素 暴风雪 (伤害/跳) 被毁坏的死尸 Tick -176 (Frost)", -- [36]
				"蜂花护发素 暴风雪 (伤害/跳) 被撕裂的死尸 Tick -176 (Frost)", -- [37]
				"蜂花护发素 暴风雪 (伤害/跳) 被撕裂的死尸 Tick -175 (Frost)", -- [38]
				"蜂花护发素 暴风雪 (伤害/跳) 被撕裂的死尸 Tick -176 (Frost)", -- [39]
				"蜂花护发素 暴风雪 (伤害/跳) 被撕裂的死尸 Tick -176 (Frost)", -- [40]
				"蜂花护发素 暴风雪 (伤害/跳) 恶疫食尸鬼 Tick -175 (Frost)", -- [41]
				"蜂花护发素 暴风雪 (伤害/跳) 被撕裂的死尸 Tick -176 (Frost)", -- [42]
				"蜂花护发素 暴风雪 (伤害/跳) 恶疫食尸鬼 Tick -176 (Frost)", -- [43]
				"蜂花护发素 暴风雪 (伤害/跳) 恶疫食尸鬼 Tick -176 (Frost)", -- [44]
				"蜂花护发素 暴风雪 (伤害/跳) 恶疫食尸鬼 Tick -176 (Frost)", -- [45]
				"蜂花护发素 暴风雪 (伤害/跳) 破碎的死尸 Tick -176 (Frost)", -- [46]
				"蜂花护发素 暴风雪 (伤害/跳) 破碎的死尸 Tick -176 (Frost)", -- [47]
				"蜂花护发素 暴风雪 (伤害/跳) 破碎的死尸 Tick -176 (Frost)", -- [48]
				"蜂花护发素 暴风雪 (伤害/跳) 被毁坏的死尸 Tick -175 (Frost)", -- [49]
				"蜂花护发素 暴风雪 (伤害/跳) 被撕裂的死尸 Tick -176 (Frost)", -- [50]
			},
			["Name"] = "蜂花护发素",
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				false, -- [6]
				false, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				false, -- [11]
				false, -- [12]
				false, -- [13]
				false, -- [14]
				false, -- [15]
				false, -- [16]
				false, -- [17]
				false, -- [18]
				false, -- [19]
				false, -- [20]
				false, -- [21]
				false, -- [22]
				false, -- [23]
				false, -- [24]
				false, -- [25]
				false, -- [26]
				false, -- [27]
				false, -- [28]
				false, -- [29]
				false, -- [30]
				false, -- [31]
				false, -- [32]
				false, -- [33]
				false, -- [34]
				false, -- [35]
				false, -- [36]
				false, -- [37]
				false, -- [38]
				false, -- [39]
				false, -- [40]
				false, -- [41]
				false, -- [42]
				false, -- [43]
				false, -- [44]
				false, -- [45]
				false, -- [46]
				false, -- [47]
				false, -- [48]
				false, -- [49]
				false, -- [50]
			},
			["LastEventTimes"] = {
				51202.63, -- [1]
				51202.647, -- [2]
				51202.647, -- [3]
				51202.647, -- [4]
				51202.647, -- [5]
				51202.647, -- [6]
				51202.647, -- [7]
				51202.647, -- [8]
				51202.647, -- [9]
				51203.647, -- [10]
				51203.647, -- [11]
				51204.497, -- [12]
				51204.497, -- [13]
				51204.646, -- [14]
				51205.646, -- [15]
				51205.714, -- [16]
				51200.629, -- [17]
				51200.629, -- [18]
				51200.629, -- [19]
				51200.629, -- [20]
				51200.629, -- [21]
				51200.629, -- [22]
				51200.629, -- [23]
				51200.629, -- [24]
				51200.629, -- [25]
				51200.629, -- [26]
				51200.629, -- [27]
				51200.629, -- [28]
				51200.629, -- [29]
				51200.629, -- [30]
				51200.629, -- [31]
				51200.863, -- [32]
				51200.863, -- [33]
				51201.63, -- [34]
				51201.63, -- [35]
				51201.63, -- [36]
				51201.63, -- [37]
				51201.63, -- [38]
				51201.63, -- [39]
				51201.63, -- [40]
				51201.63, -- [41]
				51201.63, -- [42]
				51201.63, -- [43]
				51201.63, -- [44]
				51201.63, -- [45]
				51201.863, -- [46]
				51201.863, -- [47]
				51202.081, -- [48]
				51202.63, -- [49]
				51202.63, -- [50]
			},
			["Fights"] = {
				["Fight3"] = {
					["Absorbed"] = {
						["寒冰护体"] = {
							["Details"] = {
								["蜂花护发素"] = {
									["max"] = 411,
									["min"] = 61,
									["count"] = 4,
									["amount"] = 723,
								},
							},
							["count"] = 4,
							["amount"] = 723,
						},
					},
					["DOTs"] = {
						["暴风雪 (伤害/跳)"] = {
							["Details"] = {
								["被撕裂的死尸"] = {
									["count"] = 225,
								},
								["恶疫食尸鬼"] = {
									["count"] = 171,
								},
								["缝补憎恶"] = {
									["count"] = 51,
								},
								["被毁坏的死尸"] = {
									["count"] = 261,
								},
								["破碎的死尸"] = {
									["count"] = 30,
								},
								["骷髅守护者"] = {
									["count"] = 6,
								},
							},
							["amount"] = 744,
						},
					},
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Shadow"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
						["Frost"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 1429,
					["RageGainedFrom"] = {
					},
					["Absorbs"] = 723,
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
						["Frost"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 6,
								},
								["Crit"] = {
									["count"] = 1,
								},
								["Tick"] = {
									["count"] = 248,
								},
							},
							["amount"] = 255,
						},
					},
					["ElementTakenAbsorb"] = {
						["Physical"] = 61,
						["Shadow"] = 158,
						["Melee"] = 411,
						["Frost"] = 93,
					},
					["ElementTaken"] = {
						["Physical"] = 706,
						["Shadow"] = 158,
						["Melee"] = 472,
						["Frost"] = 93,
					},
					["DOT_Time"] = 744,
					["Damage"] = 48344,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 5.07,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Fire"] = 1258,
						["Frost"] = 47086,
					},
					["PartialAbsorb"] = {
						["击退"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 61,
									["min"] = 61,
									["count"] = 1,
									["amount"] = 61,
								},
							},
							["count"] = 1,
							["amount"] = 61,
						},
						["寒冰箭"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 93,
									["min"] = 93,
									["count"] = 1,
									["amount"] = 93,
								},
							},
							["count"] = 1,
							["amount"] = 93,
						},
						["暗影箭"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 158,
									["min"] = 158,
									["count"] = 1,
									["amount"] = 158,
								},
							},
							["count"] = 1,
							["amount"] = 158,
						},
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
								["被吸收"] = {
									["max"] = 411,
									["min"] = 411,
									["count"] = 1,
									["amount"] = 411,
								},
							},
							["count"] = 2,
							["amount"] = 411,
						},
					},
					["DamagedWho"] = {
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 13194,
								},
							},
							["amount"] = 13194,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 10025,
								},
								["冰霜新星"] = {
									["count"] = 66,
								},
							},
							["amount"] = 10091,
						},
						["缝补憎恶"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 2988,
								},
								["寒冰箭"] = {
									["count"] = 3330,
								},
								["冰霜新星"] = {
									["count"] = 32,
								},
								["火焰冲击"] = {
									["count"] = 1258,
								},
							},
							["amount"] = 7608,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 15308,
								},
								["冰霜新星"] = {
									["count"] = 31,
								},
							},
							["amount"] = 15339,
						},
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 1760,
								},
							},
							["amount"] = 1760,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 352,
								},
							},
							["amount"] = 352,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["缝补憎恶"] = {
							["Details"] = {
								["击退"] = {
									["count"] = 706,
								},
								["肉搏"] = {
									["count"] = 61,
								},
							},
							["amount"] = 767,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 411,
								},
							},
							["amount"] = 411,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暗影箭"] = {
									["count"] = 158,
								},
								["寒冰箭"] = {
									["count"] = 93,
								},
							},
							["amount"] = 251,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["击退"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
						["寒冰箭"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
						["暗影箭"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 2,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["蜂花护发素"] = {
							["Details"] = {
								["寒冰护体"] = {
									["count"] = 5.07,
								},
							},
							["amount"] = 5.07,
						},
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["蜂花护发素"] = {
							["Details"] = {
								["寒冰护体"] = {
									["count"] = 723,
								},
							},
							["amount"] = 723,
						},
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 6.15,
								},
							},
							["amount"] = 6.15,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 6.79,
								},
							},
							["amount"] = 6.79,
						},
						["蜂花护发素"] = {
							["Details"] = {
								["寒冰护体"] = {
									["count"] = 5.07,
								},
							},
							["amount"] = 5.07,
						},
						["缝补憎恶"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 4.79,
								},
								["寒冰箭"] = {
									["count"] = 4.53,
								},
								["冰霜新星"] = {
									["count"] = 1.5,
								},
								["火焰冲击"] = {
									["count"] = 3,
								},
							},
							["amount"] = 13.82,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 5.06,
								},
								["冰霜新星"] = {
									["count"] = 0.43,
								},
							},
							["amount"] = 5.49,
						},
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 1.43,
								},
							},
							["amount"] = 1.43,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 1.92,
								},
							},
							["amount"] = 1.92,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["寒冰护体"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 411,
									["min"] = 61,
									["count"] = 4,
									["amount"] = 723,
								},
							},
							["count"] = 4,
							["amount"] = 723,
						},
					},
					["WhoHealed"] = {
						["蜂花护发素"] = {
							["Details"] = {
								["寒冰护体"] = {
									["count"] = 723,
								},
							},
							["amount"] = 723,
						},
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 40.67,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["暴风雪 (伤害/跳)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 176,
									["min"] = 175,
									["count"] = 248,
									["amount"] = 43627,
								},
							},
							["count"] = 248,
							["amount"] = 43627,
						},
						["寒冰箭"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 848,
									["min"] = 818,
									["count"] = 4,
									["amount"] = 3330,
								},
							},
							["count"] = 4,
							["amount"] = 3330,
						},
						["火焰冲击"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 639,
									["min"] = 619,
									["count"] = 2,
									["amount"] = 1258,
								},
							},
							["count"] = 2,
							["amount"] = 1258,
						},
						["冰霜新星"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 66,
									["min"] = 66,
									["count"] = 1,
									["amount"] = 66,
								},
								["Hit"] = {
									["max"] = 32,
									["min"] = 31,
									["count"] = 2,
									["amount"] = 63,
								},
							},
							["count"] = 3,
							["amount"] = 129,
						},
					},
					["HealingTaken"] = 723,
					["RageGain"] = 0,
					["TimeDamage"] = 35.6,
					["TimeDamaging"] = {
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 6.15,
								},
							},
							["amount"] = 6.15,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 6.79,
								},
							},
							["amount"] = 6.79,
						},
						["缝补憎恶"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 4.79,
								},
								["寒冰箭"] = {
									["count"] = 4.53,
								},
								["冰霜新星"] = {
									["count"] = 1.5,
								},
								["火焰冲击"] = {
									["count"] = 3,
								},
							},
							["amount"] = 13.82,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 5.06,
								},
								["冰霜新星"] = {
									["count"] = 0.43,
								},
							},
							["amount"] = 5.49,
						},
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 1.43,
								},
							},
							["amount"] = 1.43,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 1.92,
								},
							},
							["amount"] = 1.92,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight5"] = {
					["Absorbed"] = {
						["寒冰护体"] = {
							["Details"] = {
								["蜂花护发素"] = {
									["max"] = 113,
									["min"] = 113,
									["count"] = 1,
									["amount"] = 113,
								},
							},
							["count"] = 1,
							["amount"] = 113,
						},
					},
					["DOTs"] = {
						["暴风雪 (伤害/跳)"] = {
							["Details"] = {
								["骷髅狂战士"] = {
									["count"] = 0,
								},
								["被撕裂的死尸"] = {
									["count"] = 0,
								},
								["恶疫食尸鬼"] = {
									["count"] = 0,
								},
								["缝补憎恶"] = {
									["count"] = 0,
								},
								["被毁坏的死尸"] = {
									["count"] = 0,
								},
								["骷髅守护者"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementHitsTaken"] = {
						["Frost"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 113,
					["RageGainedFrom"] = {
					},
					["Absorbs"] = 113,
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementTakenAbsorb"] = {
						["Frost"] = 113,
					},
					["ElementTaken"] = {
						["Frost"] = 113,
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 1.5,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Frost"] = 0,
					},
					["PartialAbsorb"] = {
						["寒冰箭"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 113,
									["min"] = 113,
									["count"] = 1,
									["amount"] = 113,
								},
							},
							["count"] = 1,
							["amount"] = 113,
						},
					},
					["DamagedWho"] = {
						["骷髅狂战士"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["缝补憎恶"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["骷髅守护者"] = {
							["Details"] = {
								["寒冰箭"] = {
									["count"] = 113,
								},
							},
							["amount"] = 113,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["寒冰箭"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["蜂花护发素"] = {
							["Details"] = {
								["寒冰护体"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
						["蜂花护发素"] = {
							["Details"] = {
								["魔法吸收"] = {
									["count"] = 361,
								},
							},
							["amount"] = 361,
						},
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["蜂花护发素"] = {
							["Details"] = {
								["寒冰护体"] = {
									["count"] = 113,
								},
							},
							["amount"] = 113,
						},
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
						["魔法吸收"] = {
							["Details"] = {
								["蜂花护发素"] = {
									["count"] = 361,
								},
							},
							["amount"] = 361,
						},
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["骷髅狂战士"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["蜂花护发素"] = {
							["Details"] = {
								["寒冰护体"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["寒冰护体"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 113,
									["min"] = 113,
									["count"] = 1,
									["amount"] = 113,
								},
							},
							["count"] = 1,
							["amount"] = 113,
						},
					},
					["WhoHealed"] = {
						["蜂花护发素"] = {
							["Details"] = {
								["寒冰护体"] = {
									["count"] = 113,
								},
							},
							["amount"] = 113,
						},
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 1.5,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["暴风雪 (伤害/跳)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 113,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["骷髅狂战士"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 361,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["Absorbed"] = {
						["寒冰护体"] = {
							["Details"] = {
								["蜂花护发素"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["防护冰霜结界"] = {
							["Details"] = {
								["蜂花护发素"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["DOTs"] = {
						["暴风雪 (伤害/跳)"] = {
							["Details"] = {
								["骷髅狂战士"] = {
									["count"] = 0,
								},
								["被撕裂的死尸"] = {
									["count"] = 0,
								},
								["恶疫食尸鬼"] = {
									["count"] = 0,
								},
								["幽灵市民"] = {
									["count"] = 0,
								},
								["缝补憎恶"] = {
									["count"] = 0,
								},
								["被毁坏的死尸"] = {
									["count"] = 0,
								},
								["破碎的死尸"] = {
									["count"] = 0,
								},
								["骷髅守护者"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementHitsTaken"] = {
						["Frost"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 0,
								},
								["Absorb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
								["Absorb"] = {
									["count"] = 0,
								},
								["Immune"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Arcane"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 0,
								},
								["Absorb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Shadow"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 0,
								},
								["Immune"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Nature"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementDoneResist"] = {
						["Frost"] = 0,
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["Absorbs"] = 0,
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Frost"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Tick"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementTakenAbsorb"] = {
						["Physical"] = 0,
						["Frost"] = 0,
						["Melee"] = 0,
						["Arcane"] = 0,
					},
					["ElementTaken"] = {
						["Physical"] = 0,
						["Frost"] = 0,
						["Melee"] = 0,
						["Arcane"] = 0,
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Fire"] = 0,
						["Frost"] = 0,
					},
					["PartialAbsorb"] = {
						["奥术箭"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["暗影箭"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["疾病之云"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["击退"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["寒冰箭"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["骷髅狂战士"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
								["冰锥术"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
								["冰锥术"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["冰锥术"] = {
									["count"] = 0,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["幽灵市民"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["缝补憎恶"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
								["寒冰箭"] = {
									["count"] = 0,
								},
								["火焰冲击"] = {
									["count"] = 0,
								},
								["冰锥术"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
								["冰锥术"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["骷髅狂战士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["缝补憎恶"] = {
							["Details"] = {
								["击退"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["幽灵市民"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["奥术箭"] = {
									["count"] = 0,
								},
								["寒冰箭"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["奥术箭"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["暗影箭"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["疾病之云"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["击退"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["寒冰箭"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["蜂花护发素"] = {
							["Details"] = {
								["寒冰护体"] = {
									["count"] = 0,
								},
								["防护冰霜结界"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
						["蜂花护发素"] = {
							["Details"] = {
								["魔法吸收"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["蜂花护发素"] = {
							["Details"] = {
								["寒冰护体"] = {
									["count"] = 0,
								},
								["防护冰霜结界"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
						["魔法吸收"] = {
							["Details"] = {
								["蜂花护发素"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["骷髅狂战士"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["冰锥术"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["冰锥术"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["冰锥术"] = {
									["count"] = 0,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["蜂花护发素"] = {
							["Details"] = {
								["寒冰护体"] = {
									["count"] = 0,
								},
								["防护冰霜结界"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["缝补憎恶"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
								["寒冰箭"] = {
									["count"] = 0,
								},
								["火焰冲击"] = {
									["count"] = 0,
								},
								["冰锥术"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["寒冰护体"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["防护冰霜结界"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["WhoHealed"] = {
						["蜂花护发素"] = {
							["Details"] = {
								["寒冰护体"] = {
									["count"] = 0,
								},
								["防护冰霜结界"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["暴风雪 (伤害/跳)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["冰霜新星"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["寒冰箭"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["火焰冲击"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["冰锥术"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["骷髅狂战士"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["冰锥术"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["冰锥术"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["冰锥术"] = {
									["count"] = 0,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["缝补憎恶"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
								["寒冰箭"] = {
									["count"] = 0,
								},
								["火焰冲击"] = {
									["count"] = 0,
								},
								["冰锥术"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight2"] = {
					["Absorbed"] = {
						["防护冰霜结界"] = {
							["Details"] = {
								["蜂花护发素"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["寒冰护体"] = {
							["Details"] = {
								["蜂花护发素"] = {
									["max"] = 866,
									["min"] = 866,
									["count"] = 1,
									["amount"] = 866,
								},
							},
							["count"] = 1,
							["amount"] = 866,
						},
					},
					["DOTs"] = {
						["暴风雪 (伤害/跳)"] = {
							["Details"] = {
								["被撕裂的死尸"] = {
									["count"] = 3,
								},
								["恶疫食尸鬼"] = {
									["count"] = 0,
								},
								["破碎的死尸"] = {
									["count"] = 6,
								},
								["缝补憎恶"] = {
									["count"] = 3,
								},
								["被毁坏的死尸"] = {
									["count"] = 3,
								},
								["鬼魂市民"] = {
									["count"] = 0,
								},
								["骷髅守护者"] = {
									["count"] = 0,
								},
							},
							["amount"] = 15,
						},
					},
					["ElementHitsTaken"] = {
						["Frost"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Arcane"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Shadow"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementDoneResist"] = {
						["Frost"] = 0,
					},
					["Ressed"] = 0,
					["DamageTaken"] = 899,
					["RageGainedFrom"] = {
					},
					["Absorbs"] = 866,
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
						["Frost"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 4,
								},
								["Crit"] = {
									["count"] = 1,
								},
								["Tick"] = {
									["count"] = 5,
								},
							},
							["amount"] = 10,
						},
					},
					["ElementTakenAbsorb"] = {
						["Physical"] = 866,
						["Frost"] = 0,
					},
					["ElementTaken"] = {
						["Frost"] = 0,
						["Melee"] = 866,
						["Arcane"] = 0,
						["Physical"] = 33,
						["Shadow"] = 0,
					},
					["DOT_Time"] = 15,
					["Damage"] = 6348,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 1.5,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
						["Shadow"] = 0,
						["Arcane"] = 0,
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Fire"] = 1264,
						["Frost"] = 5084,
					},
					["PartialAbsorb"] = {
						["奥术箭"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["暗影箭"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["衰弱之触"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["寒冰箭"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["击退"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 866,
									["min"] = 866,
									["count"] = 1,
									["amount"] = 866,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 866,
						},
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 176,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
							},
							["amount"] = 176,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 352,
								},
							},
							["amount"] = 352,
						},
						["缝补憎恶"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 176,
								},
								["寒冰箭"] = {
									["count"] = 4174,
								},
								["火焰冲击"] = {
									["count"] = 1264,
								},
								["冰霜新星"] = {
									["count"] = 30,
								},
							},
							["amount"] = 5644,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 176,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
							},
							["amount"] = 176,
						},
						["鬼魂市民"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["寒冰箭"] = {
									["count"] = 0,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["缝补憎恶"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 866,
								},
								["击退"] = {
									["count"] = 33,
								},
							},
							["amount"] = 899,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["奥术箭"] = {
									["count"] = 0,
								},
								["寒冰箭"] = {
									["count"] = 0,
								},
								["暗影箭"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["奥术箭"] = {
							["Details"] = {
								["50% 抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["25% 抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["暗影箭"] = {
							["Details"] = {
								["50% 抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["衰弱之触"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["寒冰箭"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["击退"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["蜂花护发素"] = {
							["Details"] = {
								["防护冰霜结界"] = {
									["count"] = 0,
								},
								["寒冰护体"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
						["蜂花护发素"] = {
							["Details"] = {
								["魔法吸收"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["蜂花护发素"] = {
							["Details"] = {
								["防护冰霜结界"] = {
									["count"] = 0,
								},
								["寒冰护体"] = {
									["count"] = 866,
								},
							},
							["amount"] = 866,
						},
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
						["魔法吸收"] = {
							["Details"] = {
								["蜂花护发素"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["鬼魂市民"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["寒冰箭"] = {
									["count"] = 0,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["蜂花护发素"] = {
							["Details"] = {
								["防护冰霜结界"] = {
									["count"] = 0,
								},
								["寒冰护体"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["缝补憎恶"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["寒冰箭"] = {
									["count"] = 3.34,
								},
								["火焰冲击"] = {
									["count"] = 3,
								},
								["冰霜新星"] = {
									["count"] = 1.05,
								},
							},
							["amount"] = 7.39,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 2.29,
								},
							},
							["amount"] = 2.29,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["防护冰霜结界"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["寒冰护体"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 866,
									["min"] = 866,
									["count"] = 1,
									["amount"] = 866,
								},
							},
							["count"] = 1,
							["amount"] = 866,
						},
					},
					["WhoHealed"] = {
						["三聚氰胺"] = {
							["Details"] = {
								["恢复"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["蜂花护发素"] = {
							["Details"] = {
								["防护冰霜结界"] = {
									["count"] = 0,
								},
								["寒冰护体"] = {
									["count"] = 866,
								},
							},
							["amount"] = 866,
						},
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 12.68,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["暴风雪 (伤害/跳)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 176,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 880,
								},
							},
							["count"] = 5,
							["amount"] = 880,
						},
						["寒冰箭"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1670,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 1670,
								},
								["Hit"] = {
									["max"] = 841,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 2504,
								},
							},
							["count"] = 4,
							["amount"] = 4174,
						},
						["火焰冲击"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 638,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 1264,
								},
							},
							["count"] = 2,
							["amount"] = 1264,
						},
						["冰霜新星"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 30,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 30,
								},
							},
							["count"] = 1,
							["amount"] = 30,
						},
					},
					["HealingTaken"] = 866,
					["RageGain"] = 0,
					["TimeDamage"] = 11.18,
					["TimeDamaging"] = {
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["鬼魂市民"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["寒冰箭"] = {
									["count"] = 0,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["缝补憎恶"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["寒冰箭"] = {
									["count"] = 3.34,
								},
								["火焰冲击"] = {
									["count"] = 3,
								},
								["冰霜新星"] = {
									["count"] = 1.05,
								},
							},
							["amount"] = 7.39,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 2.29,
								},
							},
							["amount"] = 2.29,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["TimeHealing"] = {
						["蜂花护发素"] = {
							["Details"] = {
								["寒冰护体"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["DOTs"] = {
						["暴风雪 (伤害/跳)"] = {
							["Details"] = {
								["骷髅狂战士"] = {
									["count"] = 351,
								},
								["被撕裂的死尸"] = {
									["count"] = 849,
								},
								["恶疫食尸鬼"] = {
									["count"] = 399,
								},
								["破碎的死尸"] = {
									["count"] = 42,
								},
								["被毁坏的死尸"] = {
									["count"] = 822,
								},
								["骷髅守护者"] = {
									["count"] = 318,
								},
							},
							["amount"] = 2781,
						},
					},
					["TimeSpent"] = {
						["骷髅狂战士"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0.47,
								},
								["冰霜新星"] = {
									["count"] = 0.02,
								},
							},
							["amount"] = 0.49,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 4.61,
								},
								["冰锥术"] = {
									["count"] = 0.13,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
							},
							["amount"] = 4.74,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 2.73,
								},
								["冰霜新星"] = {
									["count"] = 0.93,
								},
								["火焰冲击"] = {
									["count"] = 0,
								},
								["射击"] = {
									["count"] = 0,
								},
								["寒冰箭"] = {
									["count"] = 0,
								},
								["冰锥术"] = {
									["count"] = 0.43,
								},
							},
							["amount"] = 4.09,
						},
						["蜂花护发素"] = {
							["Details"] = {
								["寒冰护体"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 3.55,
								},
								["火焰冲击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 3.55,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 20.81,
								},
								["冰锥术"] = {
									["count"] = 0.38,
								},
							},
							["amount"] = 21.19,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0.5,
								},
								["冰霜新星"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 2,
						},
					},
					["DamageTaken"] = 429,
					["WhoHealed"] = {
						["蜂花护发素"] = {
							["Details"] = {
								["寒冰护体"] = {
									["count"] = 429,
								},
							},
							["amount"] = 429,
						},
					},
					["PartialResist"] = {
						["奥术箭"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
						["暗影箭"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 3,
						},
						["挫志怒吼"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
						["寒冰箭"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 2,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 222,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 222,
						},
					},
					["ManaGained"] = {
						["魔法吸收"] = {
							["Details"] = {
								["蜂花护发素"] = {
									["count"] = 361,
								},
							},
							["amount"] = 361,
						},
						["恢复法力"] = {
							["Details"] = {
								["蜂花护发素"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["补充法力"] = {
							["Details"] = {
								["蜂花护发素"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["奥术箭"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["暗影箭"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 74,
									["min"] = 74,
									["count"] = 1,
									["amount"] = 74,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 74,
						},
						["挫志怒吼"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["寒冰箭"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 355,
									["min"] = 355,
									["count"] = 1,
									["amount"] = 355,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 221,
									["amount"] = 0,
								},
							},
							["count"] = 222,
							["amount"] = 355,
						},
					},
					["ActiveTime"] = 39.06,
					["Attacks"] = {
						["暴风雪 (伤害/跳)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 176,
									["min"] = 0,
									["count"] = 927,
									["amount"] = 163056,
								},
							},
							["count"] = 927,
							["amount"] = 163056,
						},
						["冰霜新星"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 66,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 579,
								},
								["Hit"] = {
									["max"] = 33,
									["min"] = 0,
									["count"] = 58,
									["amount"] = 1815,
								},
							},
							["count"] = 68,
							["amount"] = 2394,
						},
						["火焰冲击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["射击"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["寒冰箭"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["冰锥术"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 1167,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 3471,
								},
								["Hit"] = {
									["max"] = 593,
									["min"] = 0,
									["count"] = 18,
									["amount"] = 10307,
								},
							},
							["count"] = 22,
							["amount"] = 13778,
						},
					},
					["ElementTaken"] = {
						["Melee"] = 355,
						["Shadow"] = 74,
					},
					["DOT_Time"] = 2781,
					["Damage"] = 179228,
					["HealedWho"] = {
						["蜂花护发素"] = {
							["Details"] = {
								["寒冰护体"] = {
									["count"] = 429,
								},
							},
							["amount"] = 429,
						},
					},
					["TimeHeal"] = 3,
					["Heals"] = {
						["寒冰护体"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 355,
									["min"] = 74,
									["count"] = 2,
									["amount"] = 429,
								},
							},
							["count"] = 2,
							["amount"] = 429,
						},
					},
					["ElementHitsDone"] = {
						["Fire"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Frost"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 76,
								},
								["Crit"] = {
									["count"] = 12,
								},
								["Tick"] = {
									["count"] = 927,
								},
							},
							["amount"] = 1017,
						},
					},
					["Absorbs"] = 429,
					["ElementTakenAbsorb"] = {
						["Melee"] = 355,
						["Shadow"] = 74,
					},
					["ElementHitsTaken"] = {
						["Shadow"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
								},
								["Immune"] = {
									["count"] = 2,
								},
							},
							["amount"] = 3,
						},
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
								},
								["Immune"] = {
									["count"] = 185,
								},
								["Miss"] = {
									["count"] = 36,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 222,
						},
						["Arcane"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Physical"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Frost"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["WhoDamaged"] = {
						["被撕裂的死尸"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 355,
								},
							},
							["amount"] = 355,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暗影箭"] = {
									["count"] = 74,
								},
							},
							["amount"] = 74,
						},
					},
					["ElementDone"] = {
						["Fire"] = 0,
						["Frost"] = 179228,
					},
					["HealingTaken"] = 429,
					["DamagedWho"] = {
						["骷髅狂战士"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 20580,
								},
								["冰锥术"] = {
									["count"] = 577,
								},
								["冰霜新星"] = {
									["count"] = 536,
								},
							},
							["amount"] = 21693,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 49779,
								},
								["冰霜新星"] = {
									["count"] = 472,
								},
								["冰锥术"] = {
									["count"] = 5758,
								},
							},
							["amount"] = 56009,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 23397,
								},
								["冰霜新星"] = {
									["count"] = 349,
								},
								["火焰冲击"] = {
									["count"] = 0,
								},
								["射击"] = {
									["count"] = 0,
								},
								["寒冰箭"] = {
									["count"] = 0,
								},
								["冰锥术"] = {
									["count"] = 579,
								},
							},
							["amount"] = 24325,
						},
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 2462,
								},
								["冰霜新星"] = {
									["count"] = 61,
								},
								["火焰冲击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 2523,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 48191,
								},
								["冰霜新星"] = {
									["count"] = 504,
								},
								["冰锥术"] = {
									["count"] = 4568,
								},
							},
							["amount"] = 53263,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 18647,
								},
								["冰锥术"] = {
									["count"] = 2296,
								},
								["冰霜新星"] = {
									["count"] = 472,
								},
							},
							["amount"] = 21415,
						},
					},
					["TimeDamage"] = 36.06,
					["TimeDamaging"] = {
						["骷髅狂战士"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0.47,
								},
								["冰霜新星"] = {
									["count"] = 0.02,
								},
							},
							["amount"] = 0.49,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 4.61,
								},
								["冰锥术"] = {
									["count"] = 0.13,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
							},
							["amount"] = 4.74,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 2.73,
								},
								["冰霜新星"] = {
									["count"] = 0.93,
								},
								["火焰冲击"] = {
									["count"] = 0,
								},
								["射击"] = {
									["count"] = 0,
								},
								["寒冰箭"] = {
									["count"] = 0,
								},
								["冰锥术"] = {
									["count"] = 0.43,
								},
							},
							["amount"] = 4.09,
						},
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 3.55,
								},
								["火焰冲击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 3.55,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 20.81,
								},
								["冰锥术"] = {
									["count"] = 0.38,
								},
							},
							["amount"] = 21.19,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0.5,
								},
								["冰霜新星"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 2,
						},
					},
					["ManaGain"] = 361,
					["ManaGainedFrom"] = {
						["蜂花护发素"] = {
							["Details"] = {
								["魔法吸收"] = {
									["count"] = 361,
								},
								["恢复法力"] = {
									["count"] = 0,
								},
								["补充法力"] = {
									["count"] = 0,
								},
							},
							["amount"] = 361,
						},
					},
					["Absorbed"] = {
						["寒冰护体"] = {
							["Details"] = {
								["蜂花护发素"] = {
									["max"] = 355,
									["min"] = 74,
									["count"] = 2,
									["amount"] = 429,
								},
							},
							["count"] = 2,
							["amount"] = 429,
						},
					},
				},
				["Fight1"] = {
					["TimeHealing"] = {
						["蜂花护发素"] = {
							["Details"] = {
								["寒冰护体"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["DOTs"] = {
						["暴风雪 (伤害/跳)"] = {
							["Details"] = {
								["骷髅狂战士"] = {
									["count"] = 351,
								},
								["被撕裂的死尸"] = {
									["count"] = 849,
								},
								["恶疫食尸鬼"] = {
									["count"] = 399,
								},
								["破碎的死尸"] = {
									["count"] = 42,
								},
								["被毁坏的死尸"] = {
									["count"] = 822,
								},
								["骷髅守护者"] = {
									["count"] = 318,
								},
							},
							["amount"] = 2781,
						},
					},
					["TimeSpent"] = {
						["骷髅狂战士"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0.47,
								},
								["冰霜新星"] = {
									["count"] = 0.02,
								},
							},
							["amount"] = 0.49,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 4.61,
								},
								["冰锥术"] = {
									["count"] = 0.13,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
							},
							["amount"] = 4.74,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 2.73,
								},
								["冰霜新星"] = {
									["count"] = 0.93,
								},
								["火焰冲击"] = {
									["count"] = 0,
								},
								["射击"] = {
									["count"] = 0,
								},
								["寒冰箭"] = {
									["count"] = 0,
								},
								["冰锥术"] = {
									["count"] = 0.43,
								},
							},
							["amount"] = 4.09,
						},
						["蜂花护发素"] = {
							["Details"] = {
								["寒冰护体"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 3.55,
								},
								["火焰冲击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 3.55,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 20.81,
								},
								["冰锥术"] = {
									["count"] = 0.38,
								},
							},
							["amount"] = 21.19,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0.5,
								},
								["冰霜新星"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 2,
						},
					},
					["DamageTaken"] = 429,
					["WhoHealed"] = {
						["蜂花护发素"] = {
							["Details"] = {
								["寒冰护体"] = {
									["count"] = 429,
								},
							},
							["amount"] = 429,
						},
					},
					["PartialResist"] = {
						["奥术箭"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
						["暗影箭"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 3,
						},
						["挫志怒吼"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
						["寒冰箭"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 2,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 222,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 222,
						},
					},
					["ManaGained"] = {
						["魔法吸收"] = {
							["Details"] = {
								["蜂花护发素"] = {
									["count"] = 361,
								},
							},
							["amount"] = 361,
						},
						["恢复法力"] = {
							["Details"] = {
								["蜂花护发素"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["补充法力"] = {
							["Details"] = {
								["蜂花护发素"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["奥术箭"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["暗影箭"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 74,
									["min"] = 74,
									["count"] = 1,
									["amount"] = 74,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 74,
						},
						["挫志怒吼"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["寒冰箭"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 355,
									["min"] = 355,
									["count"] = 1,
									["amount"] = 355,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 221,
									["amount"] = 0,
								},
							},
							["count"] = 222,
							["amount"] = 355,
						},
					},
					["ActiveTime"] = 39.06,
					["Attacks"] = {
						["暴风雪 (伤害/跳)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 176,
									["min"] = 0,
									["count"] = 927,
									["amount"] = 163056,
								},
							},
							["count"] = 927,
							["amount"] = 163056,
						},
						["冰霜新星"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 66,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 579,
								},
								["Hit"] = {
									["max"] = 33,
									["min"] = 0,
									["count"] = 58,
									["amount"] = 1815,
								},
							},
							["count"] = 68,
							["amount"] = 2394,
						},
						["火焰冲击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["射击"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["寒冰箭"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["冰锥术"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 1167,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 3471,
								},
								["Hit"] = {
									["max"] = 593,
									["min"] = 0,
									["count"] = 18,
									["amount"] = 10307,
								},
							},
							["count"] = 22,
							["amount"] = 13778,
						},
					},
					["ElementTaken"] = {
						["Melee"] = 355,
						["Shadow"] = 74,
					},
					["DOT_Time"] = 2781,
					["Damage"] = 179228,
					["HealedWho"] = {
						["蜂花护发素"] = {
							["Details"] = {
								["寒冰护体"] = {
									["count"] = 429,
								},
							},
							["amount"] = 429,
						},
					},
					["TimeHeal"] = 3,
					["Heals"] = {
						["寒冰护体"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 355,
									["min"] = 74,
									["count"] = 2,
									["amount"] = 429,
								},
							},
							["count"] = 2,
							["amount"] = 429,
						},
					},
					["ElementHitsDone"] = {
						["Fire"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Frost"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 76,
								},
								["Crit"] = {
									["count"] = 12,
								},
								["Tick"] = {
									["count"] = 927,
								},
							},
							["amount"] = 1017,
						},
					},
					["Absorbs"] = 429,
					["ElementTakenAbsorb"] = {
						["Melee"] = 355,
						["Shadow"] = 74,
					},
					["ElementHitsTaken"] = {
						["Shadow"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
								},
								["Immune"] = {
									["count"] = 2,
								},
							},
							["amount"] = 3,
						},
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
								},
								["Immune"] = {
									["count"] = 185,
								},
								["Miss"] = {
									["count"] = 36,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 222,
						},
						["Arcane"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Physical"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Frost"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["WhoDamaged"] = {
						["被撕裂的死尸"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 355,
								},
							},
							["amount"] = 355,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暗影箭"] = {
									["count"] = 74,
								},
							},
							["amount"] = 74,
						},
					},
					["ElementDone"] = {
						["Fire"] = 0,
						["Frost"] = 179228,
					},
					["HealingTaken"] = 429,
					["DamagedWho"] = {
						["骷髅狂战士"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 20580,
								},
								["冰锥术"] = {
									["count"] = 577,
								},
								["冰霜新星"] = {
									["count"] = 536,
								},
							},
							["amount"] = 21693,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 49779,
								},
								["冰霜新星"] = {
									["count"] = 472,
								},
								["冰锥术"] = {
									["count"] = 5758,
								},
							},
							["amount"] = 56009,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 23397,
								},
								["冰霜新星"] = {
									["count"] = 349,
								},
								["火焰冲击"] = {
									["count"] = 0,
								},
								["射击"] = {
									["count"] = 0,
								},
								["寒冰箭"] = {
									["count"] = 0,
								},
								["冰锥术"] = {
									["count"] = 579,
								},
							},
							["amount"] = 24325,
						},
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 2462,
								},
								["冰霜新星"] = {
									["count"] = 61,
								},
								["火焰冲击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 2523,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 48191,
								},
								["冰霜新星"] = {
									["count"] = 504,
								},
								["冰锥术"] = {
									["count"] = 4568,
								},
							},
							["amount"] = 53263,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 18647,
								},
								["冰锥术"] = {
									["count"] = 2296,
								},
								["冰霜新星"] = {
									["count"] = 472,
								},
							},
							["amount"] = 21415,
						},
					},
					["TimeDamage"] = 36.06,
					["TimeDamaging"] = {
						["骷髅狂战士"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0.47,
								},
								["冰霜新星"] = {
									["count"] = 0.02,
								},
							},
							["amount"] = 0.49,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 4.61,
								},
								["冰锥术"] = {
									["count"] = 0.13,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
							},
							["amount"] = 4.74,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 2.73,
								},
								["冰霜新星"] = {
									["count"] = 0.93,
								},
								["火焰冲击"] = {
									["count"] = 0,
								},
								["射击"] = {
									["count"] = 0,
								},
								["寒冰箭"] = {
									["count"] = 0,
								},
								["冰锥术"] = {
									["count"] = 0.43,
								},
							},
							["amount"] = 4.09,
						},
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 3.55,
								},
								["火焰冲击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 3.55,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 20.81,
								},
								["冰锥术"] = {
									["count"] = 0.38,
								},
							},
							["amount"] = 21.19,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0.5,
								},
								["冰霜新星"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 2,
						},
					},
					["ManaGain"] = 361,
					["ManaGainedFrom"] = {
						["蜂花护发素"] = {
							["Details"] = {
								["魔法吸收"] = {
									["count"] = 361,
								},
								["恢复法力"] = {
									["count"] = 0,
								},
								["补充法力"] = {
									["count"] = 0,
								},
							},
							["amount"] = 361,
						},
					},
					["Absorbed"] = {
						["寒冰护体"] = {
							["Details"] = {
								["蜂花护发素"] = {
									["max"] = 355,
									["min"] = 74,
									["count"] = 2,
									["amount"] = 429,
								},
							},
							["count"] = 2,
							["amount"] = 429,
						},
					},
				},
				["OverallData"] = {
					["TimeHealing"] = {
						["蜂花护发素"] = {
							["Details"] = {
								["寒冰护体"] = {
									["count"] = 27.57,
								},
								["防护冰霜结界"] = {
									["count"] = 3,
								},
							},
							["amount"] = 30.57,
						},
					},
					["DOTs"] = {
						["暴风雪 (伤害/跳)"] = {
							["Details"] = {
								["破碎的死尸"] = {
									["count"] = 231,
								},
								["被毁坏的死尸"] = {
									["count"] = 3765,
								},
								["骷髅守护者"] = {
									["count"] = 1428,
								},
								["骷髅狂战士"] = {
									["count"] = 1161,
								},
								["被撕裂的死尸"] = {
									["count"] = 3462,
								},
								["恶疫食尸鬼"] = {
									["count"] = 1569,
								},
								["缝补憎恶"] = {
									["count"] = 390,
								},
								["幽灵市民"] = {
									["count"] = 72,
								},
								["鬼魂市民"] = {
									["count"] = 69,
								},
							},
							["amount"] = 12147,
						},
					},
					["ElementTakenAbsorb"] = {
						["Frost"] = 337,
						["Melee"] = 2411,
						["Arcane"] = 369,
						["Shadow"] = 232,
						["Physical"] = 1705,
					},
					["ElementDoneResist"] = {
						["Frost"] = 3109,
					},
					["TimeSpent"] = {
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 15.93,
								},
								["火焰冲击"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 17.43,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 107.53,
								},
								["冰霜新星"] = {
									["count"] = 0.43,
								},
								["冰锥术"] = {
									["count"] = 1.88,
								},
							},
							["amount"] = 109.84,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 9.41,
								},
								["冰霜新星"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 10.91,
						},
						["骷髅狂战士"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 1.71,
								},
								["冰霜新星"] = {
									["count"] = 0.02,
								},
								["冰锥术"] = {
									["count"] = 1.47,
								},
							},
							["amount"] = 3.2,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 51.97,
								},
								["冰锥术"] = {
									["count"] = 1.03,
								},
								["冰霜新星"] = {
									["count"] = 1.08,
								},
							},
							["amount"] = 54.08,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 22.86,
								},
								["冰霜新星"] = {
									["count"] = 3.08,
								},
								["火焰冲击"] = {
									["count"] = 1.46,
								},
								["射击"] = {
									["count"] = 3,
								},
								["寒冰箭"] = {
									["count"] = 1.5,
								},
								["冰锥术"] = {
									["count"] = 1.67,
								},
							},
							["amount"] = 33.57,
						},
						["蜂花护发素"] = {
							["Details"] = {
								["寒冰护体"] = {
									["count"] = 27.57,
								},
								["防护冰霜结界"] = {
									["count"] = 3,
								},
							},
							["amount"] = 30.57,
						},
						["缝补憎恶"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 16.63,
								},
								["冰霜新星"] = {
									["count"] = 5.68,
								},
								["寒冰箭"] = {
									["count"] = 21.65,
								},
								["火焰冲击"] = {
									["count"] = 10.5,
								},
								["冰锥术"] = {
									["count"] = 2.58,
								},
							},
							["amount"] = 57.04,
						},
						["鬼魂市民"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 5.25,
								},
								["寒冰箭"] = {
									["count"] = 1.5,
								},
								["冰霜新星"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 8.25,
						},
					},
					["DamageTaken"] = 8457,
					["ElementTakenResist"] = {
						["Shadow"] = 79,
						["Arcane"] = 59,
					},
					["PartialResist"] = {
						["奥术箭"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
								["50% 抵抗"] = {
									["max"] = 40,
									["min"] = 40,
									["count"] = 1,
									["amount"] = 40,
								},
								["25% 抵抗"] = {
									["max"] = 19,
									["min"] = 19,
									["count"] = 1,
									["amount"] = 19,
								},
							},
							["count"] = 59,
							["amount"] = 9,
						},
						["疾病之云"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 2,
						},
						["暗影箭"] = {
							["Details"] = {
								["50% 抵抗"] = {
									["max"] = 79,
									["min"] = 79,
									["count"] = 1,
									["amount"] = 79,
								},
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 10,
									["amount"] = 0,
								},
							},
							["count"] = 79,
							["amount"] = 11,
						},
						["挫志怒吼"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
						["衰弱之触"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 2,
						},
						["击退"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 5,
						},
						["寒冰箭"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 8,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 440,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 440,
						},
					},
					["ManaGained"] = {
						["魔法吸收"] = {
							["Details"] = {
								["蜂花护发素"] = {
									["count"] = 2888,
								},
							},
							["amount"] = 2888,
						},
						["恢复法力"] = {
							["Details"] = {
								["蜂花护发素"] = {
									["count"] = 750,
								},
							},
							["amount"] = 750,
						},
						["补充法力"] = {
							["Details"] = {
								["蜂花护发素"] = {
									["count"] = 1091,
								},
							},
							["amount"] = 1091,
						},
					},
					["PartialAbsorb"] = {
						["奥术箭"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
								["被吸收"] = {
									["max"] = 106,
									["min"] = 86,
									["count"] = 4,
									["amount"] = 369,
								},
							},
							["count"] = 9,
							["amount"] = 369,
						},
						["疾病之云"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["暗影箭"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 158,
									["min"] = 74,
									["count"] = 2,
									["amount"] = 232,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 11,
							["amount"] = 232,
						},
						["挫志怒吼"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["衰弱之触"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["击退"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
								["被吸收"] = {
									["max"] = 866,
									["min"] = 61,
									["count"] = 3,
									["amount"] = 1705,
								},
							},
							["count"] = 5,
							["amount"] = 1705,
						},
						["寒冰箭"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
								["被吸收"] = {
									["max"] = 113,
									["min"] = 32,
									["count"] = 4,
									["amount"] = 337,
								},
							},
							["count"] = 8,
							["amount"] = 337,
						},
						["肉搏"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 412,
									["min"] = 148,
									["count"] = 8,
									["amount"] = 2411,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 432,
									["amount"] = 0,
								},
							},
							["count"] = 440,
							["amount"] = 2411,
						},
					},
					["ActiveTime"] = 324.89,
					["WhoHealed"] = {
						["三聚氰胺"] = {
							["Details"] = {
								["恢复"] = {
									["count"] = 27,
								},
							},
							["amount"] = 27,
						},
						["蜂花护发素"] = {
							["Details"] = {
								["寒冰护体"] = {
									["count"] = 4988,
								},
								["防护冰霜结界"] = {
									["count"] = 131,
								},
							},
							["amount"] = 5119,
						},
					},
					["ElementTaken"] = {
						["Frost"] = 474,
						["Melee"] = 4818,
						["Arcane"] = 551,
						["Shadow"] = 904,
						["Physical"] = 1710,
					},
					["DOT_Time"] = 12147,
					["Damage"] = 771955,
					["Attacks"] = {
						["暴风雪 (伤害/跳)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 176,
									["min"] = 44,
									["count"] = 4049,
									["amount"] = 697749,
								},
							},
							["count"] = 4049,
							["amount"] = 697749,
						},
						["冰霜新星"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 66,
									["min"] = 61,
									["count"] = 15,
									["amount"] = 963,
								},
								["Hit"] = {
									["max"] = 33,
									["min"] = 30,
									["count"] = 116,
									["amount"] = 3639,
								},
							},
							["count"] = 132,
							["amount"] = 4602,
						},
						["火焰冲击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 943,
									["min"] = 943,
									["count"] = 1,
									["amount"] = 943,
								},
								["Hit"] = {
									["max"] = 672,
									["min"] = 617,
									["count"] = 8,
									["amount"] = 5103,
								},
							},
							["count"] = 9,
							["amount"] = 6046,
						},
						["射击"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 188,
									["min"] = 186,
									["count"] = 2,
									["amount"] = 374,
								},
							},
							["count"] = 2,
							["amount"] = 374,
						},
						["寒冰箭"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1670,
									["min"] = 1615,
									["count"] = 3,
									["amount"] = 4952,
								},
								["Hit"] = {
									["max"] = 851,
									["min"] = 787,
									["count"] = 17,
									["amount"] = 14084,
								},
							},
							["count"] = 20,
							["amount"] = 19036,
						},
						["冰锥术"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 2,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 1170,
									["min"] = 1108,
									["count"] = 8,
									["amount"] = 9164,
								},
								["Hit"] = {
									["max"] = 593,
									["min"] = 553,
									["count"] = 61,
									["amount"] = 34984,
								},
							},
							["count"] = 71,
							["amount"] = 44148,
						},
					},
					["TimeHeal"] = 30.57,
					["HealedWho"] = {
						["蜂花护发素"] = {
							["Details"] = {
								["寒冰护体"] = {
									["count"] = 4988,
								},
								["防护冰霜结界"] = {
									["count"] = 131,
								},
							},
							["amount"] = 5119,
						},
					},
					["Heals"] = {
						["寒冰护体"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 866,
									["min"] = 4,
									["count"] = 21,
									["amount"] = 4988,
								},
							},
							["count"] = 21,
							["amount"] = 4988,
						},
						["防护冰霜结界"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 99,
									["min"] = 32,
									["count"] = 2,
									["amount"] = 131,
								},
							},
							["count"] = 2,
							["amount"] = 131,
						},
					},
					["ElementHitsDone"] = {
						["Fire"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 10,
								},
							},
							["amount"] = 11,
						},
						["Frost"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 3,
								},
								["Hit"] = {
									["count"] = 194,
								},
								["Crit"] = {
									["count"] = 26,
								},
								["Tick"] = {
									["count"] = 4049,
								},
							},
							["amount"] = 4272,
						},
					},
					["Absorbs"] = 5119,
					["ElementHitsTaken"] = {
						["Frost"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 3,
								},
								["Immune"] = {
									["count"] = 3,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 8,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 363,
								},
								["Absorb"] = {
									["count"] = 12,
								},
								["Miss"] = {
									["count"] = 63,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 440,
						},
						["Arcane"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 2,
								},
								["Absorb"] = {
									["count"] = 4,
								},
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 9,
						},
						["Physical"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 1,
								},
								["Miss"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 6,
						},
						["Shadow"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 3,
								},
								["Immune"] = {
									["count"] = 3,
								},
								["Absorb"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 13,
						},
						["Nature"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["WhoDamaged"] = {
						["骷髅狂战士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 148,
								},
							},
							["amount"] = 148,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 986,
								},
							},
							["amount"] = 986,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 386,
								},
							},
							["amount"] = 386,
						},
						["缝补憎恶"] = {
							["Details"] = {
								["击退"] = {
									["count"] = 1710,
								},
								["肉搏"] = {
									["count"] = 1705,
								},
							},
							["amount"] = 3415,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 1116,
								},
							},
							["amount"] = 1116,
						},
						["幽灵市民"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 284,
								},
							},
							["amount"] = 284,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["奥术箭"] = {
									["count"] = 551,
								},
								["寒冰箭"] = {
									["count"] = 474,
								},
								["暗影箭"] = {
									["count"] = 904,
								},
								["肉搏"] = {
									["count"] = 193,
								},
							},
							["amount"] = 2122,
						},
					},
					["ElementDone"] = {
						["Fire"] = 6420,
						["Frost"] = 765535,
					},
					["HealingTaken"] = 5146,
					["DamagedWho"] = {
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 11700,
								},
								["冰霜新星"] = {
									["count"] = 61,
								},
								["火焰冲击"] = {
									["count"] = 943,
								},
							},
							["amount"] = 12704,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 218323,
								},
								["冰霜新星"] = {
									["count"] = 848,
								},
								["冰锥术"] = {
									["count"] = 17133,
								},
							},
							["amount"] = 236304,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 83727,
								},
								["冰锥术"] = {
									["count"] = 2296,
								},
								["冰霜新星"] = {
									["count"] = 788,
								},
							},
							["amount"] = 86811,
						},
						["骷髅狂战士"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 68066,
								},
								["冰霜新星"] = {
									["count"] = 947,
								},
								["冰锥术"] = {
									["count"] = 3976,
								},
							},
							["amount"] = 72989,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 197771,
								},
								["冰霜新星"] = {
									["count"] = 1103,
								},
								["冰锥术"] = {
									["count"] = 17230,
								},
							},
							["amount"] = 216104,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 90211,
								},
								["冰霜新星"] = {
									["count"] = 605,
								},
								["火焰冲击"] = {
									["count"] = 658,
								},
								["射击"] = {
									["count"] = 374,
								},
								["寒冰箭"] = {
									["count"] = 826,
								},
								["冰锥术"] = {
									["count"] = 2330,
								},
							},
							["amount"] = 95004,
						},
						["缝补憎恶"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 22829,
								},
								["冰霜新星"] = {
									["count"] = 187,
								},
								["寒冰箭"] = {
									["count"] = 17423,
								},
								["火焰冲击"] = {
									["count"] = 4445,
								},
								["冰锥术"] = {
									["count"] = 1183,
								},
							},
							["amount"] = 46067,
						},
						["幽灵市民"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 2726,
								},
								["冰霜新星"] = {
									["count"] = 31,
								},
							},
							["amount"] = 2757,
						},
						["鬼魂市民"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 2396,
								},
								["寒冰箭"] = {
									["count"] = 787,
								},
								["冰霜新星"] = {
									["count"] = 32,
								},
							},
							["amount"] = 3215,
						},
					},
					["TimeDamage"] = 294.32,
					["TimeDamaging"] = {
						["骷髅狂战士"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 1.71,
								},
								["冰霜新星"] = {
									["count"] = 0.02,
								},
								["冰锥术"] = {
									["count"] = 1.47,
								},
							},
							["amount"] = 3.2,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 51.97,
								},
								["冰锥术"] = {
									["count"] = 1.03,
								},
								["冰霜新星"] = {
									["count"] = 1.08,
								},
							},
							["amount"] = 54.08,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 22.86,
								},
								["冰霜新星"] = {
									["count"] = 3.08,
								},
								["火焰冲击"] = {
									["count"] = 1.46,
								},
								["射击"] = {
									["count"] = 3,
								},
								["寒冰箭"] = {
									["count"] = 1.5,
								},
								["冰锥术"] = {
									["count"] = 1.67,
								},
							},
							["amount"] = 33.57,
						},
						["鬼魂市民"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 5.25,
								},
								["寒冰箭"] = {
									["count"] = 1.5,
								},
								["冰霜新星"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 8.25,
						},
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 15.93,
								},
								["火焰冲击"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 17.43,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 107.53,
								},
								["冰霜新星"] = {
									["count"] = 0.43,
								},
								["冰锥术"] = {
									["count"] = 1.88,
								},
							},
							["amount"] = 109.84,
						},
						["缝补憎恶"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 16.63,
								},
								["冰霜新星"] = {
									["count"] = 5.68,
								},
								["寒冰箭"] = {
									["count"] = 21.65,
								},
								["火焰冲击"] = {
									["count"] = 10.5,
								},
								["冰锥术"] = {
									["count"] = 2.58,
								},
							},
							["amount"] = 57.04,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 9.41,
								},
								["冰霜新星"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 10.91,
						},
					},
					["ManaGain"] = 4729,
					["ManaGainedFrom"] = {
						["蜂花护发素"] = {
							["Details"] = {
								["魔法吸收"] = {
									["count"] = 2888,
								},
								["恢复法力"] = {
									["count"] = 750,
								},
								["补充法力"] = {
									["count"] = 1091,
								},
							},
							["amount"] = 4729,
						},
					},
					["Absorbed"] = {
						["寒冰护体"] = {
							["Details"] = {
								["蜂花护发素"] = {
									["max"] = 866,
									["min"] = 4,
									["count"] = 21,
									["amount"] = 4988,
								},
							},
							["count"] = 21,
							["amount"] = 4988,
						},
						["防护冰霜结界"] = {
							["Details"] = {
								["蜂花护发素"] = {
									["max"] = 99,
									["min"] = 32,
									["count"] = 2,
									["amount"] = 131,
								},
							},
							["count"] = 2,
							["amount"] = 131,
						},
					},
				},
			},
			["UnitLockout"] = 50949.223,
			["LastActive"] = 51205.212,
		},
		["红莲业火丶"] = {
			["GUID"] = "Player-4829-01C5BE8B",
			["LastEventHealth"] = {
				3490, -- [1]
				3490, -- [2]
				3490, -- [3]
				3490, -- [4]
				3490, -- [5]
				3490, -- [6]
				3490, -- [7]
				3490, -- [8]
				3490, -- [9]
				3490, -- [10]
				3490, -- [11]
				3490, -- [12]
				3490, -- [13]
				3490, -- [14]
				3490, -- [15]
				3490, -- [16]
				3490, -- [17]
				3490, -- [18]
				3490, -- [19]
				3490, -- [20]
				3490, -- [21]
				3490, -- [22]
				3490, -- [23]
				3490, -- [24]
				3490, -- [25]
				3490, -- [26]
				3490, -- [27]
				3490, -- [28]
				3490, -- [29]
				3490, -- [30]
				3490, -- [31]
				3490, -- [32]
				3490, -- [33]
				3490, -- [34]
				3490, -- [35]
				3490, -- [36]
				3490, -- [37]
				3490, -- [38]
				3490, -- [39]
				3490, -- [40]
				3490, -- [41]
				3490, -- [42]
				3490, -- [43]
				3490, -- [44]
				3490, -- [45]
				3490, -- [46]
				3490, -- [47]
				3490, -- [48]
				3490, -- [49]
				3490, -- [50]
			},
			["LastAttackedBy"] = "骷髅守护者",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["TimeHeal"] = {
					24.73, -- [1]
				},
				["DamageTaken"] = {
					4438, -- [1]
				},
				["Absorbs"] = {
					3648, -- [1]
				},
				["HealingTaken"] = {
					3648, -- [1]
				},
				["TimeDamage"] = {
					293.14, -- [1]
				},
				["ActiveTime"] = {
					317.87, -- [1]
				},
				["ManaGain"] = {
					1766, -- [1]
				},
				["DOT_Time"] = {
					11625, -- [1]
				},
				["Damage"] = {
					730880, -- [1]
				},
			},
			["enClass"] = "MAGE",
			["unit"] = "红莲业火丶",
			["level"] = 60,
			["LastDamageAbility"] = "暗影箭",
			["LastFightIn"] = 12,
			["LastDamageTaken"] = 125,
			["type"] = "Grouped",
			["FightsSaved"] = 5,
			["LastHealTime"] = 51175.013,
			["TimeLast"] = {
				["TimeHeal"] = 51174.214,
				["OVERALL"] = 51205.212,
				["DamageTaken"] = 51174.214,
				["Absorbs"] = 51174.214,
				["HealingTaken"] = 51174.214,
				["TimeDamage"] = 51205.212,
				["ActiveTime"] = 51205.212,
				["ManaGain"] = 51178.214,
				["DOT_Time"] = 51205.212,
				["Damage"] = 51205.212,
			},
			["Owner"] = false,
			["LastEventHealthMax"] = {
				3490, -- [1]
				3490, -- [2]
				3490, -- [3]
				3490, -- [4]
				3490, -- [5]
				3490, -- [6]
				3490, -- [7]
				3490, -- [8]
				3490, -- [9]
				3490, -- [10]
				3490, -- [11]
				3490, -- [12]
				3490, -- [13]
				3490, -- [14]
				3490, -- [15]
				3490, -- [16]
				3490, -- [17]
				3490, -- [18]
				3490, -- [19]
				3490, -- [20]
				3490, -- [21]
				3490, -- [22]
				3490, -- [23]
				3490, -- [24]
				3490, -- [25]
				3490, -- [26]
				3490, -- [27]
				3490, -- [28]
				3490, -- [29]
				3490, -- [30]
				3490, -- [31]
				3490, -- [32]
				3490, -- [33]
				3490, -- [34]
				3490, -- [35]
				3490, -- [36]
				3490, -- [37]
				3490, -- [38]
				3490, -- [39]
				3490, -- [40]
				3490, -- [41]
				3490, -- [42]
				3490, -- [43]
				3490, -- [44]
				3490, -- [45]
				3490, -- [46]
				3490, -- [47]
				3490, -- [48]
				3490, -- [49]
				3490, -- [50]
			},
			["NextEventNum"] = 34,
			["LastDamageTime"] = 51205.881,
			["LastEvents"] = {
				"红莲业火丶 暴风雪 (伤害/跳) 被毁坏的死尸 Tick -173 (Frost)", -- [1]
				"红莲业火丶 暴风雪 (伤害/跳) 被毁坏的死尸 Tick -173 (Frost)", -- [2]
				"红莲业火丶 暴风雪 (伤害/跳) 被毁坏的死尸 Tick -173 (Frost)", -- [3]
				"红莲业火丶 暴风雪 (伤害/跳) 恶疫食尸鬼 Tick -173 (Frost)", -- [4]
				"红莲业火丶 暴风雪 (伤害/跳) 被撕裂的死尸 Tick -173 (Frost)", -- [5]
				"红莲业火丶 暴风雪 (伤害/跳) 被撕裂的死尸 Tick -173 (Frost)", -- [6]
				"红莲业火丶 暴风雪 (伤害/跳) 被撕裂的死尸 Tick -173 (Frost)", -- [7]
				"红莲业火丶 暴风雪 (伤害/跳) 恶疫食尸鬼 Tick -173 (Frost)", -- [8]
				"红莲业火丶 暴风雪 (伤害/跳) 恶疫食尸鬼 Tick -173 (Frost)", -- [9]
				"红莲业火丶 暴风雪 (伤害/跳) 被撕裂的死尸 Tick -172 (Frost)", -- [10]
				"红莲业火丶 暴风雪 (伤害/跳) 被撕裂的死尸 Tick -173 (Frost)", -- [11]
				"红莲业火丶 暴风雪 (伤害/跳) 恶疫食尸鬼 Tick -173 (Frost)", -- [12]
				"红莲业火丶 暴风雪 (伤害/跳) 恶疫食尸鬼 Tick -173 (Frost)", -- [13]
				"红莲业火丶 暴风雪 (伤害/跳) 恶疫食尸鬼 Tick -173 (Frost)", -- [14]
				"红莲业火丶 暴风雪 (伤害/跳) 被撕裂的死尸 Tick -173 (Frost)", -- [15]
				"红莲业火丶 暴风雪 (伤害/跳) 被撕裂的死尸 Tick -173 (Frost)", -- [16]
				"红莲业火丶 暴风雪 (伤害/跳) 被毁坏的死尸 Tick -173 (Frost)", -- [17]
				"红莲业火丶 暴风雪 (伤害/跳) 破碎的死尸 Tick -172 (Frost)", -- [18]
				"红莲业火丶 暴风雪 (伤害/跳) 恶疫食尸鬼 Tick -173 (Frost)", -- [19]
				"红莲业火丶 暴风雪 (伤害/跳) 恶疫食尸鬼 Tick -172 (Frost)", -- [20]
				"红莲业火丶 暴风雪 (伤害/跳) 恶疫食尸鬼 Tick -172 (Frost)", -- [21]
				"红莲业火丶 暴风雪 (伤害/跳) 被撕裂的死尸 Tick -173 (Frost)", -- [22]
				"红莲业火丶 暴风雪 (伤害/跳) 被毁坏的死尸 Tick -172 (Frost)", -- [23]
				"红莲业火丶 暴风雪 (伤害/跳) 被毁坏的死尸 Tick -173 (Frost)", -- [24]
				"红莲业火丶 暴风雪 (伤害/跳) 被毁坏的死尸 Tick -173 (Frost)", -- [25]
				"红莲业火丶 暴风雪 (伤害/跳) 被撕裂的死尸 Tick -172 (Frost)", -- [26]
				"红莲业火丶 暴风雪 (伤害/跳) 被毁坏的死尸 Tick -173 (Frost)", -- [27]
				"红莲业火丶 暴风雪 (伤害/跳) 恶疫食尸鬼 Tick -172 (Frost)", -- [28]
				"红莲业火丶 暴风雪 (伤害/跳) 恶疫食尸鬼 Tick -173 (Frost)", -- [29]
				"红莲业火丶 暴风雪 (伤害/跳) 破碎的死尸 Tick -173 (Frost)", -- [30]
				"红莲业火丶 暴风雪 (伤害/跳) 破碎的死尸 Tick -173 (Frost)", -- [31]
				"红莲业火丶 暴风雪 (伤害/跳) 破碎的死尸 Tick -172 (Frost)", -- [32]
				"红莲业火丶 暴风雪 (伤害/跳) 恶疫食尸鬼 Tick -173 (Frost)", -- [33]
				"红莲业火丶 暴风雪 (伤害/跳) 被撕裂的死尸 Tick -173 (Frost)", -- [34]
				"红莲业火丶 暴风雪 (伤害/跳) 恶疫食尸鬼 Tick -173 (Frost)", -- [35]
				"红莲业火丶 暴风雪 (伤害/跳) 被撕裂的死尸 Tick -173 (Frost)", -- [36]
				"红莲业火丶 暴风雪 (伤害/跳) 被撕裂的死尸 Tick -173 (Frost)", -- [37]
				"红莲业火丶 暴风雪 (伤害/跳) 被撕裂的死尸 Tick -173 (Frost)", -- [38]
				"红莲业火丶 暴风雪 (伤害/跳) 恶疫食尸鬼 Tick -173 (Frost)", -- [39]
				"红莲业火丶 暴风雪 (伤害/跳) 被撕裂的死尸 Tick -173 (Frost)", -- [40]
				"红莲业火丶 暴风雪 (伤害/跳) 被撕裂的死尸 Tick -172 (Frost)", -- [41]
				"红莲业火丶 暴风雪 (伤害/跳) 恶疫食尸鬼 Tick -173 (Frost)", -- [42]
				"红莲业火丶 暴风雪 (伤害/跳) 恶疫食尸鬼 Tick -173 (Frost)", -- [43]
				"红莲业火丶 暴风雪 (伤害/跳) 恶疫食尸鬼 Tick -173 (Frost)", -- [44]
				"红莲业火丶 暴风雪 (伤害/跳) 恶疫食尸鬼 Tick -173 (Frost)", -- [45]
				"红莲业火丶 暴风雪 (伤害/跳) 被毁坏的死尸 Tick -173 (Frost)", -- [46]
				"红莲业火丶 暴风雪 (伤害/跳) 被撕裂的死尸 Tick -172 (Frost)", -- [47]
				"红莲业火丶 暴风雪 (伤害/跳) 破碎的死尸 Tick -172 (Frost)", -- [48]
				"红莲业火丶 暴风雪 (伤害/跳) 被毁坏的死尸 Tick -173 (Frost)", -- [49]
				"红莲业火丶 暴风雪 (伤害/跳) 被毁坏的死尸 Tick -173 (Frost)", -- [50]
			},
			["Name"] = "红莲业火丶",
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				false, -- [6]
				false, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				false, -- [11]
				false, -- [12]
				false, -- [13]
				false, -- [14]
				false, -- [15]
				false, -- [16]
				false, -- [17]
				false, -- [18]
				false, -- [19]
				false, -- [20]
				false, -- [21]
				false, -- [22]
				false, -- [23]
				false, -- [24]
				false, -- [25]
				false, -- [26]
				false, -- [27]
				false, -- [28]
				false, -- [29]
				false, -- [30]
				false, -- [31]
				false, -- [32]
				false, -- [33]
				false, -- [34]
				false, -- [35]
				false, -- [36]
				false, -- [37]
				false, -- [38]
				false, -- [39]
				false, -- [40]
				false, -- [41]
				false, -- [42]
				false, -- [43]
				false, -- [44]
				false, -- [45]
				false, -- [46]
				false, -- [47]
				false, -- [48]
				false, -- [49]
				false, -- [50]
			},
			["LastEventTimes"] = {
				51199.179, -- [1]
				51199.179, -- [2]
				51199.179, -- [3]
				51199.179, -- [4]
				51199.179, -- [5]
				51199.179, -- [6]
				51199.179, -- [7]
				51199.179, -- [8]
				51199.179, -- [9]
				51199.179, -- [10]
				51199.179, -- [11]
				51199.179, -- [12]
				51199.179, -- [13]
				51199.179, -- [14]
				51199.413, -- [15]
				51199.413, -- [16]
				51199.413, -- [17]
				51202.88, -- [18]
				51202.88, -- [19]
				51202.88, -- [20]
				51202.88, -- [21]
				51202.895, -- [22]
				51202.895, -- [23]
				51202.895, -- [24]
				51202.895, -- [25]
				51202.895, -- [26]
				51203.881, -- [27]
				51203.881, -- [28]
				51204.895, -- [29]
				51204.895, -- [30]
				51204.895, -- [31]
				51204.895, -- [32]
				51205.881, -- [33]
				51198.18, -- [34]
				51198.18, -- [35]
				51198.18, -- [36]
				51198.18, -- [37]
				51198.18, -- [38]
				51198.18, -- [39]
				51198.18, -- [40]
				51198.18, -- [41]
				51198.18, -- [42]
				51198.18, -- [43]
				51198.18, -- [44]
				51198.18, -- [45]
				51198.414, -- [46]
				51198.414, -- [47]
				51198.633, -- [48]
				51199.179, -- [49]
				51199.179, -- [50]
			},
			["Fights"] = {
				["Fight2"] = {
					["DOTs"] = {
						["暴风雪 (伤害/跳)"] = {
							["Details"] = {
								["被撕裂的死尸"] = {
									["count"] = 0,
								},
								["恶疫食尸鬼"] = {
									["count"] = 0,
								},
								["破碎的死尸"] = {
									["count"] = 0,
								},
								["缝补憎恶"] = {
									["count"] = 18,
								},
								["被毁坏的死尸"] = {
									["count"] = 0,
								},
								["鬼魂市民"] = {
									["count"] = 0,
								},
								["骷髅守护者"] = {
									["count"] = 0,
								},
							},
							["amount"] = 18,
						},
					},
					["ElementDoneResist"] = {
						["Frost"] = 0,
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Tick"] = {
									["count"] = 6,
								},
							},
							["amount"] = 8,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 18,
					["Damage"] = 2592,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Frost"] = 2592,
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["缝补憎恶"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 1035,
								},
								["寒冰箭"] = {
									["count"] = 1557,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
							},
							["amount"] = 2592,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["鬼魂市民"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["寒冰箭"] = {
									["count"] = 0,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["缝补憎恶"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 6.51,
								},
								["寒冰箭"] = {
									["count"] = 3,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
							},
							["amount"] = 9.51,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["鬼魂市民"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["寒冰箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 9.51,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["暴风雪 (伤害/跳)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 173,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 1035,
								},
							},
							["count"] = 6,
							["amount"] = 1035,
						},
						["寒冰箭"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 780,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 1557,
								},
							},
							["count"] = 2,
							["amount"] = 1557,
						},
						["冰霜新星"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 9.51,
					["TimeDamaging"] = {
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["缝补憎恶"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 6.51,
								},
								["寒冰箭"] = {
									["count"] = 3,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
							},
							["amount"] = 9.51,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["鬼魂市民"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["寒冰箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["Absorbed"] = {
						["寒冰护体"] = {
							["Details"] = {
								["红莲业火丶"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["DOTs"] = {
						["暴风雪 (伤害/跳)"] = {
							["Details"] = {
								["骷髅狂战士"] = {
									["count"] = 0,
								},
								["被撕裂的死尸"] = {
									["count"] = 0,
								},
								["恶疫食尸鬼"] = {
									["count"] = 0,
								},
								["幽灵市民"] = {
									["count"] = 0,
								},
								["缝补憎恶"] = {
									["count"] = 0,
								},
								["被毁坏的死尸"] = {
									["count"] = 0,
								},
								["破碎的死尸"] = {
									["count"] = 0,
								},
								["骷髅守护者"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementHitsTaken"] = {
						["Frost"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 0,
								},
								["Immune"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 0,
								},
								["Absorb"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Shadow"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 0,
								},
								["Immune"] = {
									["count"] = 0,
								},
								["Absorb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Nature"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementDoneResist"] = {
						["Frost"] = 0,
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["Absorbs"] = 0,
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Frost"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Tick"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementTakenAbsorb"] = {
						["Shadow"] = 0,
						["Melee"] = 0,
						["Physical"] = 0,
					},
					["ElementTaken"] = {
						["Shadow"] = 0,
						["Melee"] = 0,
						["Physical"] = 0,
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Fire"] = 0,
						["Frost"] = 0,
					},
					["PartialAbsorb"] = {
						["疾病之云"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["暗影箭"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["击退"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["寒冰箭"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["暗影迷雾"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["骷髅狂战士"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["冰锥术"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
								["冰锥术"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
								["冰锥术"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["幽灵市民"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["缝补憎恶"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
								["寒冰箭"] = {
									["count"] = 0,
								},
								["冰锥术"] = {
									["count"] = 0,
								},
								["火焰冲击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
								["冰锥术"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["缝补憎恶"] = {
							["Details"] = {
								["击退"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暗影箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["疾病之云"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["暗影箭"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["击退"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["寒冰箭"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["暗影迷雾"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["红莲业火丶"] = {
							["Details"] = {
								["寒冰护体"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
						["红莲业火丶"] = {
							["Details"] = {
								["魔法吸收"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["红莲业火丶"] = {
							["Details"] = {
								["寒冰护体"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
						["魔法吸收"] = {
							["Details"] = {
								["红莲业火丶"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["冰锥术"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["骷髅狂战士"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["冰锥术"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["缝补憎恶"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
								["寒冰箭"] = {
									["count"] = 0,
								},
								["冰锥术"] = {
									["count"] = 0,
								},
								["火焰冲击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["幽灵市民"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["红莲业火丶"] = {
							["Details"] = {
								["寒冰护体"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["寒冰护体"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["WhoHealed"] = {
						["红莲业火丶"] = {
							["Details"] = {
								["寒冰护体"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["暴风雪 (伤害/跳)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["冰霜新星"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["寒冰箭"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["火焰冲击"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["冰锥术"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["骷髅狂战士"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["冰锥术"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["幽灵市民"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["缝补憎恶"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
								["寒冰箭"] = {
									["count"] = 0,
								},
								["冰锥术"] = {
									["count"] = 0,
								},
								["火焰冲击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["冰锥术"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight3"] = {
					["DOTs"] = {
						["暴风雪 (伤害/跳)"] = {
							["Details"] = {
								["被撕裂的死尸"] = {
									["count"] = 183,
								},
								["恶疫食尸鬼"] = {
									["count"] = 123,
								},
								["破碎的死尸"] = {
									["count"] = 18,
								},
								["被毁坏的死尸"] = {
									["count"] = 225,
								},
								["缝补憎恶"] = {
									["count"] = 36,
								},
								["骷髅守护者"] = {
									["count"] = 9,
								},
							},
							["amount"] = 594,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 24,
								},
								["Crit"] = {
									["count"] = 3,
								},
								["Tick"] = {
									["count"] = 198,
								},
							},
							["amount"] = 225,
						},
						["Arcane"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 594,
					["Damage"] = 48537,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Frost"] = 48537,
						["Arcane"] = 0,
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
						["骷髅狂战士"] = {
							["Details"] = {
								["射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 10534,
								},
								["冰锥术"] = {
									["count"] = 3400,
								},
							},
							["amount"] = 13934,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 7082,
								},
								["冰霜新星"] = {
									["count"] = 92,
								},
								["冰锥术"] = {
									["count"] = 1652,
								},
							},
							["amount"] = 8826,
						},
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 1036,
								},
								["冰霜新星"] = {
									["count"] = 30,
								},
							},
							["amount"] = 1066,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 12958,
								},
								["冰霜新星"] = {
									["count"] = 62,
								},
								["冰锥术"] = {
									["count"] = 4424,
								},
							},
							["amount"] = 17444,
						},
						["缝补憎恶"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 2071,
								},
								["寒冰箭"] = {
									["count"] = 4648,
								},
								["冰霜新星"] = {
									["count"] = 30,
								},
							},
							["amount"] = 6749,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 518,
								},
							},
							["amount"] = 518,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["骷髅狂战士"] = {
							["Details"] = {
								["射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 3.15,
								},
							},
							["amount"] = 3.15,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 5.26,
								},
								["冰霜新星"] = {
									["count"] = 0.28,
								},
								["冰锥术"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 7.04,
						},
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 3.21,
								},
							},
							["amount"] = 3.21,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 8.54,
								},
							},
							["amount"] = 8.54,
						},
						["缝补憎恶"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 3.51,
								},
								["寒冰箭"] = {
									["count"] = 9,
								},
								["冰霜新星"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 14.01,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0.02,
								},
							},
							["amount"] = 0.02,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 35.97,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["暴风雪 (伤害/跳)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 173,
									["min"] = 172,
									["count"] = 198,
									["amount"] = 34199,
								},
							},
							["count"] = 198,
							["amount"] = 34199,
						},
						["冰霜新星"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 31,
									["min"] = 30,
									["count"] = 7,
									["amount"] = 214,
								},
							},
							["count"] = 7,
							["amount"] = 214,
						},
						["寒冰箭"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 789,
									["min"] = 758,
									["count"] = 6,
									["amount"] = 4648,
								},
							},
							["count"] = 6,
							["amount"] = 4648,
						},
						["射击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["冰锥术"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1156,
									["min"] = 1104,
									["count"] = 3,
									["amount"] = 3381,
								},
								["Hit"] = {
									["max"] = 576,
									["min"] = 537,
									["count"] = 11,
									["amount"] = 6095,
								},
							},
							["count"] = 14,
							["amount"] = 9476,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 35.97,
					["TimeDamaging"] = {
						["骷髅狂战士"] = {
							["Details"] = {
								["射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 3.15,
								},
							},
							["amount"] = 3.15,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 5.26,
								},
								["冰霜新星"] = {
									["count"] = 0.28,
								},
								["冰锥术"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 7.04,
						},
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 3.21,
								},
							},
							["amount"] = 3.21,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 8.54,
								},
							},
							["amount"] = 8.54,
						},
						["缝补憎恶"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 3.51,
								},
								["寒冰箭"] = {
									["count"] = 9,
								},
								["冰霜新星"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 14.01,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0.02,
								},
							},
							["amount"] = 0.02,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight4"] = {
					["DOTs"] = {
						["暴风雪 (伤害/跳)"] = {
							["Details"] = {
								["被撕裂的死尸"] = {
									["count"] = 0,
								},
								["恶疫食尸鬼"] = {
									["count"] = 0,
								},
								["缝补憎恶"] = {
									["count"] = 0,
								},
								["被毁坏的死尸"] = {
									["count"] = 0,
								},
								["破碎的死尸"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Arcane"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Frost"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
								["Tick"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 78,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Arcane"] = 78,
						["Frost"] = 0,
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
						["骷髅狂战士"] = {
							["Details"] = {
								["射击"] = {
									["count"] = 78,
								},
							},
							["amount"] = 78,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["缝补憎恶"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["寒冰箭"] = {
									["count"] = 0,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["骷髅狂战士"] = {
							["Details"] = {
								["射击"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["缝补憎恶"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["寒冰箭"] = {
									["count"] = 0,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 1.5,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["暴风雪 (伤害/跳)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["寒冰箭"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["射击"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 78,
									["min"] = 78,
									["count"] = 1,
									["amount"] = 78,
								},
							},
							["count"] = 1,
							["amount"] = 78,
						},
						["冰霜新星"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 1.5,
					["TimeDamaging"] = {
						["骷髅狂战士"] = {
							["Details"] = {
								["射击"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["缝补憎恶"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
								["寒冰箭"] = {
									["count"] = 0,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["TimeHealing"] = {
						["红莲业火丶"] = {
							["Details"] = {
								["防护冰霜结界"] = {
									["count"] = 0,
								},
								["寒冰护体"] = {
									["count"] = 4.5,
								},
							},
							["amount"] = 4.5,
						},
					},
					["DOTs"] = {
						["暴风雪 (伤害/跳)"] = {
							["Details"] = {
								["骷髅狂战士"] = {
									["count"] = 456,
								},
								["被撕裂的死尸"] = {
									["count"] = 963,
								},
								["恶疫食尸鬼"] = {
									["count"] = 456,
								},
								["破碎的死尸"] = {
									["count"] = 36,
								},
								["被毁坏的死尸"] = {
									["count"] = 900,
								},
								["骷髅守护者"] = {
									["count"] = 537,
								},
							},
							["amount"] = 3348,
						},
					},
					["TimeSpent"] = {
						["骷髅狂战士"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0.06,
								},
								["冰锥术"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.56,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 1.48,
								},
							},
							["amount"] = 1.48,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 3.14,
								},
								["寒冰箭"] = {
									["count"] = 0,
								},
								["冰霜新星"] = {
									["count"] = 0.65,
								},
							},
							["amount"] = 3.79,
						},
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 1.99,
								},
							},
							["amount"] = 1.99,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 25.12,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
							},
							["amount"] = 25.12,
						},
						["红莲业火丶"] = {
							["Details"] = {
								["防护冰霜结界"] = {
									["count"] = 0,
								},
								["寒冰护体"] = {
									["count"] = 4.5,
								},
							},
							["amount"] = 4.5,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 4.97,
								},
							},
							["amount"] = 4.97,
						},
					},
					["HealedWho"] = {
						["红莲业火丶"] = {
							["Details"] = {
								["防护冰霜结界"] = {
									["count"] = 0,
								},
								["寒冰护体"] = {
									["count"] = 395,
								},
							},
							["amount"] = 395,
						},
					},
					["ManaGainedFrom"] = {
						["红莲业火丶"] = {
							["Details"] = {
								["魔法吸收"] = {
									["count"] = 353,
								},
							},
							["amount"] = 353,
						},
					},
					["Absorbs"] = 395,
					["ManaGained"] = {
						["魔法吸收"] = {
							["Details"] = {
								["红莲业火丶"] = {
									["count"] = 353,
								},
							},
							["amount"] = 353,
						},
					},
					["ElementTakenAbsorb"] = {
						["Shadow"] = 314,
						["Frost"] = 0,
						["Melee"] = 0,
						["Arcane"] = 81,
					},
					["ActiveTime"] = 43.41,
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 1116,
								},
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 18,
								},
							},
							["amount"] = 1136,
						},
					},
					["ElementTaken"] = {
						["Shadow"] = 314,
						["Frost"] = 0,
						["Melee"] = 0,
						["Arcane"] = 81,
					},
					["DOT_Time"] = 3348,
					["Damage"] = 199153,
					["ElementHitsTaken"] = {
						["Shadow"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 1,
								},
								["Absorb"] = {
									["count"] = 2,
								},
							},
							["amount"] = 3,
						},
						["Frost"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Arcane"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["TimeHeal"] = 4.5,
					["PartialAbsorb"] = {
						["奥术箭"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 81,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 81,
								},
							},
							["count"] = 1,
							["amount"] = 81,
						},
						["寒冰箭"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["暗影箭"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
								["被吸收"] = {
									["max"] = 189,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 314,
								},
							},
							["count"] = 3,
							["amount"] = 314,
						},
						["肉搏"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["PartialResist"] = {
						["奥术箭"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
						["寒冰箭"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["暗影箭"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 3,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
					},
					["WhoDamaged"] = {
						["被撕裂的死尸"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["奥术箭"] = {
									["count"] = 81,
								},
								["寒冰箭"] = {
									["count"] = 0,
								},
								["暗影箭"] = {
									["count"] = 314,
								},
							},
							["amount"] = 395,
						},
					},
					["DamageTaken"] = 395,
					["WhoHealed"] = {
						["红莲业火丶"] = {
							["Details"] = {
								["防护冰霜结界"] = {
									["count"] = 0,
								},
								["寒冰护体"] = {
									["count"] = 395,
								},
							},
							["amount"] = 395,
						},
					},
					["Heals"] = {
						["防护冰霜结界"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["寒冰护体"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 189,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 395,
								},
							},
							["count"] = 3,
							["amount"] = 395,
						},
					},
					["Attacks"] = {
						["暴风雪 (伤害/跳)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 181,
									["min"] = 0,
									["count"] = 1116,
									["amount"] = 196363,
								},
							},
							["count"] = 1116,
							["amount"] = 196363,
						},
						["寒冰箭"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["冰锥术"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 576,
									["min"] = 547,
									["count"] = 4,
									["amount"] = 2246,
								},
							},
							["count"] = 4,
							["amount"] = 2246,
						},
						["冰霜新星"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 61,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 119,
								},
								["Hit"] = {
									["max"] = 31,
									["min"] = 0,
									["count"] = 14,
									["amount"] = 425,
								},
							},
							["count"] = 16,
							["amount"] = 544,
						},
					},
					["HealingTaken"] = 395,
					["DamagedWho"] = {
						["骷髅狂战士"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 27155,
								},
								["冰锥术"] = {
									["count"] = 1136,
								},
							},
							["amount"] = 28291,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 56209,
								},
								["冰霜新星"] = {
									["count"] = 245,
								},
							},
							["amount"] = 56454,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 26567,
								},
								["寒冰箭"] = {
									["count"] = 0,
								},
								["冰霜新星"] = {
									["count"] = 61,
								},
							},
							["amount"] = 26628,
						},
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 2072,
								},
							},
							["amount"] = 2072,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 52528,
								},
								["冰锥术"] = {
									["count"] = 1110,
								},
								["冰霜新星"] = {
									["count"] = 238,
								},
							},
							["amount"] = 53876,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 31832,
								},
							},
							["amount"] = 31832,
						},
					},
					["TimeDamage"] = 38.91,
					["TimeDamaging"] = {
						["骷髅狂战士"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0.06,
								},
								["冰锥术"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.56,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 1.48,
								},
							},
							["amount"] = 1.48,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 3.14,
								},
								["寒冰箭"] = {
									["count"] = 0,
								},
								["冰霜新星"] = {
									["count"] = 0.65,
								},
							},
							["amount"] = 3.79,
						},
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 1.99,
								},
							},
							["amount"] = 1.99,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 25.12,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
							},
							["amount"] = 25.12,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 4.97,
								},
							},
							["amount"] = 4.97,
						},
					},
					["ManaGain"] = 353,
					["ElementDone"] = {
						["Frost"] = 199153,
					},
					["Absorbed"] = {
						["防护冰霜结界"] = {
							["Details"] = {
								["红莲业火丶"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["寒冰护体"] = {
							["Details"] = {
								["红莲业火丶"] = {
									["max"] = 189,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 395,
								},
							},
							["count"] = 3,
							["amount"] = 395,
						},
					},
				},
				["Fight1"] = {
					["TimeHealing"] = {
						["红莲业火丶"] = {
							["Details"] = {
								["防护冰霜结界"] = {
									["count"] = 0,
								},
								["寒冰护体"] = {
									["count"] = 4.5,
								},
							},
							["amount"] = 4.5,
						},
					},
					["DOTs"] = {
						["暴风雪 (伤害/跳)"] = {
							["Details"] = {
								["骷髅狂战士"] = {
									["count"] = 456,
								},
								["被撕裂的死尸"] = {
									["count"] = 963,
								},
								["恶疫食尸鬼"] = {
									["count"] = 456,
								},
								["破碎的死尸"] = {
									["count"] = 36,
								},
								["被毁坏的死尸"] = {
									["count"] = 900,
								},
								["骷髅守护者"] = {
									["count"] = 537,
								},
							},
							["amount"] = 3348,
						},
					},
					["TimeSpent"] = {
						["骷髅狂战士"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0.06,
								},
								["冰锥术"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.56,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 1.48,
								},
							},
							["amount"] = 1.48,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 3.14,
								},
								["寒冰箭"] = {
									["count"] = 0,
								},
								["冰霜新星"] = {
									["count"] = 0.65,
								},
							},
							["amount"] = 3.79,
						},
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 1.99,
								},
							},
							["amount"] = 1.99,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 25.12,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
							},
							["amount"] = 25.12,
						},
						["红莲业火丶"] = {
							["Details"] = {
								["防护冰霜结界"] = {
									["count"] = 0,
								},
								["寒冰护体"] = {
									["count"] = 4.5,
								},
							},
							["amount"] = 4.5,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 4.97,
								},
							},
							["amount"] = 4.97,
						},
					},
					["HealedWho"] = {
						["红莲业火丶"] = {
							["Details"] = {
								["防护冰霜结界"] = {
									["count"] = 0,
								},
								["寒冰护体"] = {
									["count"] = 395,
								},
							},
							["amount"] = 395,
						},
					},
					["ManaGainedFrom"] = {
						["红莲业火丶"] = {
							["Details"] = {
								["魔法吸收"] = {
									["count"] = 353,
								},
							},
							["amount"] = 353,
						},
					},
					["Absorbs"] = 395,
					["ManaGained"] = {
						["魔法吸收"] = {
							["Details"] = {
								["红莲业火丶"] = {
									["count"] = 353,
								},
							},
							["amount"] = 353,
						},
					},
					["ElementTakenAbsorb"] = {
						["Shadow"] = 314,
						["Frost"] = 0,
						["Melee"] = 0,
						["Arcane"] = 81,
					},
					["ActiveTime"] = 43.41,
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 1116,
								},
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 18,
								},
							},
							["amount"] = 1136,
						},
					},
					["ElementTaken"] = {
						["Shadow"] = 314,
						["Frost"] = 0,
						["Melee"] = 0,
						["Arcane"] = 81,
					},
					["DOT_Time"] = 3348,
					["Damage"] = 199153,
					["ElementHitsTaken"] = {
						["Shadow"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 1,
								},
								["Absorb"] = {
									["count"] = 2,
								},
							},
							["amount"] = 3,
						},
						["Frost"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Arcane"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["TimeHeal"] = 4.5,
					["PartialAbsorb"] = {
						["奥术箭"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 81,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 81,
								},
							},
							["count"] = 1,
							["amount"] = 81,
						},
						["寒冰箭"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["暗影箭"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
								["被吸收"] = {
									["max"] = 189,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 314,
								},
							},
							["count"] = 3,
							["amount"] = 314,
						},
						["肉搏"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["PartialResist"] = {
						["奥术箭"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
						["寒冰箭"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["暗影箭"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 3,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
					},
					["WhoDamaged"] = {
						["被撕裂的死尸"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["奥术箭"] = {
									["count"] = 81,
								},
								["寒冰箭"] = {
									["count"] = 0,
								},
								["暗影箭"] = {
									["count"] = 314,
								},
							},
							["amount"] = 395,
						},
					},
					["DamageTaken"] = 395,
					["WhoHealed"] = {
						["红莲业火丶"] = {
							["Details"] = {
								["防护冰霜结界"] = {
									["count"] = 0,
								},
								["寒冰护体"] = {
									["count"] = 395,
								},
							},
							["amount"] = 395,
						},
					},
					["Heals"] = {
						["防护冰霜结界"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["寒冰护体"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 189,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 395,
								},
							},
							["count"] = 3,
							["amount"] = 395,
						},
					},
					["Attacks"] = {
						["暴风雪 (伤害/跳)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 181,
									["min"] = 0,
									["count"] = 1116,
									["amount"] = 196363,
								},
							},
							["count"] = 1116,
							["amount"] = 196363,
						},
						["寒冰箭"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["冰锥术"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 576,
									["min"] = 547,
									["count"] = 4,
									["amount"] = 2246,
								},
							},
							["count"] = 4,
							["amount"] = 2246,
						},
						["冰霜新星"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 61,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 119,
								},
								["Hit"] = {
									["max"] = 31,
									["min"] = 0,
									["count"] = 14,
									["amount"] = 425,
								},
							},
							["count"] = 16,
							["amount"] = 544,
						},
					},
					["HealingTaken"] = 395,
					["DamagedWho"] = {
						["骷髅狂战士"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 27155,
								},
								["冰锥术"] = {
									["count"] = 1136,
								},
							},
							["amount"] = 28291,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 56209,
								},
								["冰霜新星"] = {
									["count"] = 245,
								},
							},
							["amount"] = 56454,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 26567,
								},
								["寒冰箭"] = {
									["count"] = 0,
								},
								["冰霜新星"] = {
									["count"] = 61,
								},
							},
							["amount"] = 26628,
						},
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 2072,
								},
							},
							["amount"] = 2072,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 52528,
								},
								["冰锥术"] = {
									["count"] = 1110,
								},
								["冰霜新星"] = {
									["count"] = 238,
								},
							},
							["amount"] = 53876,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 31832,
								},
							},
							["amount"] = 31832,
						},
					},
					["TimeDamage"] = 38.91,
					["TimeDamaging"] = {
						["骷髅狂战士"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 0.06,
								},
								["冰锥术"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.56,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 1.48,
								},
							},
							["amount"] = 1.48,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 3.14,
								},
								["寒冰箭"] = {
									["count"] = 0,
								},
								["冰霜新星"] = {
									["count"] = 0.65,
								},
							},
							["amount"] = 3.79,
						},
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 1.99,
								},
							},
							["amount"] = 1.99,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 25.12,
								},
								["冰霜新星"] = {
									["count"] = 0,
								},
							},
							["amount"] = 25.12,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 4.97,
								},
							},
							["amount"] = 4.97,
						},
					},
					["ManaGain"] = 353,
					["ElementDone"] = {
						["Frost"] = 199153,
					},
					["Absorbed"] = {
						["防护冰霜结界"] = {
							["Details"] = {
								["红莲业火丶"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["寒冰护体"] = {
							["Details"] = {
								["红莲业火丶"] = {
									["max"] = 189,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 395,
								},
							},
							["count"] = 3,
							["amount"] = 395,
						},
					},
				},
				["OverallData"] = {
					["TimeHealing"] = {
						["红莲业火丶"] = {
							["Details"] = {
								["防护冰霜结界"] = {
									["count"] = 4.8,
								},
								["寒冰护体"] = {
									["count"] = 19.93,
								},
							},
							["amount"] = 24.73,
						},
					},
					["DOTs"] = {
						["暴风雪 (伤害/跳)"] = {
							["Details"] = {
								["破碎的死尸"] = {
									["count"] = 210,
								},
								["被毁坏的死尸"] = {
									["count"] = 3480,
								},
								["骷髅守护者"] = {
									["count"] = 1605,
								},
								["骷髅狂战士"] = {
									["count"] = 1218,
								},
								["被撕裂的死尸"] = {
									["count"] = 3195,
								},
								["恶疫食尸鬼"] = {
									["count"] = 1452,
								},
								["缝补憎恶"] = {
									["count"] = 351,
								},
								["幽灵市民"] = {
									["count"] = 72,
								},
								["鬼魂市民"] = {
									["count"] = 42,
								},
							},
							["amount"] = 11625,
						},
					},
					["ElementDoneResist"] = {
						["Frost"] = 2400,
					},
					["TimeSpent"] = {
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 15.26,
								},
							},
							["amount"] = 15.26,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 110.26,
								},
								["冰锥术"] = {
									["count"] = 0.37,
								},
								["冰霜新星"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 112.13,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 13.17,
								},
							},
							["amount"] = 13.17,
						},
						["骷髅狂战士"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 2.81,
								},
								["射击"] = {
									["count"] = 3,
								},
								["冰锥术"] = {
									["count"] = 4.07,
								},
							},
							["amount"] = 9.88,
						},
						["红莲业火丶"] = {
							["Details"] = {
								["防护冰霜结界"] = {
									["count"] = 4.8,
								},
								["寒冰护体"] = {
									["count"] = 19.93,
								},
							},
							["amount"] = 24.73,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 28.03,
								},
								["寒冰箭"] = {
									["count"] = 1.5,
								},
								["冰锥术"] = {
									["count"] = 1.5,
								},
								["冰霜新星"] = {
									["count"] = 3.33,
								},
							},
							["amount"] = 34.36,
						},
						["缝补憎恶"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 22.58,
								},
								["冰霜新星"] = {
									["count"] = 6.08,
								},
								["寒冰箭"] = {
									["count"] = 28.5,
								},
								["冰锥术"] = {
									["count"] = 0.29,
								},
								["火焰冲击"] = {
									["count"] = 0.17,
								},
							},
							["amount"] = 57.62,
						},
						["幽灵市民"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 1.61,
								},
							},
							["amount"] = 1.61,
						},
						["鬼魂市民"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 3.09,
								},
								["寒冰箭"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 4.59,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 44.52,
								},
							},
							["amount"] = 44.52,
						},
					},
					["HealedWho"] = {
						["红莲业火丶"] = {
							["Details"] = {
								["防护冰霜结界"] = {
									["count"] = 542,
								},
								["寒冰护体"] = {
									["count"] = 3106,
								},
							},
							["amount"] = 3648,
						},
					},
					["ManaGainedFrom"] = {
						["红莲业火丶"] = {
							["Details"] = {
								["魔法吸收"] = {
									["count"] = 1766,
								},
							},
							["amount"] = 1766,
						},
					},
					["Absorbs"] = 3648,
					["ManaGained"] = {
						["魔法吸收"] = {
							["Details"] = {
								["红莲业火丶"] = {
									["count"] = 1766,
								},
							},
							["amount"] = 1766,
						},
					},
					["ElementTakenAbsorb"] = {
						["Frost"] = 911,
						["Melee"] = 360,
						["Arcane"] = 124,
						["Physical"] = 724,
						["Shadow"] = 1529,
					},
					["ActiveTime"] = 317.87,
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 1,
								},
								["Tick"] = {
									["count"] = 3875,
								},
								["Crit"] = {
									["count"] = 17,
								},
								["Hit"] = {
									["count"] = 151,
								},
							},
							["amount"] = 4044,
						},
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Arcane"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 2,
						},
					},
					["ElementTaken"] = {
						["Frost"] = 911,
						["Melee"] = 1781,
						["Arcane"] = 124,
						["Physical"] = 47,
						["Shadow"] = 1575,
					},
					["DOT_Time"] = 11625,
					["Damage"] = 730880,
					["ElementHitsTaken"] = {
						["Frost"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 2,
								},
								["Absorb"] = {
									["count"] = 10,
								},
								["Reflect"] = {
									["count"] = 1,
								},
								["Immune"] = {
									["count"] = 1,
								},
							},
							["amount"] = 14,
						},
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 4,
								},
								["Hit"] = {
									["count"] = 1,
								},
								["Immune"] = {
									["count"] = 165,
								},
								["Crit"] = {
									["count"] = 1,
								},
								["Miss"] = {
									["count"] = 25,
								},
							},
							["amount"] = 196,
						},
						["Arcane"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Shadow"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 3,
								},
								["Absorb"] = {
									["count"] = 10,
								},
								["Immune"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 15,
						},
						["Nature"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["TimeHeal"] = 24.73,
					["PartialAbsorb"] = {
						["奥术箭"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 81,
									["min"] = 43,
									["count"] = 2,
									["amount"] = 124,
								},
							},
							["count"] = 2,
							["amount"] = 124,
						},
						["暗影箭"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
								["被吸收"] = {
									["max"] = 189,
									["min"] = 62,
									["count"] = 11,
									["amount"] = 1529,
								},
							},
							["count"] = 14,
							["amount"] = 1529,
						},
						["击退"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 724,
									["min"] = 724,
									["count"] = 1,
									["amount"] = 724,
								},
							},
							["count"] = 1,
							["amount"] = 724,
						},
						["暗影迷雾"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["寒冰箭"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
								["被吸收"] = {
									["max"] = 116,
									["min"] = 80,
									["count"] = 10,
									["amount"] = 911,
								},
							},
							["count"] = 14,
							["amount"] = 911,
						},
						["疾病之云"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 302,
									["min"] = 58,
									["count"] = 2,
									["amount"] = 360,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 194,
									["amount"] = 0,
								},
							},
							["count"] = 196,
							["amount"] = 360,
						},
					},
					["PartialResist"] = {
						["奥术箭"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 2,
						},
						["暗影箭"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 14,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 14,
						},
						["击退"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
						["暗影迷雾"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
						["寒冰箭"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 14,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 14,
						},
						["疾病之云"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 3,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 196,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 196,
						},
					},
					["WhoDamaged"] = {
						["缝补憎恶"] = {
							["Details"] = {
								["击退"] = {
									["count"] = 47,
								},
								["肉搏"] = {
									["count"] = 724,
								},
							},
							["amount"] = 771,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 995,
								},
							},
							["amount"] = 995,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["奥术箭"] = {
									["count"] = 124,
								},
								["寒冰箭"] = {
									["count"] = 911,
								},
								["暗影箭"] = {
									["count"] = 1575,
								},
								["肉搏"] = {
									["count"] = 62,
								},
							},
							["amount"] = 2672,
						},
					},
					["DamageTaken"] = 4438,
					["WhoHealed"] = {
						["红莲业火丶"] = {
							["Details"] = {
								["防护冰霜结界"] = {
									["count"] = 542,
								},
								["寒冰护体"] = {
									["count"] = 3106,
								},
							},
							["amount"] = 3648,
						},
					},
					["Heals"] = {
						["防护冰霜结界"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 116,
									["min"] = 80,
									["count"] = 6,
									["amount"] = 542,
								},
							},
							["count"] = 6,
							["amount"] = 542,
						},
						["寒冰护体"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 724,
									["min"] = 43,
									["count"] = 20,
									["amount"] = 3106,
								},
							},
							["count"] = 20,
							["amount"] = 3106,
						},
					},
					["Attacks"] = {
						["暴风雪 (伤害/跳)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 181,
									["min"] = 41,
									["count"] = 3875,
									["amount"] = 673927,
								},
							},
							["count"] = 3875,
							["amount"] = 673927,
						},
						["冰霜新星"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 67,
									["min"] = 58,
									["count"] = 7,
									["amount"] = 422,
								},
								["Hit"] = {
									["max"] = 35,
									["min"] = 29,
									["count"] = 86,
									["amount"] = 2636,
								},
							},
							["count"] = 93,
							["amount"] = 3058,
						},
						["射击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 85,
									["min"] = 85,
									["count"] = 1,
									["amount"] = 85,
								},
								["Hit"] = {
									["max"] = 78,
									["min"] = 78,
									["count"] = 1,
									["amount"] = 78,
								},
							},
							["count"] = 2,
							["amount"] = 163,
						},
						["寒冰箭"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1864,
									["min"] = 1512,
									["count"] = 3,
									["amount"] = 4890,
								},
								["Hit"] = {
									["max"] = 921,
									["min"] = 758,
									["count"] = 18,
									["amount"] = 14077,
								},
							},
							["count"] = 21,
							["amount"] = 18967,
						},
						["火焰冲击"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 660,
									["min"] = 660,
									["count"] = 1,
									["amount"] = 660,
								},
							},
							["count"] = 1,
							["amount"] = 660,
						},
						["冰锥术"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 1156,
									["min"] = 1074,
									["count"] = 7,
									["amount"] = 7797,
								},
								["Hit"] = {
									["max"] = 581,
									["min"] = 537,
									["count"] = 47,
									["amount"] = 26308,
								},
							},
							["count"] = 55,
							["amount"] = 34105,
						},
					},
					["HealingTaken"] = 3648,
					["DamagedWho"] = {
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 12036,
								},
								["冰霜新星"] = {
									["count"] = 30,
								},
							},
							["amount"] = 12066,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 202082,
								},
								["冰锥术"] = {
									["count"] = 13975,
								},
								["冰霜新星"] = {
									["count"] = 1174,
								},
							},
							["amount"] = 217231,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 94376,
								},
							},
							["amount"] = 94376,
						},
						["骷髅狂战士"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 72060,
								},
								["射击"] = {
									["count"] = 163,
								},
								["冰霜新星"] = {
									["count"] = 133,
								},
								["冰锥术"] = {
									["count"] = 3980,
								},
							},
							["amount"] = 76336,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 185242,
								},
								["冰锥术"] = {
									["count"] = 13366,
								},
								["冰霜新星"] = {
									["count"] = 953,
								},
							},
							["amount"] = 199561,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 84086,
								},
								["寒冰箭"] = {
									["count"] = 777,
								},
								["冰锥术"] = {
									["count"] = 2219,
								},
								["冰霜新星"] = {
									["count"] = 493,
								},
							},
							["amount"] = 87575,
						},
						["缝补憎恶"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 19801,
								},
								["冰霜新星"] = {
									["count"] = 244,
								},
								["寒冰箭"] = {
									["count"] = 17415,
								},
								["冰锥术"] = {
									["count"] = 565,
								},
								["火焰冲击"] = {
									["count"] = 660,
								},
							},
							["amount"] = 38685,
						},
						["幽灵市民"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 2647,
								},
							},
							["amount"] = 2647,
						},
						["鬼魂市民"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 1597,
								},
								["寒冰箭"] = {
									["count"] = 775,
								},
								["冰霜新星"] = {
									["count"] = 31,
								},
							},
							["amount"] = 2403,
						},
					},
					["TimeDamage"] = 293.14,
					["TimeDamaging"] = {
						["破碎的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 15.26,
								},
							},
							["amount"] = 15.26,
						},
						["被毁坏的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 110.26,
								},
								["冰锥术"] = {
									["count"] = 0.37,
								},
								["冰霜新星"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 112.13,
						},
						["骷髅守护者"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 13.17,
								},
							},
							["amount"] = 13.17,
						},
						["骷髅狂战士"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 2.81,
								},
								["射击"] = {
									["count"] = 3,
								},
								["冰锥术"] = {
									["count"] = 4.07,
								},
							},
							["amount"] = 9.88,
						},
						["被撕裂的死尸"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 44.52,
								},
							},
							["amount"] = 44.52,
						},
						["恶疫食尸鬼"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 28.03,
								},
								["寒冰箭"] = {
									["count"] = 1.5,
								},
								["冰锥术"] = {
									["count"] = 1.5,
								},
								["冰霜新星"] = {
									["count"] = 3.33,
								},
							},
							["amount"] = 34.36,
						},
						["缝补憎恶"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 22.58,
								},
								["冰霜新星"] = {
									["count"] = 6.08,
								},
								["寒冰箭"] = {
									["count"] = 28.5,
								},
								["冰锥术"] = {
									["count"] = 0.29,
								},
								["火焰冲击"] = {
									["count"] = 0.17,
								},
							},
							["amount"] = 57.62,
						},
						["幽灵市民"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 1.61,
								},
							},
							["amount"] = 1.61,
						},
						["鬼魂市民"] = {
							["Details"] = {
								["暴风雪 (伤害/跳)"] = {
									["count"] = 3.09,
								},
								["寒冰箭"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 4.59,
						},
					},
					["ManaGain"] = 1766,
					["ElementDone"] = {
						["Frost"] = 730057,
						["Fire"] = 660,
						["Arcane"] = 163,
					},
					["Absorbed"] = {
						["防护冰霜结界"] = {
							["Details"] = {
								["红莲业火丶"] = {
									["max"] = 116,
									["min"] = 80,
									["count"] = 6,
									["amount"] = 542,
								},
							},
							["count"] = 6,
							["amount"] = 542,
						},
						["寒冰护体"] = {
							["Details"] = {
								["红莲业火丶"] = {
									["max"] = 724,
									["min"] = 43,
									["count"] = 20,
									["amount"] = 3106,
								},
							},
							["count"] = 20,
							["amount"] = 3106,
						},
					},
				},
			},
			["UnitLockout"] = 50697.218,
			["LastActive"] = 51205.212,
		},
		["三聚氰胺"] = {
			["GUID"] = "Player-4829-024FB79B",
			["LastEventHealth"] = {
				1378, -- [1]
				1927, -- [2]
				1927, -- [3]
				1927, -- [4]
				1927, -- [5]
				1927, -- [6]
				1927, -- [7]
				1927, -- [8]
				1927, -- [9]
				1927, -- [10]
				1927, -- [11]
			},
			["LastEventType"] = {
				"HEAL", -- [1]
				"HEAL", -- [2]
				"HEAL", -- [3]
				"HEAL", -- [4]
				"HEAL", -- [5]
				"HEAL", -- [6]
				"HEAL", -- [7]
				"HEAL", -- [8]
				"HEAL", -- [9]
				"HEAL", -- [10]
				"HEAL", -- [11]
			},
			["TimeWindows"] = {
				["Healing"] = {
					27, -- [1]
				},
				["TimeHeal"] = {
					1.5, -- [1]
				},
				["HOT_Time"] = {
					3, -- [1]
				},
				["ActiveTime"] = {
					1.5, -- [1]
				},
			},
			["enClass"] = "PRIEST",
			["unit"] = "三聚氰胺",
			["level"] = 55,
			["LastFightIn"] = 5,
			["type"] = "Self",
			["FightsSaved"] = 5,
			["TimeLast"] = {
				["TimeHeal"] = 49952.287,
				["HOT_Time"] = 49952.287,
				["ActiveTime"] = 49952.287,
				["OVERALL"] = 49952.287,
				["Healing"] = 49952.287,
			},
			["Owner"] = false,
			["LastHealTime"] = 49953.154,
			["NextEventNum"] = 12,
			["LastEventHealthMax"] = {
				1927, -- [1]
				1927, -- [2]
				1927, -- [3]
				1927, -- [4]
				1927, -- [5]
				1927, -- [6]
				1927, -- [7]
				1927, -- [8]
				1927, -- [9]
				1927, -- [10]
				1927, -- [11]
			},
			["LastEvents"] = {
				"三聚氰胺 快速治疗 三聚氰胺 Hit +777 (228 过量治疗)", -- [1]
				"三聚氰胺 恢复 蜂花护发素 Tick +27", -- [2]
				"三聚氰胺 恢复 红莲业火丶 Tick +27", -- [3]
				"三聚氰胺 恢复 蜂花护发素 Tick +27", -- [4]
				"三聚氰胺 恢复 红莲业火丶 Tick +27", -- [5]
				"三聚氰胺 恢复 蜂花护发素 Tick +27", -- [6]
				"三聚氰胺 恢复 红莲业火丶 Tick +27", -- [7]
				"三聚氰胺 恢复 蜂花护发素 Tick +27", -- [8]
				"三聚氰胺 恢复 红莲业火丶 Tick +27", -- [9]
				"三聚氰胺 恢复 蜂花护发素 Tick +27", -- [10]
				"三聚氰胺 恢复 红莲业火丶 Tick +27", -- [11]
			},
			["Name"] = "三聚氰胺",
			["LastEventIncoming"] = {
				true, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				false, -- [6]
				false, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				false, -- [11]
			},
			["LastEventTimes"] = {
				49044.163, -- [1]
				49953.154, -- [2]
				49955.988, -- [3]
				49956.153, -- [4]
				49958.988, -- [5]
				49959.154, -- [6]
				49961.97, -- [7]
				49962.156, -- [8]
				49964.986, -- [9]
				49965.141, -- [10]
				49967.986, -- [11]
			},
			["Fights"] = {
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["TimeHealing"] = {
						["蜂花护发素"] = {
							["Details"] = {
								["恢复"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
					},
					["TimeSpent"] = {
						["蜂花护发素"] = {
							["Details"] = {
								["恢复"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
					},
					["HealedWho"] = {
						["蜂花护发素"] = {
							["Details"] = {
								["恢复"] = {
									["count"] = 27,
								},
							},
							["amount"] = 27,
						},
					},
					["HOT_Time"] = 3,
					["ActiveTime"] = 1.5,
					["Heals"] = {
						["恢复"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 27,
									["min"] = 27,
									["count"] = 1,
									["amount"] = 27,
								},
							},
							["count"] = 1,
							["amount"] = 27,
						},
					},
					["TimeHeal"] = 1.5,
					["HOTs"] = {
						["恢复"] = {
							["Details"] = {
								["蜂花护发素"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["Healing"] = 27,
				},
			},
			["UnitLockout"] = 49044.063,
			["LastActive"] = 49967.287,
		},
	},
	["FightNum"] = 13,
	["CombatTimes"] = {
		{
			49156.075, -- [1]
			49224.073, -- [2]
			"21:34:59", -- [3]
			"21:36:07", -- [4]
			"被毁坏的死尸", -- [5]
		}, -- [1]
		{
			49378.065, -- [1]
			49451.063, -- [2]
			"21:38:41", -- [3]
			"21:39:54", -- [4]
			"被撕裂的死尸", -- [5]
		}, -- [2]
		{
			49661.068, -- [1]
			49693.067, -- [2]
			"21:43:25", -- [3]
			"21:43:56", -- [4]
			"被撕裂的死尸", -- [5]
		}, -- [3]
		{
			49702.064, -- [1]
			49730.065, -- [2]
			"21:44:06", -- [3]
			"21:44:33", -- [4]
			"被毁坏的死尸", -- [5]
		}, -- [4]
		{
			49853.311, -- [1]
			49859.312, -- [2]
			"21:46:36", -- [3]
			"21:46:42", -- [4]
			"骷髅狂战士", -- [5]
		}, -- [5]
		{
			49894.289, -- [1]
			49953.288, -- [2]
			"21:47:17", -- [3]
			"21:48:16", -- [4]
			"骷髅守护者", -- [5]
		}, -- [6]
		{
			50198.291, -- [1]
			50204.293, -- [2]
			"21:52:21", -- [3]
			"21:52:27", -- [4]
			"破碎的死尸", -- [5]
		}, -- [7]
		{
			50456.298, -- [1]
			50533.293, -- [2]
			"21:56:39", -- [3]
			"21:57:56", -- [4]
			"骷髅狂战士", -- [5]
		}, -- [8]
		{
			50625.998, -- [1]
			50643.219, -- [2]
			"21:59:33", -- [3]
			"21:59:46", -- [4]
			"骷髅守护者", -- [5]
		}, -- [9]
		{
			50697.218, -- [1]
			50703.216, -- [2]
			"22:00:41", -- [3]
			"22:00:46", -- [4]
			"骷髅狂战士", -- [5]
		}, -- [10]
		{
			50741.215, -- [1]
			50798.214, -- [2]
			"22:01:24", -- [3]
			"22:02:21", -- [4]
			"骷髅守护者", -- [5]
		}, -- [11]
		{
			50949.223, -- [1]
			50971.223, -- [2]
			"22:04:53", -- [3]
			"22:05:14", -- [4]
			"被毁坏的死尸", -- [5]
		}, -- [12]
		{
			51147.215, -- [1]
			51207.213, -- [2]
			"22:08:11", -- [3]
			"22:09:10", -- [4]
			"被撕裂的死尸", -- [5]
		}, -- [13]
	},
	["FoughtWho"] = {
		"被撕裂的死尸 22:08:11-22:09:10", -- [1]
		"被毁坏的死尸 22:04:53-22:05:14", -- [2]
		"骷髅守护者 22:01:24-22:02:21", -- [3]
		"骷髅狂战士 22:00:41-22:00:46", -- [4]
		"骷髅守护者 21:59:33-21:59:46", -- [5]
	},
}
