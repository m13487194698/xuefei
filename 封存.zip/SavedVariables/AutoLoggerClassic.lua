
ALCOptions = {
	["minimapTable"] = {
		["hide"] = true,
	},
	["instances"] = {
		[409] = true,
		[249] = true,
		[509] = true,
		[531] = true,
		[533] = true,
		[309] = true,
		[469] = true,
	},
}
