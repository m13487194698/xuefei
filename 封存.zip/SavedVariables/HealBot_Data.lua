
HealBot_Config = {
	["CrashProtStartTime"] = 2,
	["SkinDefault"] = {
		["[NGA]wking"] = {
			["Raid 10"] = false,
			["Solo"] = false,
			["BG 40"] = false,
			["Party"] = false,
			["BG 10"] = false,
			["Raid 25"] = false,
			["Raid 40"] = false,
			["Arena"] = false,
			["BG 15"] = false,
			["Pet Battle"] = false,
		},
		["Group"] = {
			["Raid 10"] = false,
			["Solo"] = false,
			["BG 40"] = false,
			["Party"] = false,
			["BG 10"] = false,
			["Pet Battle"] = false,
			["Raid 40"] = false,
			["Arena"] = false,
			["BG 15"] = false,
			["Raid 25"] = false,
		},
		["Standard"] = {
			["Raid 10"] = false,
			["Solo"] = false,
			["BG 40"] = false,
			["Party"] = false,
			["BG 10"] = false,
			["Pet Battle"] = false,
			["Raid 40"] = false,
			["Arena"] = false,
			["BG 15"] = false,
			["Raid 25"] = false,
		},
		["Raid 40"] = {
			["Raid 10"] = false,
			["Solo"] = false,
			["BG 40"] = false,
			["Party"] = false,
			["BG 10"] = false,
			["Pet Battle"] = false,
			["Raid 40"] = false,
			["Arena"] = false,
			["BG 15"] = false,
			["Raid 25"] = false,
		},
		["Raid 25"] = {
			["Raid 10"] = false,
			["Solo"] = false,
			["BG 40"] = false,
			["Party"] = false,
			["BG 10"] = false,
			["Pet Battle"] = false,
			["Raid 40"] = false,
			["Arena"] = false,
			["BG 15"] = false,
			["Raid 25"] = false,
		},
	},
	["MyFriend"] = "x",
	["Skin_ID"] = -1,
	["AdjustMaxHealth"] = false,
	["LastVersionSkinUpdate"] = "8.3.0.3",
	["LastAutoSkinChangeTime"] = 21981.015,
	["MacroUse10"] = 0,
	["LastAutoSkinChangeType"] = "None",
	["Profile"] = 1,
	["BuffReset"] = "6.0.0",
	["EnableHealthy"] = true,
	["CurrentSpec"] = 1,
	["DisableSolo"] = false,
	["DisableHealBot"] = false,
	["CrashProtMacroName"] = "hbCrashProt",
	["DisabledNow"] = 0,
}
HealBot_Config_Spells = {
	["EnabledSpellTrinket2"] = {
	},
	["EnabledSpellTarget"] = {
		["Left1"] = true,
		["ShiftLeft1"] = true,
		["Right1"] = true,
		["CtrlLeft1"] = true,
		["AltRight1"] = true,
	},
	["EnemySpellTrinket1"] = {
	},
	["EnemyAvoidBlueCursor"] = {
	},
	["EnemySpellTrinket2"] = {
	},
	["EnemyKeyCombo"] = {
	},
	["DisabledKeyCombo"] = {
		["Alt-ShiftRight4"] = "C:B",
		["Alt-ShiftLeft2"] = "C:A",
		["Right1"] = "治疗术",
		["Right"] = "治疗术",
		["Left"] = "快速治疗",
		["Ctrl-ShiftRight"] = "C:E",
		["Middle"] = "恢复",
		["Middle1"] = "恢复",
		["Alt-ShiftLeft1"] = "C:A",
		["Left4"] = "快速治疗",
		["Ctrl-ShiftLeft2"] = "C:D",
		["Middle2"] = "恢复",
		["Ctrl-ShiftRight2"] = "C:E",
		["Ctrl-ShiftLeft4"] = "C:D",
		["Ctrl-ShiftLeft3"] = "C:D",
		["Alt-ShiftRight3"] = "C:B",
		["Right2"] = "治疗术",
		["Alt-ShiftLeft3"] = "C:A",
		["Left1"] = "快速治疗",
		["Alt-ShiftLeft"] = "C:A",
		["Middle4"] = "恢复",
		["Alt-ShiftRight1"] = "C:B",
		["Left3"] = "快速治疗",
		["Alt-ShiftLeft4"] = "C:A",
		["Ctrl-ShiftRight4"] = "C:E",
		["Left2"] = "快速治疗",
		["Ctrl-ShiftLeft"] = "C:D",
		["Alt-ShiftRight"] = "C:B",
		["Right4"] = "治疗术",
		["Middle3"] = "恢复",
		["Right3"] = "治疗术",
		["Alt-ShiftRight2"] = "C:B",
		["Ctrl-ShiftLeft1"] = "C:D",
		["Ctrl-ShiftRight1"] = "C:E",
		["Ctrl-ShiftRight3"] = "C:E",
	},
	["EnabledAvoidBlueCursor"] = {
	},
	["DisabledSpellTrinket1"] = {
	},
	["ButtonCastMethod"] = 2,
	["EnabledKeyCombo"] = {
		["Alt-ShiftRight4"] = "C:B",
		["Alt-ShiftMiddle2"] = "",
		["Alt-ShiftLeft2"] = "C:A",
		["Right1"] = "S:6064",
		["Right"] = "治疗术",
		["Alt-ShiftRight2"] = "C:B",
		["Alt-ShiftMiddle4"] = "",
		["Alt-CtrlLeft1"] = "",
		["Alt-ShiftMiddle1"] = "",
		["Middle"] = "恢复",
		["Middle1"] = "S:10929",
		["Alt-ShiftLeft1"] = "C:A",
		["Left4"] = "快速治疗",
		["Ctrl-ShiftLeft2"] = "C:D",
		["AltMiddle2"] = "治疗祷言",
		["Ctrl-ShiftRight2"] = "C:E",
		["Ctrl-ShiftLeft4"] = "C:D",
		["Ctrl-ShiftRight1"] = "C:E",
		["ShiftRight4"] = "次级治疗术",
		["AltRight1"] = "S:10965",
		["Alt-ShiftRight3"] = "C:B",
		["Right2"] = "治疗术",
		["AltMiddle1"] = "S:10961",
		["Alt-ShiftMiddle3"] = "",
		["Alt-ShiftLeft3"] = "C:A",
		["Alt-ShiftMiddle"] = "",
		["Alt-ShiftLeft"] = "C:A",
		["AltMiddle3"] = "治疗祷言",
		["AltMiddle"] = "治疗祷言",
		["Ctrl-ShiftLeft1"] = "C:D",
		["Middle3"] = "恢复",
		["Middle4"] = "恢复",
		["Ctrl-ShiftLeft3"] = "C:D",
		["Left"] = "快速治疗",
		["ShiftRight3"] = "次级治疗术",
		["Alt-ShiftRight1"] = "C:B",
		["CtrlLeft1"] = "",
		["Left1"] = "S:9473",
		["Right3"] = "治疗术",
		["Alt-ShiftLeft4"] = "C:A",
		["Ctrl-ShiftRight3"] = "C:E",
		["Ctrl-ShiftRight4"] = "C:E",
		["Left2"] = "快速治疗",
		["ShiftRight1"] = "S:2053",
		["ShiftRight"] = "次级治疗术",
		["Ctrl-ShiftLeft"] = "C:D",
		["Alt-ShiftRight"] = "C:B",
		["Middle2"] = "恢复",
		["Right4"] = "治疗术",
		["Left3"] = "快速治疗",
		["ShiftLeft1"] = "",
		["AltMiddle4"] = "治疗祷言",
		["Ctrl-ShiftRight"] = "C:E",
		["ShiftRight2"] = "次级治疗术",
		["AltLeft1"] = "S:10917",
		["Ctrl-ShiftMiddle1"] = "",
	},
	["DisabledAvoidBlueCursor"] = {
	},
	["DisabledSpellTrinket2"] = {
	},
	["DisabledSpellTarget"] = {
	},
	["EnemySpellTarget"] = {
	},
	["EnabledSpellTrinket1"] = {
	},
}
HealBot_Config_Buffs = {
	["HealBot_CBWarnRange_Screen"] = 2,
	["CBshownHB"] = true,
	["HealBot_CBWarnRange_Aggro"] = 2,
	["HealBotBuffColG"] = {
		1, -- [1]
		1, -- [2]
		1, -- [3]
		1, -- [4]
		1, -- [5]
		1, -- [6]
		1, -- [7]
		1, -- [8]
	},
	["BuffWatch"] = true,
	["ShortBuffTimer"] = 10,
	["ShowBuffWarning"] = false,
	["PalaBlessingsAsOne"] = false,
	["HealBot_CBWarnRange_Sound"] = 3,
	["LongBuffTimer"] = 120,
	["BuffWatchWhenGrouped"] = false,
	["SoundBuffPlay"] = "Tribal Bass Drum",
	["SoundBuffWarning"] = false,
	["NoAuraWhenRested"] = false,
	["HealBotBuffDropDown"] = {
		4, -- [1]
		4, -- [2]
		4, -- [3]
		4, -- [4]
		4, -- [5]
		4, -- [6]
		2, -- [7]
		2, -- [8]
		2, -- [9]
		["42"] = 4,
		["43"] = 4,
		["23"] = 4,
		["41"] = 4,
		["47"] = 2,
		["46"] = 4,
		["34"] = 4,
		["44"] = 4,
		["48"] = 2,
		["33"] = 4,
		["28"] = 2,
		["38"] = 2,
		["21"] = 4,
		["13"] = 4,
		["17"] = 2,
		["27"] = 2,
		["15"] = 2,
		["25"] = 4,
		["35"] = 4,
		["45"] = 4,
		["37"] = 2,
		["18"] = 2,
		["36"] = 4,
		["22"] = 4,
		["14"] = 4,
		["24"] = 4,
		["16"] = 2,
		["26"] = 4,
		["31"] = 4,
		["12"] = 4,
		["11"] = 4,
		["32"] = 4,
	},
	["BuffWatchInCombat"] = false,
	["CBshownAB"] = false,
	["HealBotBuffColR"] = {
		1, -- [1]
		1, -- [2]
		1, -- [3]
		1, -- [4]
		1, -- [5]
		1, -- [6]
		1, -- [7]
		1, -- [8]
	},
	["HealBotBuffText"] = {
		"空", -- [1]
		"空", -- [2]
		"空", -- [3]
		"空", -- [4]
		"空", -- [5]
		"空", -- [6]
		"空", -- [7]
		"空", -- [8]
		"空", -- [9]
		["42"] = "空",
		["43"] = "空",
		["23"] = "空",
		["41"] = "空",
		["47"] = "空",
		["46"] = "空",
		["34"] = "空",
		["44"] = "空",
		["48"] = "空",
		["33"] = "空",
		["28"] = "空",
		["38"] = "空",
		["21"] = "空",
		["13"] = "坚韧祷言",
		["17"] = "虚弱之触",
		["27"] = "空",
		["15"] = "防护暗影",
		["25"] = "空",
		["35"] = "空",
		["45"] = "空",
		["37"] = "空",
		["18"] = "空",
		["36"] = "空",
		["22"] = "空",
		["14"] = "精神祷言",
		["24"] = "空",
		["16"] = "心灵之火",
		["26"] = "空",
		["31"] = "空",
		["12"] = "神圣之灵",
		["11"] = "真言术：韧",
		["32"] = "空",
	},
	["HealBot_CBWarnRange_Bar"] = 3,
	["HealBotBuffColB"] = {
		1, -- [1]
		1, -- [2]
		1, -- [3]
		1, -- [4]
		1, -- [5]
		1, -- [6]
		1, -- [7]
		1, -- [8]
	},
}
HealBot_Config_Cures = {
	["CDCshownHB"] = true,
	["DebuffWatch"] = true,
	["HealBotDebuffText"] = {
		"空", -- [1]
		"空", -- [2]
		"空", -- [3]
		["42"] = "空",
		["43"] = "空",
		["41"] = "空",
		["23"] = "空",
		["33"] = "空",
		["12"] = "空",
		["13"] = "空",
		["22"] = "空",
		["31"] = "空",
		["21"] = "空",
		["11"] = "空",
		["32"] = "空",
	},
	["IgnoreFastDurDebuffs"] = true,
	["ShowDebuffWarning"] = true,
	["HealBot_CDCWarnRange_Screen"] = 2,
	["DebuffWatchInCombat"] = true,
	["HealBot_Custom_Defuffs_All"] = {
		["Poison"] = false,
		["Curse"] = false,
		["Magic"] = false,
		["Disease"] = false,
	},
	["HealBot_CDCWarnRange_Aggro"] = 2,
	["IgnoreFastDurDebuffsSecs"] = 2,
	["HealBot_CDCWarnRange_Bar"] = 3,
	["SoundDebuffPlay"] = "Tribal Bass Drum",
	["HealBot_CDCWarnRange_Sound"] = 3,
	["HealBotDebuffDropDown"] = {
		4, -- [1]
		4, -- [2]
		4, -- [3]
		["42"] = 4,
		["43"] = 4,
		["41"] = 4,
		["23"] = 4,
		["33"] = 4,
		["12"] = 4,
		["13"] = 4,
		["22"] = 4,
		["31"] = 4,
		["21"] = 4,
		["11"] = 4,
		["32"] = 4,
	},
	["SoundDebuffWarning"] = true,
	["CDCshownAB"] = false,
	["AlwaysShowBossStrict"] = true,
	["IgnoreFriendDebuffs"] = true,
	["IgnoreOnCooldownDebuffs"] = false,
	["DebuffWatchWhenGrouped"] = false,
	["CDCBarColour"] = {
		["Poison"] = {
			["B"] = 0.24,
			["G"] = 0.46,
			["R"] = 0.12,
		},
		["Curse"] = {
			["B"] = 0.09,
			["G"] = 0.43,
			["R"] = 0.83,
		},
		["Magic"] = {
			["B"] = 0.83,
			["G"] = 0.33,
			["R"] = 0.26,
		},
		["Disease"] = {
			["B"] = 0.7,
			["G"] = 0.19,
			["R"] = 0.55,
		},
	},
	["HealBotDebuffPriority"] = {
		["Disease"] = 7,
		["Custom"] = 10,
		["Poison"] = 8,
		["Magic"] = 5,
		["Curse"] = 6,
	},
	["AlwaysShowBoss"] = true,
}
