
ExAE_Config = {
	["仨聚氰胺@Enigma"] = {
		["CurrentSetId"] = 0,
	},
	["卅聚氰胺@Enigma"] = {
		["CurrentSetId"] = 0,
	},
	["三聚氰胺@Enigma"] = {
		["CurrentSetId"] = 0,
	},
}
