
CodexConfig = {
	["showUnitTooltip"] = true,
	["showHighLevel"] = true,
	["bossMarkerSize"] = 25,
	["showTrackingMethodDropdown"] = true,
	["autoAccept"] = false,
	["allQuestGivers"] = true,
	["trackingMethod"] = 1,
	["minimumDropChance"] = 2,
	["showLowLevel"] = false,
	["spawnMarkerSize"] = 10,
	["continentIcon"] = false,
	["currentQuestGivers"] = true,
	["showFestival"] = false,
	["alwaysShowId"] = false,
	["nameplateIcon"] = false,
	["colorBySpawn"] = true,
	["zoneMapIcon"] = true,
	["miniMapIcon"] = true,
	["autoTurnin"] = false,
	["minimapButton"] = true,
	["questMarkerSize"] = 14,
}
CodexHiddenQuests = {
}
CodexBrowserFavorites = {
	["objects"] = {
	},
	["items"] = {
	},
	["quests"] = {
	},
	["units"] = {
	},
}
CodexColors = {
	["英雄之魂"] = {
		0.615686274509804, -- [1]
		0.419607843137255, -- [2]
		0.454901960784314, -- [3]
	},
}
