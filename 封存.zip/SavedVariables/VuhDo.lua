
VUHDO_CONFIG = {
	["SMARTCAST_CLEANSE"] = false,
	["RANGE_SPELL"] = "次级治疗术",
	["OMIT_MAIN_TANKS"] = false,
	["OMIT_PLAYER_TARGETS"] = false,
	["BLIZZ_UI_HIDE_TARGET"] = 2,
	["DIRECTION"] = {
		["isAlways"] = false,
		["isDistanceText"] = false,
		["enable"] = true,
		["isDeadOnly"] = false,
		["scale"] = 76,
	},
	["STANDARD_TOOLTIP"] = false,
	["OVERHEAL_EXTRA_SCALE"] = 1,
	["LOCK_PANELS"] = false,
	["DEBUFF_TOOLTIP"] = true,
	["RANGE_PESSIMISTIC"] = false,
	["SMARTCAST_RESURRECT"] = 1,
	["BLIZZ_UI_HIDE_PET"] = 2,
	["INC_HOTS_SECS"] = 3,
	["SMARTCAST_BUFF"] = false,
	["SHOW_PANELS"] = true,
	["HIDE_EMPTY_PANELS"] = 1,
	["RANGE_CHECK_DELAY"] = 200,
	["SHOW_MINIMAP"] = true,
	["INC_CHANNELLED_SECS"] = 3,
	["OMIT_OWN_GROUP"] = false,
	["MODE"] = 1,
	["BLIZZ_UI_HIDE_RAID"] = 2,
	["DETECT_DEBUFFS_REMOVABLE_ONLY"] = true,
	["AOE_ADVISOR"] = {
		["subInc"] = true,
		["config"] = {
			["poh"] = {
				["enable"] = true,
				["thresh"] = 20000,
			},
			["coh"] = {
				["enable"] = true,
				["thresh"] = 15000,
			},
			["lod"] = {
				["enable"] = true,
				["thresh"] = 10000,
			},
			["cb"] = {
				["enable"] = false,
				["thresh"] = 10000,
			},
			["hr"] = {
				["enable"] = false,
				["thresh"] = 10000,
			},
			["wg"] = {
				["enable"] = true,
				["thresh"] = 15000,
			},
			["tq"] = {
				["enable"] = true,
				["thresh"] = 15000,
			},
			["ch"] = {
				["enable"] = true,
				["thresh"] = 15000,
			},
		},
		["knownOnly"] = true,
		["subIncOnlyCastTime"] = true,
		["isCooldown"] = true,
		["refresh"] = 800,
		["animate"] = true,
		["isGroupWise"] = false,
	},
	["IS_SHARE"] = true,
	["CLUSTER"] = {
		["CONE_DEGREES"] = 360,
		["CHAIN_MAX_JUMP"] = 3,
		["RANGE_JUMP"] = 11,
		["IS_NUMBER"] = true,
		["DISPLAY_DESTINATION"] = 2,
		["COOLDOWN_SPELL"] = "",
		["BELOW_HEALTH_PERC"] = 85,
		["RANGE"] = 30,
		["MODE"] = 1,
		["DISPLAY_SOURCE"] = 2,
		["TEXT"] = {
			["X_ADJUST"] = 40,
			["USE_MONO"] = false,
			["Y_ADJUST"] = 22,
			["ANCHOR"] = "BOTTOMRIGHT",
			["USE_OUTLINE"] = true,
			["SCALE"] = 85,
			["COLOR"] = {
				["TG"] = 1,
				["R"] = 0,
				["TB"] = 1,
				["G"] = 0,
				["TR"] = 1,
				["TO"] = 1,
				["B"] = 0,
				["useText"] = true,
				["useBackground"] = true,
				["O"] = 1,
				["useOpacity"] = true,
			},
			["FONT"] = "Interface\\AddOns\\VuhDo\\Fonts\\ariblk.ttf",
			["USE_SHADOW"] = false,
		},
		["THRESH_GOOD"] = 5,
		["ARE_TARGETS_RANDOM"] = true,
		["REFRESH"] = 180,
		["THRESH_FAIR"] = 3,
	},
	["OMIT_MAIN_ASSIST"] = false,
	["MAX_EMERGENCIES"] = 5,
	["RES_ANNOUNCE_TEXT"] = "vuhdo！复活吧，我的勇士！",
	["SHOW_INC_BOMBED"] = true,
	["VERSION"] = 4,
	["RANGE_CHECK"] = true,
	["CURRENT_SKIN"] = "皮肤1",
	["BAR_FRAMES"] = false,
	["DETECT_DEBUFFS_IGNORE_DURATION"] = true,
	["RES_ANNOUNCE_MASS_TEXT"] = "Casting mass resurrection!",
	["CUSTOM_DEBUFF"] = {
		["point"] = "TOPRIGHT",
		["scale"] = 0.65,
		["STORED"] = {
			"冰霜冲击", -- [1]
			"虚弱灵魂", -- [2]
			"凶残撕咬", -- [3]
			"立刻治疗", -- [4]
			"穿刺", -- [5]
			"蛛网裹体", -- [6]
			"裂纹小刀", -- [7]
			"熔渣炉", -- [8]
			"重力炸弹", -- [9]
			"灼热之光", -- [10]
			"岩石之握", -- [11]
			"野性突袭", -- [12]
			"凝固汽油炸弹", -- [13]
			"愈合祷言", -- [14]
			"圣盾术", -- [15]
			"寒冰屏障", -- [16]
			"狗头人上身！", -- [17]
			"灼热胆汁", -- [18]
			"麻痹毒素", -- [19]
			"血肉成灰", -- [20]
			"光明之触", -- [21]
			"黑暗之触", -- [22]
			"刺骨之寒", -- [23]
			"酸腺撕咬", -- [24]
			"灵感", -- [25]
			"漂浮术", -- [26]
			"20475", -- [27]
		},
		["isIcon"] = true,
		["selected"] = "",
		["SELECTED"] = "漂浮术",
		["isStacks"] = false,
		["TIMER_TEXT"] = {
			["X_ADJUST"] = 20,
			["USE_MONO"] = false,
			["Y_ADJUST"] = 26,
			["ANCHOR"] = "BOTTOMRIGHT",
			["USE_OUTLINE"] = false,
			["SCALE"] = 85,
			["COLOR"] = {
				["TG"] = 1,
				["R"] = 0,
				["TB"] = 1,
				["G"] = 0,
				["TR"] = 1,
				["TO"] = 1,
				["B"] = 0,
				["useText"] = true,
				["useBackground"] = true,
				["O"] = 1,
				["useOpacity"] = true,
			},
			["FONT"] = "Interface\\AddOns\\VuhDo\\Fonts\\ariblk.ttf",
			["USE_SHADOW"] = true,
		},
		["version"] = 45,
		["isColor"] = false,
		["max_num"] = 3,
		["yAdjust"] = -34,
		["COUNTER_TEXT"] = {
			["X_ADJUST"] = -10,
			["USE_MONO"] = false,
			["Y_ADJUST"] = -15,
			["ANCHOR"] = "TOPLEFT",
			["USE_OUTLINE"] = false,
			["SCALE"] = 70,
			["COLOR"] = {
				["TG"] = 1,
				["R"] = 0,
				["TB"] = 0,
				["G"] = 0,
				["TR"] = 0,
				["TO"] = 1,
				["B"] = 0,
				["useText"] = true,
				["useBackground"] = true,
				["O"] = 1,
				["useOpacity"] = true,
			},
			["FONT"] = "Interface\\AddOns\\VuhDo\\Fonts\\ariblk.ttf",
			["USE_SHADOW"] = true,
		},
		["STORED_SETTINGS"] = {
			["刺骨之寒"] = {
				["isStacks"] = false,
				["timer"] = true,
				["isIcon"] = true,
				["isMine"] = true,
				["isColor"] = false,
				["isOthers"] = true,
			},
			["岩石之握"] = {
				["isStacks"] = false,
				["animate"] = true,
				["timer"] = true,
				["isIcon"] = true,
				["isMine"] = true,
				["isColor"] = false,
				["isOthers"] = true,
			},
			["漂浮术"] = {
				["isIcon"] = 1,
				["timer"] = 1,
				["isMine"] = true,
				["isOthers"] = true,
			},
			["血肉成灰"] = {
				["isStacks"] = false,
				["timer"] = true,
				["isIcon"] = true,
				["isMine"] = true,
				["isColor"] = false,
				["isOthers"] = true,
			},
			["冰霜冲击"] = {
				["isStacks"] = false,
				["animate"] = true,
				["timer"] = true,
				["isIcon"] = true,
				["isMine"] = true,
				["isColor"] = false,
				["isOthers"] = true,
			},
			["20475"] = {
				["isColor"] = false,
				["isIconGlow"] = false,
				["isStacks"] = false,
				["isMine"] = true,
				["timer"] = true,
				["isIcon"] = true,
				["isBarGlow"] = false,
				["isOthers"] = true,
			},
			["野性突袭"] = {
				["isStacks"] = false,
				["animate"] = true,
				["timer"] = true,
				["isIcon"] = true,
				["isMine"] = true,
				["isColor"] = false,
				["isOthers"] = true,
			},
			["狗头人上身！"] = {
				["isStacks"] = false,
				["timer"] = true,
				["isIcon"] = true,
				["isMine"] = true,
				["isColor"] = false,
				["isOthers"] = true,
			},
			["寒冰屏障"] = {
				["isIcon"] = 1,
				["timer"] = 1,
				["isMine"] = true,
				["isOthers"] = true,
			},
			["光明之触"] = {
				["isStacks"] = false,
				["timer"] = true,
				["isIcon"] = true,
				["isMine"] = true,
				["isColor"] = false,
				["isOthers"] = true,
			},
			["灼热之光"] = {
				["isStacks"] = false,
				["animate"] = true,
				["timer"] = true,
				["isIcon"] = true,
				["isMine"] = true,
				["isColor"] = false,
				["isOthers"] = true,
			},
			["黑暗之触"] = {
				["isStacks"] = false,
				["timer"] = true,
				["isIcon"] = true,
				["isMine"] = true,
				["isColor"] = false,
				["isOthers"] = true,
			},
			["愈合祷言"] = {
				["isIcon"] = 1,
				["timer"] = 1,
				["isMine"] = true,
				["isOthers"] = true,
			},
			["蛛网裹体"] = {
				["isStacks"] = false,
				["animate"] = true,
				["timer"] = true,
				["isIcon"] = true,
				["isMine"] = true,
				["isColor"] = false,
				["isOthers"] = true,
			},
			["灼热胆汁"] = {
				["isStacks"] = false,
				["timer"] = true,
				["isIcon"] = true,
				["isMine"] = true,
				["isColor"] = false,
				["isOthers"] = true,
			},
			["立刻治疗"] = {
				["isStacks"] = false,
				["animate"] = true,
				["timer"] = true,
				["isIcon"] = true,
				["isMine"] = true,
				["isColor"] = false,
				["isOthers"] = true,
			},
			["凝固汽油炸弹"] = {
				["isStacks"] = false,
				["animate"] = true,
				["timer"] = true,
				["isIcon"] = true,
				["isMine"] = true,
				["isColor"] = false,
				["isOthers"] = true,
			},
			["裂纹小刀"] = {
				["isStacks"] = false,
				["animate"] = true,
				["timer"] = true,
				["isIcon"] = true,
				["isMine"] = true,
				["isColor"] = false,
				["isOthers"] = true,
			},
			["灵感"] = {
				["isIcon"] = 1,
				["timer"] = 1,
				["isMine"] = true,
				["isOthers"] = true,
			},
			["虚弱灵魂"] = {
				["isStacks"] = false,
				["isIcon"] = true,
				["timer"] = true,
				["isMine"] = true,
				["isColor"] = false,
				["isOthers"] = true,
			},
			["穿刺"] = {
				["isStacks"] = false,
				["animate"] = true,
				["timer"] = true,
				["isIcon"] = true,
				["isMine"] = true,
				["isColor"] = false,
				["isOthers"] = true,
			},
			["凶残撕咬"] = {
				["isStacks"] = false,
				["animate"] = true,
				["timer"] = true,
				["isIcon"] = true,
				["isMine"] = true,
				["isColor"] = false,
				["isOthers"] = true,
			},
			["熔渣炉"] = {
				["isStacks"] = false,
				["animate"] = true,
				["timer"] = true,
				["isIcon"] = true,
				["isMine"] = true,
				["isColor"] = false,
				["isOthers"] = true,
			},
			["酸腺撕咬"] = {
				["isStacks"] = false,
				["timer"] = true,
				["isIcon"] = true,
				["isMine"] = true,
				["isColor"] = false,
				["isOthers"] = true,
			},
			["重力炸弹"] = {
				["isStacks"] = false,
				["animate"] = true,
				["timer"] = true,
				["isIcon"] = true,
				["isMine"] = true,
				["isColor"] = false,
				["isOthers"] = true,
			},
			["麻痹毒素"] = {
				["isStacks"] = false,
				["timer"] = true,
				["isIcon"] = true,
				["isMine"] = true,
				["isColor"] = false,
				["isOthers"] = true,
			},
			["圣盾术"] = {
				["isIcon"] = 1,
				["timer"] = 1,
				["isMine"] = true,
				["isOthers"] = true,
			},
		},
		["timer"] = true,
		["xAdjust"] = -2,
		["blacklistModi"] = "ALT-CTRL-SHIFT",
	},
	["GROUP_HIGHLIGHT_FACTOR"] = 0.1,
	["SCAN_RANGE"] = "2",
	["ON_MOUSE_UP"] = false,
	["BLIZZ_UI_HIDE_RAID_MGR"] = 2,
	["BLIZZ_UI_HIDE_FOCUS"] = 2,
	["DETECT_DEBUFFS_IGNORE_NO_HARM"] = true,
	["DETECT_DEBUFFS_IGNORE_BY_CLASS"] = true,
	["INC_CASTED_SECS"] = 3,
	["INC_BOMBED_SECS"] = 3,
	["DETECT_DEBUFFS_REMOVABLE_ONLY_ICONS"] = false,
	["IS_UNIT_HIGHLIGHT"] = false,
	["DETECT_DEBUFFS_IGNORE_MOVEMENT"] = true,
	["PLAYER_TARGET_FRAME_THICKNESS"] = 1,
	["AUTO_PROFILES"] = {
	},
	["PLAYER_TARGET_FRAME"] = true,
	["SHOW_INC_CHANNELLED"] = true,
	["SHOW_PLAYER_TAGS"] = true,
	["DETECT_DEBUFFS"] = true,
	["UPDATE_HOTS_MS"] = 250,
	["SHOW_INC_CASTED"] = true,
	["AUTO_ARRANGEMENTS"] = {
		["25"] = "团队",
		["lastAutoSaveSlot"] = 0,
		["5"] = "团队",
		["10"] = "团队",
		["dirty"] = true,
	},
	["CURRENT_PROFILE"] = "",
	["EMERGENCY_TRIGGER"] = 100,
	["SHOW_INCOMING"] = true,
	["LOCK_CLICKS_THROUGH"] = false,
	["OMIT_FOCUS"] = false,
	["SPELL_TRACE"] = {
		["isOthers"] = false,
		["STORED_SETTINGS"] = {
			["596"] = {
				["duration"] = 2,
				["isMine"] = true,
				["isOthers"] = false,
			},
			["194509"] = {
				["duration"] = 2,
				["isMine"] = true,
				["isOthers"] = false,
			},
			["34861"] = {
				["duration"] = 2,
				["isMine"] = true,
				["isOthers"] = false,
			},
			["1064"] = {
				["duration"] = 2,
				["isMine"] = true,
				["isOthers"] = false,
			},
		},
		["version"] = 1,
		["SELECTED"] = "",
		["duration"] = 2,
		["showTrailOfLight"] = false,
		["isMine"] = true,
		["STORED"] = {
			"1064", -- [1]
			"34861", -- [2]
			"596", -- [3]
			"194509", -- [4]
		},
	},
	["BLIZZ_UI_HIDE_PARTY"] = 3,
	["BLIZZ_UI_HIDE_PLAYER"] = 2,
	["CURRENT_ARRANGEMENT"] = "团队",
	["RES_IS_SHOW_TEXT"] = 1,
	["THREAT"] = {
		["THREAT_BAR_WIDTH"] = 4,
		["AGGRO_USE_FRAME"] = 1,
		["THREAT_SYMBOL_MIN_PERCENT"] = 85,
		["AGGRO_REFRESH_MS"] = 300,
		["AGGRO_TEXT_RIGHT"] = "<<",
		["AGGRO_DETECT"] = true,
		["AGGRO_TEXT_LEFT"] = ">>",
		["THREAT_USE_SYMBOL"] = false,
		["THREAT_DETECT"] = false,
		["THREAT_USE_BAR"] = false,
	},
	["SHOW_OWN_INCOMING"] = true,
	["SHOW_INC_HOTS"] = true,
	["IS_GROUP_HIGHLIGHT"] = false,
}
VUHDO_PANEL_SETUP = {
	{
		["OVERHEAL_TEXT"] = {
			["show"] = true,
			["yAdjust"] = 0,
			["point"] = "LEFT",
			["scale"] = 1,
			["xAdjust"] = 0,
		},
		["POSITION"] = {
			["y"] = 617.580322265625,
			["x"] = 987.264282226563,
			["scale"] = 1,
			["relativePoint"] = "BOTTOMLEFT",
			["orientation"] = "TOPLEFT",
			["height"] = 158.000015258789,
			["growth"] = "TOPLEFT",
			["width"] = 69.9999847412109,
		},
		["RAID_ICON"] = {
			["show"] = true,
			["yAdjust"] = -20,
			["point"] = "TOP",
			["scale"] = 1,
			["xAdjust"] = 0,
		},
		["frameStrata"] = "MEDIUM",
		["MODEL"] = {
			["sort"] = 3,
			["groups"] = {
				1, -- [1]
				2, -- [2]
				3, -- [3]
				4, -- [4]
				5, -- [5]
				6, -- [6]
				7, -- [7]
				8, -- [8]
			},
			["ordering"] = 0,
		},
		["TOOLTIP"] = {
			["BACKGROUND"] = {
				["useBackground"] = true,
				["R"] = 0,
				["useOpacity"] = true,
				["O"] = 1,
				["G"] = 0,
				["B"] = 0,
			},
			["point"] = "TOPLEFT",
			["BORDER"] = {
				["useBackground"] = true,
				["R"] = 0,
				["useOpacity"] = true,
				["O"] = 1,
				["G"] = 0,
				["B"] = 0,
			},
			["showBuffs"] = false,
			["y"] = -100,
			["x"] = 100,
			["relativePoint"] = "TOPLEFT",
			["SCALE"] = 1,
			["show"] = true,
			["inFight"] = false,
			["position"] = 80,
		},
		["PANEL_COLOR"] = {
			["BACK"] = {
				["useBackground"] = true,
				["R"] = 0.4314,
				["useOpacity"] = true,
				["O"] = 0.64,
				["G"] = 0.4314,
				["B"] = 0.4314,
			},
			["classColorsBackHeader"] = false,
			["TARGET"] = {
				["TR"] = 1,
				["TO"] = 1,
				["TB"] = 1,
				["useText"] = true,
				["TG"] = 1,
			},
			["BORDER"] = {
				["edgeSize"] = 8,
				["B"] = 0.1373,
				["G"] = 0.1373,
				["useOpacity"] = true,
				["R"] = 0.1373,
				["useBackground"] = true,
				["file"] = "Interface\\Addons\\XPerl\\images\\XPerl_ThinEdge",
				["O"] = 0,
				["insets"] = 0,
			},
			["barTexture"] = "Bars",
			["barBackBrightness"] = 30,
			["classColorsBack"] = false,
			["classColorsBar"] = false,
			["TEXT"] = {
				["TG"] = 0.82,
				["TR"] = 1,
				["B"] = 0,
				["R"] = 0,
				["TB"] = 0,
				["O"] = 0.75,
				["G"] = 0,
				["useText"] = true,
				["useOpacity"] = true,
				["font"] = "",
				["TO"] = 1,
				["maxChars"] = 0,
				["useBackground"] = true,
				["textSizeLife"] = 8,
				["textSize"] = 11,
			},
			["BARS"] = {
				["useBackground"] = true,
				["useOpacity"] = true,
				["R"] = 0.7,
				["O"] = 1,
				["mode"] = 1,
				["G"] = 0.7,
				["B"] = 0.7,
			},
			["TOT"] = {
				["TR"] = 1,
				["TO"] = 1,
				["TB"] = 1,
				["useText"] = true,
				["TG"] = 1,
			},
			["classColorsHeader"] = false,
			["HEADER"] = {
				["TG"] = 0.859,
				["B"] = 0.6,
				["TB"] = 0.38,
				["barTexture"] = "VuhDo - Concave, dark",
				["G"] = 0.6,
				["TR"] = 1,
				["font"] = "",
				["TO"] = 1,
				["useBackground"] = true,
				["textSize"] = 10,
				["useText"] = true,
				["O"] = 0.6,
				["R"] = 0.6,
			},
		},
		["HOTS"] = {
			["SLOTS"] = {
				"恢复", -- [1]
				"痛苦压制", -- [2]
				"愈合祷言", -- [3]
				"驱除疾病", -- [4]
			},
			["BARS"] = {
				["show"] = false,
				["radioValue"] = 1,
				["invertOrientation"] = false,
				["invertDirection"] = false,
				["width"] = 25,
			},
			["SLOTCFG"] = {
				{
					true, -- [1]
					false, -- [2]
				}, -- [1]
				{
					true, -- [1]
					false, -- [2]
				}, -- [2]
				{
					true, -- [1]
					false, -- [2]
				}, -- [3]
				{
					true, -- [1]
					true, -- [2]
				}, -- [4]
				{
					true, -- [1]
					false, -- [2]
				}, -- [5]
				{
					true, -- [1]
					false, -- [2]
				}, -- [6]
				{
					true, -- [1]
					false, -- [2]
				}, -- [7]
			},
			["isFlatTexture"] = false,
			["show"] = true,
			["iconRadioValue"] = 2,
			["radioValue"] = 20,
			["stacksRadioValue"] = 3,
			["size"] = 70,
		},
		["SCALING"] = {
			["targetWidth"] = 30,
			["barHeight"] = 33,
			["ommitEmptyWhenStructured"] = true,
			["showTarget"] = false,
			["maxRowsWhenLoose"] = 6,
			["totSpacing"] = 3,
			["isDamFlash"] = true,
			["showManaBars"] = true,
			["borderGapY"] = 2,
			["alignBottom"] = false,
			["isPlayerOnTop"] = true,
			["arrangeHorizontal"] = false,
			["scale"] = 0.95,
			["targetSpacing"] = 3,
			["targetOrientation"] = 1,
			["raidIconScale"] = 0.6,
			["sideLeftWidth"] = 6,
			["headerSpacing"] = 5,
			["borderGapX"] = 4,
			["manaBarHeight"] = 3,
			["barWidth"] = 62,
			["damFlashFactor"] = 0.75,
			["headerWidth"] = 50,
			["maxColumnsWhenStructured"] = 8,
			["showRageBars"] = 1,
			["vertical"] = false,
			["showTot"] = false,
			["sideRightWidth"] = 6,
			["invertGrowth"] = false,
			["columnSpacing"] = 2,
			["totWidth"] = 30,
			["headerHeight"] = 20,
			["rowSpacing"] = 2,
		},
		["IS_RAID_ICON"] = 1,
		["LIFE_TEXT"] = {
			["show"] = true,
			["hideIrrelevant"] = false,
			["position"] = 4,
			["mode"] = 1,
			["verbose"] = false,
		},
		["ID_TEXT"] = {
			["showTags"] = true,
			["_spacing"] = 19,
			["showNickname"] = false,
			["showClass"] = false,
			["yAdjust"] = 9,
			["version"] = 2,
			["position"] = "TOP+TOP",
			["showName"] = true,
			["xAdjust"] = 0,
			["showPetOwners"] = true,
		},
	}, -- [1]
	{
		["OVERHEAL_TEXT"] = {
			["show"] = true,
			["yAdjust"] = 0,
			["point"] = "LEFT",
			["scale"] = 1,
			["xAdjust"] = 0,
		},
		["POSITION"] = {
			["y"] = 186.4051,
			["x"] = 977.8878,
			["scale"] = 1,
			["relativePoint"] = "BOTTOMLEFT",
			["orientation"] = "TOPLEFT",
			["height"] = 110.25,
			["growth"] = "TOPLEFT",
			["width"] = 103.0001,
		},
		["RAID_ICON"] = {
			["show"] = true,
			["yAdjust"] = -20,
			["point"] = "TOP",
			["scale"] = 1,
			["xAdjust"] = 0,
		},
		["frameStrata"] = "MEDIUM",
		["MODEL"] = {
			["ordering"] = 0,
			["sort"] = 3,
		},
		["TOOLTIP"] = {
			["BACKGROUND"] = {
				["useBackground"] = true,
				["R"] = 0,
				["useOpacity"] = true,
				["O"] = 1,
				["G"] = 0,
				["B"] = 0,
			},
			["point"] = "TOPLEFT",
			["BORDER"] = {
				["useBackground"] = true,
				["R"] = 0,
				["useOpacity"] = true,
				["O"] = 1,
				["G"] = 0,
				["B"] = 0,
			},
			["showBuffs"] = false,
			["y"] = -100,
			["x"] = 100,
			["relativePoint"] = "TOPLEFT",
			["SCALE"] = 1,
			["show"] = true,
			["inFight"] = false,
			["position"] = 80,
		},
		["PANEL_COLOR"] = {
			["BACK"] = {
				["useBackground"] = true,
				["R"] = 0.4314,
				["useOpacity"] = true,
				["O"] = 0.64,
				["G"] = 0.4314,
				["B"] = 0.4314,
			},
			["classColorsBackHeader"] = false,
			["TARGET"] = {
				["TR"] = 1,
				["TO"] = 1,
				["TB"] = 1,
				["useText"] = true,
				["TG"] = 1,
			},
			["BORDER"] = {
				["edgeSize"] = 8,
				["B"] = 0.1373,
				["G"] = 0.1373,
				["useOpacity"] = true,
				["R"] = 0.1373,
				["useBackground"] = true,
				["file"] = "Interface\\Addons\\XPerl\\images\\XPerl_ThinEdge",
				["O"] = 0,
				["insets"] = 0,
			},
			["barTexture"] = "Bars",
			["BARS"] = {
				["useBackground"] = true,
				["useOpacity"] = true,
				["R"] = 0.7,
				["O"] = 1,
				["mode"] = 1,
				["G"] = 0.7,
				["B"] = 0.7,
			},
			["barBackBrightness"] = 30,
			["classColorsBack"] = false,
			["classColorsBar"] = false,
			["TEXT"] = {
				["TG"] = 0.82,
				["maxChars"] = 0,
				["R"] = 0,
				["B"] = 0,
				["TB"] = 0,
				["O"] = 0.75,
				["useText"] = true,
				["G"] = 0,
				["useOpacity"] = true,
				["font"] = "",
				["TO"] = 1,
				["useBackground"] = true,
				["TR"] = 1,
				["textSizeLife"] = 8,
				["textSize"] = 11,
			},
			["TOT"] = {
				["TR"] = 1,
				["TO"] = 1,
				["TB"] = 1,
				["useText"] = true,
				["TG"] = 1,
			},
			["classColorsHeader"] = false,
			["HEADER"] = {
				["TG"] = 0.859,
				["B"] = 0.6,
				["TB"] = 0.38,
				["barTexture"] = "VuhDo - Concave, dark",
				["G"] = 0.6,
				["TR"] = 1,
				["font"] = "",
				["TO"] = 1,
				["useBackground"] = true,
				["textSize"] = 10,
				["useText"] = true,
				["O"] = 0.6,
				["R"] = 0.6,
			},
			["classColorsName"] = false,
		},
		["HOTS"] = {
			["SLOTS"] = {
				"恢复", -- [1]
				"痛苦压制", -- [2]
				"愈合祷言", -- [3]
				"驱除疾病", -- [4]
				"恩赐", -- [5]
			},
			["BARS"] = {
				["show"] = false,
				["radioValue"] = 1,
				["invertOrientation"] = false,
				["invertDirection"] = false,
				["width"] = 25,
			},
			["SLOTCFG"] = {
				{
					true, -- [1]
					false, -- [2]
				}, -- [1]
				{
					true, -- [1]
					false, -- [2]
				}, -- [2]
				{
					true, -- [1]
					false, -- [2]
				}, -- [3]
				{
					true, -- [1]
					true, -- [2]
				}, -- [4]
				{
					true, -- [1]
					false, -- [2]
				}, -- [5]
				{
					true, -- [1]
					false, -- [2]
				}, -- [6]
				{
					true, -- [1]
					false, -- [2]
				}, -- [7]
			},
			["isFlatTexture"] = false,
			["show"] = 1,
			["iconRadioValue"] = 2,
			["radioValue"] = 20,
			["stacksRadioValue"] = 3,
			["size"] = 70,
		},
		["SCALING"] = {
			["targetWidth"] = 30,
			["maxColumnsWhenStructured"] = 8,
			["ommitEmptyWhenStructured"] = true,
			["showTarget"] = false,
			["maxRowsWhenLoose"] = 6,
			["headerWidth"] = 50,
			["isDamFlash"] = true,
			["showManaBars"] = true,
			["borderGapY"] = 2,
			["alignBottom"] = false,
			["headerHeight"] = 20,
			["arrangeHorizontal"] = false,
			["scale"] = 0.85,
			["vertical"] = false,
			["targetOrientation"] = 1,
			["raidIconScale"] = 0.6,
			["sideLeftWidth"] = 6,
			["headerSpacing"] = 5,
			["borderGapX"] = 9,
			["invertGrowth"] = false,
			["barWidth"] = 85,
			["damFlashFactor"] = 0.75,
			["totSpacing"] = 3,
			["barHeight"] = 45,
			["targetSpacing"] = 2,
			["showRageBars"] = 1,
			["showTot"] = false,
			["sideRightWidth"] = 6,
			["manaBarHeight"] = 3,
			["columnSpacing"] = 2,
			["totWidth"] = 30,
			["isPlayerOnTop"] = true,
			["rowSpacing"] = 2,
		},
		["IS_RAID_ICON"] = 1,
		["LIFE_TEXT"] = {
			["hideIrrelevant"] = false,
			["position"] = 3,
			["mode"] = 1,
			["verbose"] = false,
		},
		["ID_TEXT"] = {
			["showTags"] = true,
			["_spacing"] = 19,
			["showClass"] = false,
			["yAdjust"] = 9,
			["version"] = 2,
			["position"] = "TOP+TOP",
			["showName"] = true,
			["xAdjust"] = 0,
			["showPetOwners"] = true,
		},
	}, -- [2]
	{
		["OVERHEAL_TEXT"] = {
			["show"] = true,
			["yAdjust"] = 0,
			["point"] = "LEFT",
			["scale"] = 1,
			["xAdjust"] = 0,
		},
		["POSITION"] = {
			["y"] = 751.8105,
			["x"] = 524.2221,
			["scale"] = 1,
			["relativePoint"] = "BOTTOMLEFT",
			["orientation"] = "TOPLEFT",
			["height"] = 90.25,
			["growth"] = "TOPLEFT",
			["width"] = 108,
		},
		["RAID_ICON"] = {
			["show"] = true,
			["yAdjust"] = -20,
			["point"] = "TOP",
			["scale"] = 1,
			["xAdjust"] = 0,
		},
		["frameStrata"] = "MEDIUM",
		["MODEL"] = {
			["sort"] = 3,
			["ordering"] = 0,
		},
		["TOOLTIP"] = {
			["BACKGROUND"] = {
				["useBackground"] = true,
				["R"] = 0,
				["useOpacity"] = true,
				["O"] = 1,
				["G"] = 0,
				["B"] = 0,
			},
			["point"] = "TOPLEFT",
			["BORDER"] = {
				["useBackground"] = true,
				["R"] = 0,
				["useOpacity"] = true,
				["O"] = 1,
				["G"] = 0,
				["B"] = 0,
			},
			["showBuffs"] = false,
			["y"] = -100,
			["x"] = 100,
			["relativePoint"] = "TOPLEFT",
			["SCALE"] = 1,
			["show"] = true,
			["inFight"] = false,
			["position"] = 2,
		},
		["PANEL_COLOR"] = {
			["BACK"] = {
				["useBackground"] = true,
				["R"] = 0.4314,
				["useOpacity"] = true,
				["O"] = 0.64,
				["G"] = 0.4314,
				["B"] = 0.4314,
			},
			["classColorsBackHeader"] = false,
			["TARGET"] = {
				["TR"] = 1,
				["TO"] = 1,
				["TB"] = 1,
				["useText"] = true,
				["TG"] = 1,
			},
			["BORDER"] = {
				["edgeSize"] = 8,
				["B"] = 0.1373,
				["G"] = 0.1373,
				["useOpacity"] = true,
				["R"] = 0.1373,
				["useBackground"] = true,
				["file"] = "Interface\\Addons\\XPerl\\images\\XPerl_ThinEdge",
				["O"] = 0,
				["insets"] = 0,
			},
			["barTexture"] = "Bars",
			["BARS"] = {
				["useBackground"] = true,
				["useOpacity"] = true,
				["R"] = 0.7,
				["O"] = 1,
				["mode"] = 1,
				["G"] = 0.7,
				["B"] = 0.7,
			},
			["barBackBrightness"] = 30,
			["classColorsBack"] = false,
			["classColorsBar"] = false,
			["TEXT"] = {
				["TG"] = 0.82,
				["maxChars"] = 0,
				["R"] = 0,
				["B"] = 0,
				["TB"] = 0,
				["O"] = 0.75,
				["useText"] = true,
				["G"] = 0,
				["useOpacity"] = true,
				["font"] = "",
				["TO"] = 1,
				["useBackground"] = true,
				["TR"] = 1,
				["textSizeLife"] = 8,
				["textSize"] = 11,
			},
			["TOT"] = {
				["TR"] = 1,
				["TO"] = 1,
				["TB"] = 1,
				["useText"] = true,
				["TG"] = 1,
			},
			["classColorsHeader"] = false,
			["HEADER"] = {
				["TG"] = 0.859,
				["B"] = 0.6,
				["TB"] = 0.38,
				["barTexture"] = "VuhDo - Concave, dark",
				["G"] = 0.6,
				["TR"] = 1,
				["font"] = "",
				["TO"] = 1,
				["useBackground"] = true,
				["textSize"] = 10,
				["useText"] = true,
				["O"] = 0.6,
				["R"] = 0.6,
			},
			["classColorsName"] = false,
		},
		["HOTS"] = {
			["SLOTS"] = {
				"恢复", -- [1]
				"痛苦压制", -- [2]
				"愈合祷言", -- [3]
				"驱除疾病", -- [4]
				"恩赐", -- [5]
			},
			["BARS"] = {
				["show"] = false,
				["radioValue"] = 1,
				["invertOrientation"] = false,
				["invertDirection"] = false,
				["width"] = 25,
			},
			["SLOTCFG"] = {
				{
					true, -- [1]
					false, -- [2]
				}, -- [1]
				{
					true, -- [1]
					false, -- [2]
				}, -- [2]
				{
					true, -- [1]
					false, -- [2]
				}, -- [3]
				{
					true, -- [1]
					true, -- [2]
				}, -- [4]
				{
					true, -- [1]
					false, -- [2]
				}, -- [5]
				{
					true, -- [1]
					false, -- [2]
				}, -- [6]
				{
					true, -- [1]
					false, -- [2]
				}, -- [7]
			},
			["isFlatTexture"] = false,
			["show"] = true,
			["iconRadioValue"] = 2,
			["radioValue"] = 20,
			["stacksRadioValue"] = 3,
			["size"] = 70,
		},
		["SCALING"] = {
			["targetWidth"] = 25,
			["maxColumnsWhenStructured"] = 8,
			["ommitEmptyWhenStructured"] = true,
			["showTarget"] = true,
			["maxRowsWhenLoose"] = 6,
			["headerWidth"] = 50,
			["isDamFlash"] = true,
			["showManaBars"] = true,
			["borderGapY"] = 2,
			["alignBottom"] = false,
			["headerHeight"] = 20,
			["arrangeHorizontal"] = false,
			["scale"] = 0.95,
			["vertical"] = false,
			["targetOrientation"] = 1,
			["raidIconScale"] = 0.6,
			["sideLeftWidth"] = 6,
			["headerSpacing"] = 5,
			["borderGapX"] = 6,
			["invertGrowth"] = false,
			["barWidth"] = 69,
			["damFlashFactor"] = 0.75,
			["totSpacing"] = 3,
			["barHeight"] = 45,
			["targetSpacing"] = 2,
			["showRageBars"] = 1,
			["showTot"] = false,
			["sideRightWidth"] = 6,
			["manaBarHeight"] = 3,
			["columnSpacing"] = 1,
			["totWidth"] = 30,
			["isPlayerOnTop"] = true,
			["rowSpacing"] = 2,
		},
		["IS_RAID_ICON"] = 1,
		["LIFE_TEXT"] = {
			["hideIrrelevant"] = false,
			["position"] = 3,
			["mode"] = 1,
			["verbose"] = false,
		},
		["ID_TEXT"] = {
			["showTags"] = true,
			["_spacing"] = 19,
			["showClass"] = false,
			["yAdjust"] = 9,
			["version"] = 2,
			["position"] = "TOP+TOP",
			["showName"] = true,
			["xAdjust"] = 0,
			["showPetOwners"] = true,
		},
	}, -- [3]
	{
		["OVERHEAL_TEXT"] = {
			["show"] = true,
			["yAdjust"] = 0,
			["point"] = "LEFT",
			["scale"] = 1,
			["xAdjust"] = 0,
		},
		["POSITION"] = {
			["y"] = 491.8,
			["x"] = 279.3,
			["scale"] = 1,
			["relativePoint"] = "BOTTOMLEFT",
			["orientation"] = "TOPLEFT",
			["height"] = 60,
			["growth"] = "TOPLEFT",
			["width"] = 231,
		},
		["RAID_ICON"] = {
			["show"] = true,
			["yAdjust"] = -20,
			["point"] = "TOP",
			["scale"] = 1,
			["xAdjust"] = 0,
		},
		["frameStrata"] = "MEDIUM",
		["MODEL"] = {
			["ordering"] = 0,
			["sort"] = 3,
		},
		["TOOLTIP"] = {
			["BACKGROUND"] = {
				["useBackground"] = true,
				["R"] = 0,
				["useOpacity"] = true,
				["O"] = 1,
				["G"] = 0,
				["B"] = 0,
			},
			["point"] = "TOPLEFT",
			["BORDER"] = {
				["useBackground"] = true,
				["R"] = 0,
				["useOpacity"] = true,
				["O"] = 1,
				["G"] = 0,
				["B"] = 0,
			},
			["showBuffs"] = false,
			["y"] = -100,
			["x"] = 100,
			["relativePoint"] = "TOPLEFT",
			["SCALE"] = 1,
			["show"] = true,
			["inFight"] = false,
			["position"] = 2,
		},
		["PANEL_COLOR"] = {
			["BACK"] = {
				["useBackground"] = true,
				["R"] = 0.4314,
				["useOpacity"] = true,
				["O"] = 0.64,
				["G"] = 0.4314,
				["B"] = 0.4314,
			},
			["classColorsBackHeader"] = false,
			["TARGET"] = {
				["TR"] = 1,
				["TO"] = 1,
				["TB"] = 1,
				["useText"] = true,
				["TG"] = 1,
			},
			["BORDER"] = {
				["edgeSize"] = 8,
				["B"] = 0.1373,
				["G"] = 0.1373,
				["useOpacity"] = true,
				["R"] = 0.1373,
				["useBackground"] = true,
				["file"] = "Interface\\Addons\\XPerl\\images\\XPerl_ThinEdge",
				["O"] = 0,
				["insets"] = 0,
			},
			["barTexture"] = "Bars",
			["BARS"] = {
				["useBackground"] = true,
				["useOpacity"] = true,
				["R"] = 0.7,
				["O"] = 1,
				["mode"] = 1,
				["G"] = 0.7,
				["B"] = 0.7,
			},
			["barBackBrightness"] = 30,
			["classColorsBack"] = false,
			["classColorsBar"] = false,
			["TEXT"] = {
				["TG"] = 0.82,
				["maxChars"] = 0,
				["R"] = 0,
				["B"] = 0,
				["TB"] = 0,
				["O"] = 0.75,
				["useText"] = true,
				["G"] = 0,
				["useOpacity"] = true,
				["font"] = "",
				["TO"] = 1,
				["useBackground"] = true,
				["TR"] = 1,
				["textSizeLife"] = 8,
				["textSize"] = 11,
			},
			["TOT"] = {
				["TR"] = 1,
				["TO"] = 1,
				["TB"] = 1,
				["useText"] = true,
				["TG"] = 1,
			},
			["classColorsHeader"] = false,
			["HEADER"] = {
				["TG"] = 0.859,
				["B"] = 0.6,
				["TB"] = 0.38,
				["barTexture"] = "VuhDo - Concave, dark",
				["G"] = 0.6,
				["TR"] = 1,
				["font"] = "",
				["TO"] = 1,
				["useBackground"] = true,
				["textSize"] = 10,
				["useText"] = true,
				["O"] = 0.6,
				["R"] = 0.6,
			},
			["classColorsName"] = false,
		},
		["HOTS"] = {
			["SLOTS"] = {
				"恢复", -- [1]
				"痛苦压制", -- [2]
				"愈合祷言", -- [3]
				"驱除疾病", -- [4]
				"恩赐", -- [5]
			},
			["BARS"] = {
				["show"] = false,
				["radioValue"] = 1,
				["invertOrientation"] = false,
				["invertDirection"] = false,
				["width"] = 25,
			},
			["SLOTCFG"] = {
				{
					true, -- [1]
					false, -- [2]
				}, -- [1]
				{
					true, -- [1]
					false, -- [2]
				}, -- [2]
				{
					true, -- [1]
					false, -- [2]
				}, -- [3]
				{
					true, -- [1]
					true, -- [2]
				}, -- [4]
				{
					true, -- [1]
					false, -- [2]
				}, -- [5]
				{
					true, -- [1]
					false, -- [2]
				}, -- [6]
				{
					true, -- [1]
					false, -- [2]
				}, -- [7]
			},
			["isFlatTexture"] = false,
			["show"] = true,
			["iconRadioValue"] = 2,
			["radioValue"] = 20,
			["stacksRadioValue"] = 3,
			["size"] = 70,
		},
		["SCALING"] = {
			["targetWidth"] = 30,
			["maxColumnsWhenStructured"] = 8,
			["ommitEmptyWhenStructured"] = true,
			["showTarget"] = true,
			["maxRowsWhenLoose"] = 6,
			["headerWidth"] = 50,
			["isDamFlash"] = true,
			["showManaBars"] = true,
			["borderGapY"] = 2,
			["alignBottom"] = false,
			["headerHeight"] = 20,
			["arrangeHorizontal"] = false,
			["scale"] = 0.95,
			["vertical"] = false,
			["targetOrientation"] = 1,
			["raidIconScale"] = 0.6,
			["sideLeftWidth"] = 6,
			["headerSpacing"] = 5,
			["borderGapX"] = 2,
			["invertGrowth"] = false,
			["barWidth"] = 50,
			["damFlashFactor"] = 0.75,
			["totSpacing"] = 3,
			["barHeight"] = 45,
			["targetSpacing"] = 3,
			["showRageBars"] = 1,
			["showTot"] = false,
			["sideRightWidth"] = 6,
			["manaBarHeight"] = 3,
			["columnSpacing"] = 2,
			["totWidth"] = 30,
			["isPlayerOnTop"] = true,
			["rowSpacing"] = 2,
		},
		["IS_RAID_ICON"] = 1,
		["LIFE_TEXT"] = {
			["hideIrrelevant"] = false,
			["position"] = 3,
			["mode"] = 1,
			["verbose"] = false,
		},
		["ID_TEXT"] = {
			["showTags"] = true,
			["_spacing"] = 18,
			["showClass"] = false,
			["yAdjust"] = 9,
			["version"] = 2,
			["position"] = "TOP+TOP",
			["showName"] = true,
			["xAdjust"] = 0,
			["showPetOwners"] = true,
		},
	}, -- [4]
	{
		["OVERHEAL_TEXT"] = {
			["show"] = true,
			["yAdjust"] = 0,
			["point"] = "LEFT",
			["scale"] = 1,
			["xAdjust"] = 0,
		},
		["POSITION"] = {
			["y"] = 518,
			["x"] = 250,
			["scale"] = 1,
			["relativePoint"] = "BOTTOMLEFT",
			["orientation"] = "TOPLEFT",
			["height"] = 200,
			["growth"] = "TOPLEFT",
			["width"] = 200,
		},
		["RAID_ICON"] = {
			["show"] = true,
			["yAdjust"] = -20,
			["point"] = "TOP",
			["scale"] = 1,
			["xAdjust"] = 0,
		},
		["frameStrata"] = "MEDIUM",
		["MODEL"] = {
			["ordering"] = 0,
			["sort"] = 3,
		},
		["TOOLTIP"] = {
			["BACKGROUND"] = {
				["useBackground"] = true,
				["R"] = 0,
				["useOpacity"] = true,
				["O"] = 1,
				["G"] = 0,
				["B"] = 0,
			},
			["point"] = "TOPLEFT",
			["BORDER"] = {
				["useBackground"] = true,
				["R"] = 0,
				["useOpacity"] = true,
				["O"] = 1,
				["G"] = 0,
				["B"] = 0,
			},
			["showBuffs"] = false,
			["y"] = -100,
			["x"] = 100,
			["relativePoint"] = "TOPLEFT",
			["SCALE"] = 1,
			["show"] = true,
			["inFight"] = false,
			["position"] = 2,
		},
		["PANEL_COLOR"] = {
			["BACK"] = {
				["useBackground"] = true,
				["R"] = 0.4314,
				["useOpacity"] = true,
				["O"] = 0.64,
				["G"] = 0.4314,
				["B"] = 0.4314,
			},
			["classColorsBackHeader"] = false,
			["TARGET"] = {
				["TR"] = 1,
				["TO"] = 1,
				["TB"] = 1,
				["useText"] = true,
				["TG"] = 1,
			},
			["BORDER"] = {
				["edgeSize"] = 8,
				["B"] = 0.1373,
				["G"] = 0.1373,
				["useOpacity"] = true,
				["R"] = 0.1373,
				["useBackground"] = true,
				["file"] = "Interface\\Addons\\XPerl\\images\\XPerl_ThinEdge",
				["O"] = 0,
				["insets"] = 0,
			},
			["barTexture"] = "Bars",
			["BARS"] = {
				["useBackground"] = true,
				["useOpacity"] = true,
				["R"] = 0.7,
				["O"] = 1,
				["mode"] = 1,
				["G"] = 0.7,
				["B"] = 0.7,
			},
			["barBackBrightness"] = 30,
			["classColorsBack"] = false,
			["classColorsBar"] = false,
			["TEXT"] = {
				["TG"] = 0.82,
				["maxChars"] = 0,
				["R"] = 0,
				["B"] = 0,
				["TB"] = 0,
				["O"] = 0.75,
				["useText"] = true,
				["G"] = 0,
				["useOpacity"] = true,
				["font"] = "",
				["TO"] = 1,
				["useBackground"] = true,
				["TR"] = 1,
				["textSizeLife"] = 8,
				["textSize"] = 11,
			},
			["TOT"] = {
				["TR"] = 1,
				["TO"] = 1,
				["TB"] = 1,
				["useText"] = true,
				["TG"] = 1,
			},
			["classColorsHeader"] = false,
			["HEADER"] = {
				["TG"] = 0.859,
				["B"] = 0.6,
				["TB"] = 0.38,
				["barTexture"] = "VuhDo - Concave, dark",
				["G"] = 0.6,
				["TR"] = 1,
				["font"] = "",
				["TO"] = 1,
				["useBackground"] = true,
				["textSize"] = 10,
				["useText"] = true,
				["O"] = 0.6,
				["R"] = 0.6,
			},
			["classColorsName"] = false,
		},
		["HOTS"] = {
			["SLOTS"] = {
				"恢复", -- [1]
				"痛苦压制", -- [2]
				"愈合祷言", -- [3]
				"驱除疾病", -- [4]
				"恩赐", -- [5]
			},
			["BARS"] = {
				["show"] = false,
				["radioValue"] = 1,
				["invertOrientation"] = false,
				["invertDirection"] = false,
				["width"] = 25,
			},
			["SLOTCFG"] = {
				{
					true, -- [1]
					false, -- [2]
				}, -- [1]
				{
					true, -- [1]
					false, -- [2]
				}, -- [2]
				{
					true, -- [1]
					false, -- [2]
				}, -- [3]
				{
					true, -- [1]
					true, -- [2]
				}, -- [4]
				{
					true, -- [1]
					false, -- [2]
				}, -- [5]
				{
					true, -- [1]
					false, -- [2]
				}, -- [6]
				{
					true, -- [1]
					false, -- [2]
				}, -- [7]
			},
			["isFlatTexture"] = false,
			["show"] = true,
			["iconRadioValue"] = 2,
			["radioValue"] = 20,
			["stacksRadioValue"] = 3,
			["size"] = 70,
		},
		["SCALING"] = {
			["targetWidth"] = 30,
			["maxColumnsWhenStructured"] = 8,
			["ommitEmptyWhenStructured"] = true,
			["showTarget"] = false,
			["maxRowsWhenLoose"] = 6,
			["headerWidth"] = 50,
			["isDamFlash"] = true,
			["showManaBars"] = true,
			["borderGapY"] = 2,
			["alignBottom"] = false,
			["headerHeight"] = 20,
			["arrangeHorizontal"] = false,
			["scale"] = 0.95,
			["vertical"] = false,
			["targetOrientation"] = 1,
			["raidIconScale"] = 0.6,
			["sideLeftWidth"] = 6,
			["headerSpacing"] = 5,
			["borderGapX"] = 2,
			["invertGrowth"] = false,
			["barWidth"] = 50,
			["damFlashFactor"] = 0.75,
			["totSpacing"] = 3,
			["barHeight"] = 45,
			["targetSpacing"] = 3,
			["showRageBars"] = 1,
			["showTot"] = false,
			["sideRightWidth"] = 6,
			["manaBarHeight"] = 3,
			["columnSpacing"] = 2,
			["totWidth"] = 30,
			["isPlayerOnTop"] = true,
			["rowSpacing"] = 2,
		},
		["IS_RAID_ICON"] = 1,
		["LIFE_TEXT"] = {
			["hideIrrelevant"] = false,
			["position"] = 3,
			["mode"] = 1,
			["verbose"] = false,
		},
		["ID_TEXT"] = {
			["showTags"] = true,
			["showClass"] = false,
			["showName"] = true,
			["version"] = 2,
			["position"] = "TOP+TOP",
			["yAdjust"] = 9,
			["xAdjust"] = 0,
			["showPetOwners"] = true,
		},
	}, -- [5]
	{
		["OVERHEAL_TEXT"] = {
			["show"] = true,
			["yAdjust"] = 0,
			["point"] = "LEFT",
			["scale"] = 1,
			["xAdjust"] = 0,
		},
		["POSITION"] = {
			["y"] = 488,
			["x"] = 280,
			["scale"] = 1,
			["relativePoint"] = "BOTTOMLEFT",
			["orientation"] = "TOPLEFT",
			["height"] = 200,
			["growth"] = "TOPLEFT",
			["width"] = 200,
		},
		["RAID_ICON"] = {
			["show"] = true,
			["yAdjust"] = -20,
			["point"] = "TOP",
			["scale"] = 1,
			["xAdjust"] = 0,
		},
		["frameStrata"] = "MEDIUM",
		["MODEL"] = {
			["ordering"] = 0,
			["sort"] = 3,
		},
		["TOOLTIP"] = {
			["BACKGROUND"] = {
				["useBackground"] = true,
				["R"] = 0,
				["useOpacity"] = true,
				["O"] = 1,
				["G"] = 0,
				["B"] = 0,
			},
			["point"] = "TOPLEFT",
			["BORDER"] = {
				["useBackground"] = true,
				["R"] = 0,
				["useOpacity"] = true,
				["O"] = 1,
				["G"] = 0,
				["B"] = 0,
			},
			["showBuffs"] = false,
			["y"] = -100,
			["x"] = 100,
			["relativePoint"] = "TOPLEFT",
			["SCALE"] = 1,
			["show"] = true,
			["inFight"] = false,
			["position"] = 2,
		},
		["PANEL_COLOR"] = {
			["BACK"] = {
				["useBackground"] = true,
				["R"] = 0.4314,
				["useOpacity"] = true,
				["O"] = 0.64,
				["G"] = 0.4314,
				["B"] = 0.4314,
			},
			["classColorsBackHeader"] = false,
			["TARGET"] = {
				["TR"] = 1,
				["TO"] = 1,
				["TB"] = 1,
				["useText"] = true,
				["TG"] = 1,
			},
			["BORDER"] = {
				["edgeSize"] = 8,
				["B"] = 0.1373,
				["G"] = 0.1373,
				["useOpacity"] = true,
				["R"] = 0.1373,
				["useBackground"] = true,
				["file"] = "Interface\\Addons\\XPerl\\images\\XPerl_ThinEdge",
				["O"] = 0,
				["insets"] = 0,
			},
			["barTexture"] = "Bars",
			["BARS"] = {
				["useBackground"] = true,
				["useOpacity"] = true,
				["R"] = 0.7,
				["O"] = 1,
				["mode"] = 1,
				["G"] = 0.7,
				["B"] = 0.7,
			},
			["barBackBrightness"] = 30,
			["classColorsBack"] = false,
			["classColorsBar"] = false,
			["TEXT"] = {
				["TG"] = 0.82,
				["maxChars"] = 0,
				["R"] = 0,
				["B"] = 0,
				["TB"] = 0,
				["O"] = 0.75,
				["useText"] = true,
				["G"] = 0,
				["useOpacity"] = true,
				["font"] = "",
				["TO"] = 1,
				["useBackground"] = true,
				["TR"] = 1,
				["textSizeLife"] = 8,
				["textSize"] = 11,
			},
			["TOT"] = {
				["TR"] = 1,
				["TO"] = 1,
				["TB"] = 1,
				["useText"] = true,
				["TG"] = 1,
			},
			["classColorsHeader"] = false,
			["HEADER"] = {
				["TG"] = 0.859,
				["B"] = 0.6,
				["TB"] = 0.38,
				["barTexture"] = "VuhDo - Concave, dark",
				["G"] = 0.6,
				["TR"] = 1,
				["font"] = "",
				["TO"] = 1,
				["useBackground"] = true,
				["textSize"] = 10,
				["useText"] = true,
				["O"] = 0.6,
				["R"] = 0.6,
			},
			["classColorsName"] = false,
		},
		["HOTS"] = {
			["SLOTS"] = {
				"恢复", -- [1]
				"痛苦压制", -- [2]
				"愈合祷言", -- [3]
				"驱除疾病", -- [4]
				"恩赐", -- [5]
			},
			["BARS"] = {
				["show"] = false,
				["radioValue"] = 1,
				["invertOrientation"] = false,
				["invertDirection"] = false,
				["width"] = 25,
			},
			["SLOTCFG"] = {
				{
					true, -- [1]
					false, -- [2]
				}, -- [1]
				{
					true, -- [1]
					false, -- [2]
				}, -- [2]
				{
					true, -- [1]
					false, -- [2]
				}, -- [3]
				{
					true, -- [1]
					true, -- [2]
				}, -- [4]
				{
					true, -- [1]
					false, -- [2]
				}, -- [5]
				{
					true, -- [1]
					false, -- [2]
				}, -- [6]
				{
					true, -- [1]
					false, -- [2]
				}, -- [7]
			},
			["isFlatTexture"] = false,
			["show"] = true,
			["iconRadioValue"] = 2,
			["radioValue"] = 20,
			["stacksRadioValue"] = 3,
			["size"] = 70,
		},
		["SCALING"] = {
			["targetWidth"] = 30,
			["maxColumnsWhenStructured"] = 8,
			["ommitEmptyWhenStructured"] = true,
			["showTarget"] = false,
			["maxRowsWhenLoose"] = 6,
			["headerWidth"] = 50,
			["isDamFlash"] = true,
			["showManaBars"] = true,
			["borderGapY"] = 2,
			["alignBottom"] = false,
			["headerHeight"] = 20,
			["arrangeHorizontal"] = false,
			["scale"] = 0.95,
			["vertical"] = false,
			["targetOrientation"] = 1,
			["raidIconScale"] = 0.6,
			["sideLeftWidth"] = 6,
			["headerSpacing"] = 5,
			["borderGapX"] = 2,
			["invertGrowth"] = false,
			["barWidth"] = 50,
			["damFlashFactor"] = 0.75,
			["totSpacing"] = 3,
			["barHeight"] = 45,
			["targetSpacing"] = 3,
			["showRageBars"] = 1,
			["showTot"] = false,
			["sideRightWidth"] = 6,
			["manaBarHeight"] = 3,
			["columnSpacing"] = 2,
			["totWidth"] = 30,
			["isPlayerOnTop"] = true,
			["rowSpacing"] = 2,
		},
		["IS_RAID_ICON"] = 1,
		["LIFE_TEXT"] = {
			["hideIrrelevant"] = false,
			["position"] = 3,
			["mode"] = 1,
			["verbose"] = false,
		},
		["ID_TEXT"] = {
			["showTags"] = true,
			["showClass"] = false,
			["showName"] = true,
			["version"] = 2,
			["position"] = "TOP+TOP",
			["yAdjust"] = 9,
			["xAdjust"] = 0,
			["showPetOwners"] = true,
		},
	}, -- [6]
	{
		["OVERHEAL_TEXT"] = {
			["show"] = true,
			["yAdjust"] = 0,
			["point"] = "LEFT",
			["scale"] = 1,
			["xAdjust"] = 0,
		},
		["POSITION"] = {
			["y"] = 458,
			["x"] = 310,
			["scale"] = 1,
			["relativePoint"] = "BOTTOMLEFT",
			["orientation"] = "TOPLEFT",
			["height"] = 200,
			["growth"] = "TOPLEFT",
			["width"] = 200,
		},
		["RAID_ICON"] = {
			["show"] = true,
			["yAdjust"] = -20,
			["point"] = "TOP",
			["scale"] = 1,
			["xAdjust"] = 0,
		},
		["frameStrata"] = "MEDIUM",
		["MODEL"] = {
			["ordering"] = 0,
			["sort"] = 3,
		},
		["TOOLTIP"] = {
			["BACKGROUND"] = {
				["useBackground"] = true,
				["R"] = 0,
				["useOpacity"] = true,
				["O"] = 1,
				["G"] = 0,
				["B"] = 0,
			},
			["point"] = "TOPLEFT",
			["BORDER"] = {
				["useBackground"] = true,
				["R"] = 0,
				["useOpacity"] = true,
				["O"] = 1,
				["G"] = 0,
				["B"] = 0,
			},
			["showBuffs"] = false,
			["y"] = -100,
			["x"] = 100,
			["relativePoint"] = "TOPLEFT",
			["SCALE"] = 1,
			["show"] = true,
			["inFight"] = false,
			["position"] = 2,
		},
		["PANEL_COLOR"] = {
			["BACK"] = {
				["useBackground"] = true,
				["R"] = 0.4314,
				["useOpacity"] = true,
				["O"] = 0.64,
				["G"] = 0.4314,
				["B"] = 0.4314,
			},
			["classColorsBackHeader"] = false,
			["TARGET"] = {
				["TR"] = 1,
				["TO"] = 1,
				["TB"] = 1,
				["useText"] = true,
				["TG"] = 1,
			},
			["BORDER"] = {
				["edgeSize"] = 8,
				["B"] = 0.1373,
				["G"] = 0.1373,
				["useOpacity"] = true,
				["R"] = 0.1373,
				["useBackground"] = true,
				["file"] = "Interface\\Addons\\XPerl\\images\\XPerl_ThinEdge",
				["O"] = 0,
				["insets"] = 0,
			},
			["barTexture"] = "Bars",
			["BARS"] = {
				["useBackground"] = true,
				["useOpacity"] = true,
				["R"] = 0.7,
				["O"] = 1,
				["mode"] = 1,
				["G"] = 0.7,
				["B"] = 0.7,
			},
			["barBackBrightness"] = 30,
			["classColorsBack"] = false,
			["classColorsBar"] = false,
			["TEXT"] = {
				["TG"] = 0.82,
				["maxChars"] = 0,
				["R"] = 0,
				["B"] = 0,
				["TB"] = 0,
				["O"] = 0.75,
				["useText"] = true,
				["G"] = 0,
				["useOpacity"] = true,
				["font"] = "",
				["TO"] = 1,
				["useBackground"] = true,
				["TR"] = 1,
				["textSizeLife"] = 8,
				["textSize"] = 11,
			},
			["TOT"] = {
				["TR"] = 1,
				["TO"] = 1,
				["TB"] = 1,
				["useText"] = true,
				["TG"] = 1,
			},
			["classColorsHeader"] = false,
			["HEADER"] = {
				["TG"] = 0.859,
				["B"] = 0.6,
				["TB"] = 0.38,
				["barTexture"] = "VuhDo - Concave, dark",
				["G"] = 0.6,
				["TR"] = 1,
				["font"] = "",
				["TO"] = 1,
				["useBackground"] = true,
				["textSize"] = 10,
				["useText"] = true,
				["O"] = 0.6,
				["R"] = 0.6,
			},
			["classColorsName"] = false,
		},
		["HOTS"] = {
			["SLOTS"] = {
				"恢复", -- [1]
				"痛苦压制", -- [2]
				"愈合祷言", -- [3]
				"驱除疾病", -- [4]
				"恩赐", -- [5]
			},
			["BARS"] = {
				["show"] = false,
				["radioValue"] = 1,
				["invertOrientation"] = false,
				["invertDirection"] = false,
				["width"] = 25,
			},
			["SLOTCFG"] = {
				{
					true, -- [1]
					false, -- [2]
				}, -- [1]
				{
					true, -- [1]
					false, -- [2]
				}, -- [2]
				{
					true, -- [1]
					false, -- [2]
				}, -- [3]
				{
					true, -- [1]
					true, -- [2]
				}, -- [4]
				{
					true, -- [1]
					false, -- [2]
				}, -- [5]
				{
					true, -- [1]
					false, -- [2]
				}, -- [6]
				{
					true, -- [1]
					false, -- [2]
				}, -- [7]
			},
			["isFlatTexture"] = false,
			["show"] = true,
			["iconRadioValue"] = 2,
			["radioValue"] = 20,
			["stacksRadioValue"] = 3,
			["size"] = 70,
		},
		["SCALING"] = {
			["targetWidth"] = 30,
			["maxColumnsWhenStructured"] = 8,
			["ommitEmptyWhenStructured"] = true,
			["showTarget"] = false,
			["maxRowsWhenLoose"] = 6,
			["headerWidth"] = 50,
			["isDamFlash"] = true,
			["showManaBars"] = true,
			["borderGapY"] = 2,
			["alignBottom"] = false,
			["headerHeight"] = 20,
			["arrangeHorizontal"] = false,
			["scale"] = 0.95,
			["vertical"] = false,
			["targetOrientation"] = 1,
			["raidIconScale"] = 0.6,
			["sideLeftWidth"] = 6,
			["headerSpacing"] = 5,
			["borderGapX"] = 2,
			["invertGrowth"] = false,
			["barWidth"] = 50,
			["damFlashFactor"] = 0.75,
			["totSpacing"] = 3,
			["barHeight"] = 45,
			["targetSpacing"] = 3,
			["showRageBars"] = 1,
			["showTot"] = false,
			["sideRightWidth"] = 6,
			["manaBarHeight"] = 3,
			["columnSpacing"] = 2,
			["totWidth"] = 30,
			["isPlayerOnTop"] = true,
			["rowSpacing"] = 2,
		},
		["IS_RAID_ICON"] = 1,
		["LIFE_TEXT"] = {
			["hideIrrelevant"] = false,
			["position"] = 3,
			["mode"] = 1,
			["verbose"] = false,
		},
		["ID_TEXT"] = {
			["showTags"] = true,
			["showClass"] = false,
			["showName"] = true,
			["version"] = 2,
			["position"] = "TOP+TOP",
			["yAdjust"] = 9,
			["xAdjust"] = 0,
			["showPetOwners"] = true,
		},
	}, -- [7]
	{
		["OVERHEAL_TEXT"] = {
			["show"] = true,
			["yAdjust"] = 0,
			["point"] = "LEFT",
			["scale"] = 1,
			["xAdjust"] = 0,
		},
		["POSITION"] = {
			["y"] = 428,
			["x"] = 340,
			["scale"] = 1,
			["relativePoint"] = "BOTTOMLEFT",
			["orientation"] = "TOPLEFT",
			["height"] = 200,
			["growth"] = "TOPLEFT",
			["width"] = 200,
		},
		["RAID_ICON"] = {
			["show"] = true,
			["yAdjust"] = -20,
			["point"] = "TOP",
			["scale"] = 1,
			["xAdjust"] = 0,
		},
		["frameStrata"] = "MEDIUM",
		["MODEL"] = {
			["ordering"] = 0,
			["sort"] = 3,
		},
		["TOOLTIP"] = {
			["BACKGROUND"] = {
				["useBackground"] = true,
				["R"] = 0,
				["useOpacity"] = true,
				["O"] = 1,
				["G"] = 0,
				["B"] = 0,
			},
			["point"] = "TOPLEFT",
			["BORDER"] = {
				["useBackground"] = true,
				["R"] = 0,
				["useOpacity"] = true,
				["O"] = 1,
				["G"] = 0,
				["B"] = 0,
			},
			["showBuffs"] = false,
			["y"] = -100,
			["x"] = 100,
			["relativePoint"] = "TOPLEFT",
			["SCALE"] = 1,
			["show"] = true,
			["inFight"] = false,
			["position"] = 2,
		},
		["PANEL_COLOR"] = {
			["BACK"] = {
				["useBackground"] = true,
				["R"] = 0.4314,
				["useOpacity"] = true,
				["O"] = 0.64,
				["G"] = 0.4314,
				["B"] = 0.4314,
			},
			["classColorsBackHeader"] = false,
			["TARGET"] = {
				["TR"] = 1,
				["TO"] = 1,
				["TB"] = 1,
				["useText"] = true,
				["TG"] = 1,
			},
			["BORDER"] = {
				["edgeSize"] = 8,
				["B"] = 0.1373,
				["G"] = 0.1373,
				["useOpacity"] = true,
				["R"] = 0.1373,
				["useBackground"] = true,
				["file"] = "Interface\\Addons\\XPerl\\images\\XPerl_ThinEdge",
				["O"] = 0,
				["insets"] = 0,
			},
			["barTexture"] = "Bars",
			["BARS"] = {
				["useBackground"] = true,
				["useOpacity"] = true,
				["R"] = 0.7,
				["O"] = 1,
				["mode"] = 1,
				["G"] = 0.7,
				["B"] = 0.7,
			},
			["barBackBrightness"] = 30,
			["classColorsBack"] = false,
			["classColorsBar"] = false,
			["TEXT"] = {
				["TG"] = 0.82,
				["maxChars"] = 0,
				["R"] = 0,
				["B"] = 0,
				["TB"] = 0,
				["O"] = 0.75,
				["useText"] = true,
				["G"] = 0,
				["useOpacity"] = true,
				["font"] = "",
				["TO"] = 1,
				["useBackground"] = true,
				["TR"] = 1,
				["textSizeLife"] = 8,
				["textSize"] = 11,
			},
			["TOT"] = {
				["TR"] = 1,
				["TO"] = 1,
				["TB"] = 1,
				["useText"] = true,
				["TG"] = 1,
			},
			["classColorsHeader"] = false,
			["HEADER"] = {
				["TG"] = 0.859,
				["B"] = 0.6,
				["TB"] = 0.38,
				["barTexture"] = "VuhDo - Concave, dark",
				["G"] = 0.6,
				["TR"] = 1,
				["font"] = "",
				["TO"] = 1,
				["useBackground"] = true,
				["textSize"] = 10,
				["useText"] = true,
				["O"] = 0.6,
				["R"] = 0.6,
			},
			["classColorsName"] = false,
		},
		["HOTS"] = {
			["SLOTS"] = {
				"恢复", -- [1]
				"痛苦压制", -- [2]
				"愈合祷言", -- [3]
				"驱除疾病", -- [4]
				"恩赐", -- [5]
			},
			["BARS"] = {
				["show"] = false,
				["radioValue"] = 1,
				["invertOrientation"] = false,
				["invertDirection"] = false,
				["width"] = 25,
			},
			["SLOTCFG"] = {
				{
					true, -- [1]
					false, -- [2]
				}, -- [1]
				{
					true, -- [1]
					false, -- [2]
				}, -- [2]
				{
					true, -- [1]
					false, -- [2]
				}, -- [3]
				{
					true, -- [1]
					true, -- [2]
				}, -- [4]
				{
					true, -- [1]
					false, -- [2]
				}, -- [5]
				{
					true, -- [1]
					false, -- [2]
				}, -- [6]
				{
					true, -- [1]
					false, -- [2]
				}, -- [7]
			},
			["isFlatTexture"] = false,
			["show"] = true,
			["iconRadioValue"] = 2,
			["radioValue"] = 20,
			["stacksRadioValue"] = 3,
			["size"] = 70,
		},
		["SCALING"] = {
			["targetWidth"] = 30,
			["maxColumnsWhenStructured"] = 8,
			["ommitEmptyWhenStructured"] = true,
			["showTarget"] = false,
			["maxRowsWhenLoose"] = 6,
			["headerWidth"] = 50,
			["isDamFlash"] = true,
			["showManaBars"] = true,
			["borderGapY"] = 2,
			["alignBottom"] = false,
			["headerHeight"] = 20,
			["arrangeHorizontal"] = false,
			["scale"] = 0.95,
			["vertical"] = false,
			["targetOrientation"] = 1,
			["raidIconScale"] = 0.6,
			["sideLeftWidth"] = 6,
			["headerSpacing"] = 5,
			["borderGapX"] = 2,
			["invertGrowth"] = false,
			["barWidth"] = 50,
			["damFlashFactor"] = 0.75,
			["totSpacing"] = 3,
			["barHeight"] = 45,
			["targetSpacing"] = 3,
			["showRageBars"] = 1,
			["showTot"] = false,
			["sideRightWidth"] = 6,
			["manaBarHeight"] = 3,
			["columnSpacing"] = 2,
			["totWidth"] = 30,
			["isPlayerOnTop"] = true,
			["rowSpacing"] = 2,
		},
		["IS_RAID_ICON"] = 1,
		["LIFE_TEXT"] = {
			["hideIrrelevant"] = false,
			["position"] = 3,
			["mode"] = 1,
			["verbose"] = false,
		},
		["ID_TEXT"] = {
			["showTags"] = true,
			["showClass"] = false,
			["showName"] = true,
			["version"] = 2,
			["position"] = "TOP+TOP",
			["yAdjust"] = 9,
			["xAdjust"] = 0,
			["showPetOwners"] = true,
		},
	}, -- [8]
	{
		["OVERHEAL_TEXT"] = {
			["show"] = true,
			["yAdjust"] = 0,
			["point"] = "LEFT",
			["scale"] = 1,
			["xAdjust"] = 0,
		},
		["POSITION"] = {
			["y"] = 398,
			["x"] = 370,
			["scale"] = 1,
			["relativePoint"] = "BOTTOMLEFT",
			["orientation"] = "TOPLEFT",
			["height"] = 200,
			["growth"] = "TOPLEFT",
			["width"] = 200,
		},
		["RAID_ICON"] = {
			["show"] = true,
			["yAdjust"] = -20,
			["point"] = "TOP",
			["scale"] = 1,
			["xAdjust"] = 0,
		},
		["frameStrata"] = "MEDIUM",
		["MODEL"] = {
			["ordering"] = 0,
			["sort"] = 3,
		},
		["TOOLTIP"] = {
			["BACKGROUND"] = {
				["useBackground"] = true,
				["R"] = 0,
				["useOpacity"] = true,
				["O"] = 1,
				["G"] = 0,
				["B"] = 0,
			},
			["point"] = "TOPLEFT",
			["BORDER"] = {
				["useBackground"] = true,
				["R"] = 0,
				["useOpacity"] = true,
				["O"] = 1,
				["G"] = 0,
				["B"] = 0,
			},
			["showBuffs"] = false,
			["y"] = -100,
			["x"] = 100,
			["relativePoint"] = "TOPLEFT",
			["SCALE"] = 1,
			["show"] = true,
			["inFight"] = false,
			["position"] = 2,
		},
		["PANEL_COLOR"] = {
			["BACK"] = {
				["useBackground"] = true,
				["R"] = 0.4314,
				["useOpacity"] = true,
				["O"] = 0.64,
				["G"] = 0.4314,
				["B"] = 0.4314,
			},
			["classColorsBackHeader"] = false,
			["TARGET"] = {
				["TR"] = 1,
				["TO"] = 1,
				["TB"] = 1,
				["useText"] = true,
				["TG"] = 1,
			},
			["BORDER"] = {
				["edgeSize"] = 8,
				["B"] = 0.1373,
				["G"] = 0.1373,
				["useOpacity"] = true,
				["R"] = 0.1373,
				["useBackground"] = true,
				["file"] = "Interface\\Addons\\XPerl\\images\\XPerl_ThinEdge",
				["O"] = 0,
				["insets"] = 0,
			},
			["barTexture"] = "Bars",
			["BARS"] = {
				["useBackground"] = true,
				["useOpacity"] = true,
				["R"] = 0.7,
				["O"] = 1,
				["mode"] = 1,
				["G"] = 0.7,
				["B"] = 0.7,
			},
			["barBackBrightness"] = 30,
			["classColorsBack"] = false,
			["classColorsBar"] = false,
			["TEXT"] = {
				["TG"] = 0.82,
				["maxChars"] = 0,
				["R"] = 0,
				["B"] = 0,
				["TB"] = 0,
				["O"] = 0.75,
				["useText"] = true,
				["G"] = 0,
				["useOpacity"] = true,
				["font"] = "",
				["TO"] = 1,
				["useBackground"] = true,
				["TR"] = 1,
				["textSizeLife"] = 8,
				["textSize"] = 11,
			},
			["TOT"] = {
				["TR"] = 1,
				["TO"] = 1,
				["TB"] = 1,
				["useText"] = true,
				["TG"] = 1,
			},
			["classColorsHeader"] = false,
			["HEADER"] = {
				["TG"] = 0.859,
				["B"] = 0.6,
				["TB"] = 0.38,
				["barTexture"] = "VuhDo - Concave, dark",
				["G"] = 0.6,
				["TR"] = 1,
				["font"] = "",
				["TO"] = 1,
				["useBackground"] = true,
				["textSize"] = 10,
				["useText"] = true,
				["O"] = 0.6,
				["R"] = 0.6,
			},
			["classColorsName"] = false,
		},
		["HOTS"] = {
			["SLOTS"] = {
				"恢复", -- [1]
				"痛苦压制", -- [2]
				"愈合祷言", -- [3]
				"驱除疾病", -- [4]
				"恩赐", -- [5]
			},
			["BARS"] = {
				["show"] = false,
				["radioValue"] = 1,
				["invertOrientation"] = false,
				["invertDirection"] = false,
				["width"] = 25,
			},
			["SLOTCFG"] = {
				{
					true, -- [1]
					false, -- [2]
				}, -- [1]
				{
					true, -- [1]
					false, -- [2]
				}, -- [2]
				{
					true, -- [1]
					false, -- [2]
				}, -- [3]
				{
					true, -- [1]
					true, -- [2]
				}, -- [4]
				{
					true, -- [1]
					false, -- [2]
				}, -- [5]
				{
					true, -- [1]
					false, -- [2]
				}, -- [6]
				{
					true, -- [1]
					false, -- [2]
				}, -- [7]
			},
			["isFlatTexture"] = false,
			["show"] = true,
			["iconRadioValue"] = 2,
			["radioValue"] = 20,
			["stacksRadioValue"] = 3,
			["size"] = 70,
		},
		["SCALING"] = {
			["targetWidth"] = 30,
			["maxColumnsWhenStructured"] = 8,
			["ommitEmptyWhenStructured"] = true,
			["showTarget"] = false,
			["maxRowsWhenLoose"] = 6,
			["headerWidth"] = 50,
			["isDamFlash"] = true,
			["showManaBars"] = true,
			["borderGapY"] = 2,
			["alignBottom"] = false,
			["headerHeight"] = 20,
			["arrangeHorizontal"] = false,
			["scale"] = 0.95,
			["vertical"] = false,
			["targetOrientation"] = 1,
			["raidIconScale"] = 0.6,
			["sideLeftWidth"] = 6,
			["headerSpacing"] = 5,
			["borderGapX"] = 2,
			["invertGrowth"] = false,
			["barWidth"] = 50,
			["damFlashFactor"] = 0.75,
			["totSpacing"] = 3,
			["barHeight"] = 45,
			["targetSpacing"] = 3,
			["showRageBars"] = 1,
			["showTot"] = false,
			["sideRightWidth"] = 6,
			["manaBarHeight"] = 3,
			["columnSpacing"] = 2,
			["totWidth"] = 30,
			["isPlayerOnTop"] = true,
			["rowSpacing"] = 2,
		},
		["IS_RAID_ICON"] = 1,
		["LIFE_TEXT"] = {
			["hideIrrelevant"] = false,
			["position"] = 3,
			["mode"] = 1,
			["verbose"] = false,
		},
		["ID_TEXT"] = {
			["showTags"] = true,
			["showClass"] = false,
			["showName"] = true,
			["version"] = 2,
			["position"] = "TOP+TOP",
			["yAdjust"] = 9,
			["xAdjust"] = 0,
			["showPetOwners"] = true,
		},
	}, -- [9]
	{
		["OVERHEAL_TEXT"] = {
			["show"] = true,
			["yAdjust"] = 0,
			["point"] = "LEFT",
			["scale"] = 1,
			["xAdjust"] = 0,
		},
		["POSITION"] = {
			["y"] = 368,
			["x"] = 400,
			["scale"] = 1,
			["relativePoint"] = "BOTTOMLEFT",
			["orientation"] = "TOPLEFT",
			["height"] = 200,
			["growth"] = "TOPLEFT",
			["width"] = 200,
		},
		["RAID_ICON"] = {
			["show"] = true,
			["yAdjust"] = -20,
			["point"] = "TOP",
			["scale"] = 1,
			["xAdjust"] = 0,
		},
		["frameStrata"] = "MEDIUM",
		["MODEL"] = {
			["ordering"] = 0,
			["sort"] = 3,
		},
		["TOOLTIP"] = {
			["BACKGROUND"] = {
				["useBackground"] = true,
				["R"] = 0,
				["useOpacity"] = true,
				["O"] = 1,
				["G"] = 0,
				["B"] = 0,
			},
			["point"] = "TOPLEFT",
			["BORDER"] = {
				["useBackground"] = true,
				["R"] = 0,
				["useOpacity"] = true,
				["O"] = 1,
				["G"] = 0,
				["B"] = 0,
			},
			["showBuffs"] = false,
			["y"] = -100,
			["x"] = 100,
			["relativePoint"] = "TOPLEFT",
			["SCALE"] = 1,
			["show"] = true,
			["inFight"] = false,
			["position"] = 2,
		},
		["PANEL_COLOR"] = {
			["BACK"] = {
				["useBackground"] = true,
				["R"] = 0.4314,
				["useOpacity"] = true,
				["O"] = 0.64,
				["G"] = 0.4314,
				["B"] = 0.4314,
			},
			["classColorsBackHeader"] = false,
			["TARGET"] = {
				["TR"] = 1,
				["TO"] = 1,
				["TB"] = 1,
				["useText"] = true,
				["TG"] = 1,
			},
			["BORDER"] = {
				["edgeSize"] = 8,
				["B"] = 0.1373,
				["G"] = 0.1373,
				["useOpacity"] = true,
				["R"] = 0.1373,
				["useBackground"] = true,
				["file"] = "Interface\\Addons\\XPerl\\images\\XPerl_ThinEdge",
				["O"] = 0,
				["insets"] = 0,
			},
			["barTexture"] = "Bars",
			["BARS"] = {
				["useBackground"] = true,
				["useOpacity"] = true,
				["R"] = 0.7,
				["O"] = 1,
				["mode"] = 1,
				["G"] = 0.7,
				["B"] = 0.7,
			},
			["barBackBrightness"] = 30,
			["classColorsBack"] = false,
			["classColorsBar"] = false,
			["TEXT"] = {
				["TG"] = 0.82,
				["maxChars"] = 0,
				["R"] = 0,
				["B"] = 0,
				["TB"] = 0,
				["O"] = 0.75,
				["useText"] = true,
				["G"] = 0,
				["useOpacity"] = true,
				["font"] = "",
				["TO"] = 1,
				["useBackground"] = true,
				["TR"] = 1,
				["textSizeLife"] = 8,
				["textSize"] = 11,
			},
			["TOT"] = {
				["TR"] = 1,
				["TO"] = 1,
				["TB"] = 1,
				["useText"] = true,
				["TG"] = 1,
			},
			["classColorsHeader"] = false,
			["HEADER"] = {
				["TG"] = 0.859,
				["B"] = 0.6,
				["TB"] = 0.38,
				["barTexture"] = "VuhDo - Concave, dark",
				["G"] = 0.6,
				["TR"] = 1,
				["font"] = "",
				["TO"] = 1,
				["useBackground"] = true,
				["textSize"] = 10,
				["useText"] = true,
				["O"] = 0.6,
				["R"] = 0.6,
			},
			["classColorsName"] = false,
		},
		["HOTS"] = {
			["SLOTS"] = {
				"恢复", -- [1]
				"痛苦压制", -- [2]
				"愈合祷言", -- [3]
				"驱除疾病", -- [4]
				"恩赐", -- [5]
			},
			["BARS"] = {
				["show"] = false,
				["radioValue"] = 1,
				["invertOrientation"] = false,
				["invertDirection"] = false,
				["width"] = 25,
			},
			["SLOTCFG"] = {
				{
					true, -- [1]
					false, -- [2]
				}, -- [1]
				{
					true, -- [1]
					false, -- [2]
				}, -- [2]
				{
					true, -- [1]
					false, -- [2]
				}, -- [3]
				{
					true, -- [1]
					true, -- [2]
				}, -- [4]
				{
					true, -- [1]
					false, -- [2]
				}, -- [5]
				{
					true, -- [1]
					false, -- [2]
				}, -- [6]
				{
					true, -- [1]
					false, -- [2]
				}, -- [7]
			},
			["isFlatTexture"] = false,
			["show"] = true,
			["iconRadioValue"] = 2,
			["radioValue"] = 20,
			["stacksRadioValue"] = 3,
			["size"] = 70,
		},
		["SCALING"] = {
			["targetWidth"] = 30,
			["maxColumnsWhenStructured"] = 8,
			["ommitEmptyWhenStructured"] = true,
			["showTarget"] = false,
			["maxRowsWhenLoose"] = 6,
			["headerWidth"] = 50,
			["isDamFlash"] = true,
			["showManaBars"] = true,
			["borderGapY"] = 2,
			["alignBottom"] = false,
			["headerHeight"] = 20,
			["arrangeHorizontal"] = false,
			["scale"] = 0.95,
			["vertical"] = false,
			["targetOrientation"] = 1,
			["raidIconScale"] = 0.6,
			["sideLeftWidth"] = 6,
			["headerSpacing"] = 5,
			["borderGapX"] = 2,
			["invertGrowth"] = false,
			["barWidth"] = 50,
			["damFlashFactor"] = 0.75,
			["totSpacing"] = 3,
			["barHeight"] = 45,
			["targetSpacing"] = 3,
			["showRageBars"] = 1,
			["showTot"] = false,
			["sideRightWidth"] = 6,
			["manaBarHeight"] = 3,
			["columnSpacing"] = 2,
			["totWidth"] = 30,
			["isPlayerOnTop"] = true,
			["rowSpacing"] = 2,
		},
		["IS_RAID_ICON"] = 1,
		["LIFE_TEXT"] = {
			["hideIrrelevant"] = false,
			["position"] = 3,
			["mode"] = 1,
			["verbose"] = false,
		},
		["ID_TEXT"] = {
			["showTags"] = true,
			["showClass"] = false,
			["showName"] = true,
			["version"] = 2,
			["position"] = "TOP+TOP",
			["yAdjust"] = 9,
			["xAdjust"] = 0,
			["showPetOwners"] = true,
		},
	}, -- [10]
	["RAID_ICON_FILTER"] = {
		true, -- [1]
		true, -- [2]
		true, -- [3]
		true, -- [4]
		true, -- [5]
		true, -- [6]
		true, -- [7]
		true, -- [8]
	},
	["PANEL_COLOR"] = {
		["TEXT"] = {
			["TR"] = 1,
			["TO"] = 1,
			["TB"] = 0,
			["useText"] = true,
			["TG"] = 0.82,
		},
		["HEALTH_TEXT"] = {
			["TR"] = 1,
			["TO"] = 1,
			["TB"] = 0,
			["useText"] = false,
			["TG"] = 0,
		},
		["BARS"] = {
			["useOpacity"] = true,
			["R"] = 0.7,
			["B"] = 0.7,
			["G"] = 0.7,
			["O"] = 1,
			["useBackground"] = true,
		},
		["classColorsName"] = false,
	},
	["HOTS"] = {
		["iconRadioValue"] = 1,
		["SLOTS"] = {
			"恢复", -- [1]
			"真言术：盾", -- [2]
			"!", -- [3]
			"", -- [4]
			"", -- [5]
			"", -- [6]
			"", -- [7]
			"", -- [8]
			"", -- [9]
			"BOUQUET_AOE Advice", -- [10]
		},
		["BARS"] = {
			["radioValue"] = 1,
			["width"] = 25,
		},
		["TIMER_TEXT"] = {
			["X_ADJUST"] = 25,
			["SCALE"] = 60,
			["USE_MONO"] = false,
			["Y_ADJUST"] = 0,
			["FONT"] = "Interface\\AddOns\\VuhDo\\Fonts\\ariblk.ttf",
			["USE_SHADOW"] = false,
			["ANCHOR"] = "BOTTOMRIGHT",
			["USE_OUTLINE"] = true,
		},
		["radioValue"] = 13,
		["SLOTCFG"] = {
			["1"] = {
				["scale"] = 1,
				["mine"] = true,
			},
			["3"] = {
				["scale"] = 1,
				["mine"] = true,
				["others"] = true,
			},
			["2"] = {
				["scale"] = 1,
				["mine"] = true,
				["others"] = true,
			},
			["5"] = {
				["scale"] = 1,
				["mine"] = true,
				["others"] = false,
			},
			["4"] = {
				["scale"] = 1,
				["mine"] = true,
				["others"] = false,
			},
			["7"] = {
				["scale"] = 1,
				["mine"] = true,
				["others"] = false,
			},
			["6"] = {
				["scale"] = 1,
				["mine"] = true,
				["others"] = false,
			},
			["9"] = {
				["scale"] = 1,
				["mine"] = true,
				["others"] = false,
			},
			["8"] = {
				["scale"] = 1,
				["mine"] = true,
				["others"] = false,
			},
			["10"] = {
				["scale"] = 1.5,
				["mine"] = true,
				["others"] = false,
			},
		},
		["stacksRadioValue"] = 2,
		["COUNTER_TEXT"] = {
			["X_ADJUST"] = -25,
			["SCALE"] = 66,
			["USE_MONO"] = false,
			["Y_ADJUST"] = 0,
			["FONT"] = "Interface\\AddOns\\VuhDo\\Fonts\\ariblk.ttf",
			["USE_SHADOW"] = false,
			["ANCHOR"] = "TOP",
			["USE_OUTLINE"] = true,
		},
	},
	["VERSION"] = 4,
	["BAR_COLORS"] = {
		["OVERHEAL_TEXT"] = {
			["TR"] = 0.8,
			["TO"] = 1,
			["TB"] = 0.8,
			["TG"] = 1,
			["useText"] = true,
			["useOpacity"] = true,
		},
		["HOT7"] = {
			["useBackground"] = true,
			["R"] = 1,
			["O"] = 0.75,
			["G"] = 1,
			["B"] = 1,
		},
		["PLAYER_TARGET"] = {
			["useBackground"] = true,
			["R"] = 0.7,
			["O"] = 1,
			["G"] = 0.7,
			["B"] = 0.7,
		},
		["HOT1"] = {
			["TG"] = 0.6,
			["countdownMode"] = 1,
			["B"] = 0.3,
			["TB"] = 0.6,
			["G"] = 0.3,
			["useText"] = true,
			["TR"] = 1,
			["TO"] = 1,
			["isFullDuration"] = false,
			["useBackground"] = true,
			["O"] = 1,
			["R"] = 1,
		},
		["DIRECTION"] = {
			["useBackground"] = true,
			["R"] = 1,
			["B"] = 0.4,
			["O"] = 1,
			["G"] = 0.4,
		},
		["EMERGENCY"] = {
			["TG"] = 0.82,
			["B"] = 0,
			["TB"] = 0,
			["G"] = 0,
			["TR"] = 1,
			["TO"] = 1,
			["useOpacity"] = true,
			["useBackground"] = true,
			["useText"] = true,
			["O"] = 1,
			["R"] = 1,
		},
		["BAR_FRAMES"] = {
			["useBackground"] = true,
			["R"] = 0,
			["useOpacity"] = true,
			["O"] = 0.7,
			["G"] = 0,
			["B"] = 0,
		},
		["RAID_ICONS"] = {
			["1"] = {
				["TG"] = 1,
				["R"] = 1,
				["TB"] = 0.607,
				["G"] = 0.976,
				["TR"] = 0.98,
				["TO"] = 1,
				["B"] = 0.305,
				["useText"] = true,
				["useBackground"] = true,
				["O"] = 1,
				["useOpacity"] = false,
			},
			["filterOnly"] = true,
			["3"] = {
				["TG"] = 0.674,
				["R"] = 0.788,
				["TB"] = 0.921,
				["G"] = 0.29,
				["TR"] = 1,
				["TO"] = 1,
				["B"] = 0.8,
				["useText"] = true,
				["useBackground"] = true,
				["O"] = 1,
				["useOpacity"] = false,
			},
			["2"] = {
				["TG"] = 0.827,
				["R"] = 1,
				["TB"] = 0.419,
				["G"] = 0.513,
				["TR"] = 1,
				["TO"] = 1,
				["B"] = 0.039,
				["useText"] = true,
				["useBackground"] = true,
				["O"] = 1,
				["useOpacity"] = false,
			},
			["enable"] = false,
			["4"] = {
				["TG"] = 1,
				["R"] = 0,
				["TB"] = 0.698,
				["G"] = 0.8,
				["TR"] = 0.698,
				["TO"] = 1,
				["B"] = 0.015,
				["useText"] = true,
				["useBackground"] = true,
				["O"] = 1,
				["useOpacity"] = false,
			},
			["7"] = {
				["TG"] = 0.627,
				["R"] = 0.8,
				["TB"] = 0.619,
				["G"] = 0.184,
				["TR"] = 1,
				["TO"] = 1,
				["B"] = 0.129,
				["useText"] = true,
				["useBackground"] = true,
				["O"] = 1,
				["useOpacity"] = false,
			},
			["6"] = {
				["TG"] = 0.831,
				["R"] = 0.121,
				["TB"] = 1,
				["G"] = 0.69,
				["TR"] = 0.662,
				["TO"] = 1,
				["B"] = 0.972,
				["useText"] = true,
				["useBackground"] = true,
				["O"] = 1,
				["useOpacity"] = false,
			},
			["8"] = {
				["TG"] = 0.231,
				["R"] = 0.847,
				["TB"] = 0.231,
				["G"] = 0.866,
				["TR"] = 0.231,
				["TO"] = 1,
				["B"] = 0.89,
				["useText"] = true,
				["useBackground"] = true,
				["O"] = 1,
				["useOpacity"] = false,
			},
			["5"] = {
				["TG"] = 0.87,
				["B"] = 0.8,
				["TB"] = 1,
				["G"] = 0.717,
				["TR"] = 0.725,
				["TO"] = 1,
				["useOpacity"] = false,
				["useText"] = true,
				["useBackground"] = true,
				["O"] = 1,
				["R"] = 0.466,
			},
		},
		["IRRELEVANT"] = {
			["TG"] = 0.82,
			["B"] = 0.4,
			["TB"] = 0,
			["G"] = 0,
			["TR"] = 1,
			["TO"] = 1,
			["useOpacity"] = true,
			["useBackground"] = false,
			["useText"] = false,
			["O"] = 0.5,
			["R"] = 0,
		},
		["HOT9"] = {
			["TG"] = 1,
			["countdownMode"] = 1,
			["R"] = 0.3,
			["TB"] = 1,
			["G"] = 1,
			["useText"] = true,
			["useBackground"] = true,
			["TO"] = 1,
			["isFullDuration"] = false,
			["TR"] = 0.6,
			["O"] = 1,
			["B"] = 1,
		},
		["HOT_CHARGE_4"] = {
			["TG"] = 1,
			["B"] = 0.8,
			["TB"] = 1,
			["G"] = 0.8,
			["TR"] = 1,
			["TO"] = 1,
			["useText"] = true,
			["useBackground"] = true,
			["O"] = 1,
			["R"] = 0.8,
		},
		["DEBUFF5"] = {
			["useBackground"] = false,
			["useText"] = false,
			["useOpacity"] = false,
		},
		["HOT_CHARGE_3"] = {
			["TG"] = 1,
			["B"] = 0.3,
			["TB"] = 0.6,
			["G"] = 1,
			["TR"] = 0.6,
			["TO"] = 1,
			["useText"] = true,
			["useBackground"] = true,
			["O"] = 1,
			["R"] = 0.3,
		},
		["CLUSTER_GOOD"] = {
			["TG"] = 1,
			["R"] = 0,
			["TB"] = 0,
			["G"] = 0.8,
			["TR"] = 0,
			["TO"] = 1,
			["B"] = 0,
			["useText"] = true,
			["useBackground"] = true,
			["O"] = 1,
			["useOpacity"] = false,
		},
		["DEBUFF_ICON_GLOW"] = {
			["TG"] = 1,
			["R"] = 0.95,
			["TB"] = 0,
			["G"] = 0.95,
			["TR"] = 1,
			["TO"] = 1,
			["B"] = 0.32,
			["useText"] = true,
			["useBackground"] = true,
			["O"] = 1,
			["useOpacity"] = true,
		},
		["DEBUFF3"] = {
			["TG"] = 0.957,
			["B"] = 0.8,
			["TB"] = 1,
			["G"] = 0.4,
			["TR"] = 0.329,
			["TO"] = 1,
			["useOpacity"] = true,
			["useBackground"] = true,
			["useText"] = true,
			["O"] = 1,
			["R"] = 0.4,
		},
		["INCOMING"] = {
			["TG"] = 0.82,
			["B"] = 0,
			["TB"] = 0,
			["G"] = 0,
			["TR"] = 1,
			["TO"] = 1,
			["useOpacity"] = true,
			["useBackground"] = false,
			["useText"] = false,
			["O"] = 0.33,
			["R"] = 0,
		},
		["HOT6"] = {
			["useBackground"] = true,
			["R"] = 1,
			["O"] = 0.75,
			["G"] = 1,
			["B"] = 1,
		},
		["TARGET_ENEMY"] = {
			["TG"] = 0,
			["R"] = 1,
			["TB"] = 0,
			["G"] = 0,
			["TR"] = 1,
			["TO"] = 1,
			["B"] = 0,
			["useText"] = true,
			["useBackground"] = true,
			["O"] = 1,
			["useOpacity"] = true,
		},
		["DEBUFF4"] = {
			["TG"] = 0,
			["B"] = 0.7,
			["TB"] = 1,
			["G"] = 0,
			["TR"] = 1,
			["TO"] = 1,
			["useOpacity"] = true,
			["useBackground"] = true,
			["useText"] = true,
			["O"] = 1,
			["R"] = 0.7,
		},
		["DEBUFF6"] = {
			["TG"] = 0.5,
			["B"] = 0,
			["TB"] = 0,
			["G"] = 0.3,
			["TR"] = 0.8,
			["TO"] = 1,
			["useOpacity"] = true,
			["useBackground"] = true,
			["useText"] = true,
			["O"] = 1,
			["R"] = 0.6,
		},
		["HOT8"] = {
			["useBackground"] = true,
			["R"] = 1,
			["O"] = 0.75,
			["G"] = 1,
			["B"] = 1,
		},
		["useDebuffIcon"] = true,
		["HOT3"] = {
			["TG"] = 1,
			["countdownMode"] = 1,
			["B"] = 1,
			["TB"] = 1,
			["G"] = 1,
			["useText"] = true,
			["TR"] = 1,
			["TO"] = 1,
			["isFullDuration"] = false,
			["useBackground"] = true,
			["O"] = 1,
			["R"] = 1,
		},
		["CHARMED"] = {
			["TG"] = 0.31,
			["B"] = 0.263,
			["TB"] = 0.31,
			["G"] = 0.082,
			["TR"] = 1,
			["TO"] = 1,
			["useOpacity"] = true,
			["useBackground"] = true,
			["useText"] = true,
			["O"] = 1,
			["R"] = 0.51,
		},
		["TARGET_FRIEND"] = {
			["TG"] = 1,
			["R"] = 0,
			["TB"] = 0,
			["G"] = 1,
			["TR"] = 0,
			["TO"] = 1,
			["B"] = 0,
			["useText"] = true,
			["useBackground"] = true,
			["O"] = 1,
			["useOpacity"] = true,
		},
		["NO_EMERGENCY"] = {
			["TG"] = 0.82,
			["B"] = 0.4,
			["TB"] = 0,
			["G"] = 0,
			["TR"] = 1,
			["TO"] = 1,
			["useOpacity"] = true,
			["useBackground"] = true,
			["useText"] = true,
			["O"] = 1,
			["R"] = 0,
		},
		["HOTS"] = {
			["isFadeOut"] = true,
			["WARNING"] = {
				["TG"] = 0.6,
				["lowSecs"] = 3,
				["B"] = 0.2,
				["TB"] = 0.6,
				["G"] = 0.2,
				["TR"] = 1,
				["TO"] = 1,
				["enabled"] = false,
				["useBackground"] = true,
				["useText"] = true,
				["O"] = 1,
				["R"] = 0.5,
			},
			["useSquare"] = true,
			["useCountdown"] = true,
			["useColorText"] = true,
			["useAmount"] = true,
			["TEXT"] = {
				["outline"] = true,
				["shadow"] = false,
			},
			["useColorBack"] = true,
		},
		["SHIELD"] = {
			["TG"] = 0.52,
			["R"] = 0.35,
			["TB"] = 1,
			["G"] = 0.52,
			["TR"] = 0.35,
			["TO"] = 1,
			["B"] = 1,
			["useBackground"] = true,
			["useText"] = false,
			["O"] = 1,
			["useOpacity"] = true,
		},
		["DEBUFF1"] = {
			["TG"] = 1,
			["B"] = 0.8,
			["TB"] = 0.686,
			["G"] = 0.592,
			["TR"] = 0,
			["TO"] = 1,
			["useOpacity"] = true,
			["useBackground"] = true,
			["useText"] = true,
			["O"] = 1,
			["R"] = 0,
		},
		["CLUSTER_FAIR"] = {
			["TG"] = 1,
			["R"] = 0.8,
			["TB"] = 0,
			["G"] = 0.8,
			["TR"] = 1,
			["TO"] = 1,
			["B"] = 0,
			["useText"] = true,
			["useBackground"] = true,
			["O"] = 1,
			["useOpacity"] = false,
		},
		["HOT2"] = {
			["TG"] = 1,
			["countdownMode"] = 1,
			["B"] = 0.3,
			["TB"] = 0.6,
			["G"] = 1,
			["useText"] = true,
			["TR"] = 1,
			["TO"] = 1,
			["isFullDuration"] = false,
			["useBackground"] = true,
			["O"] = 1,
			["R"] = 1,
		},
		["DEAD"] = {
			["TG"] = 0.5,
			["B"] = 0.3,
			["TB"] = 0.5,
			["G"] = 0.3,
			["TR"] = 0.5,
			["TO"] = 1,
			["useOpacity"] = true,
			["useBackground"] = true,
			["useText"] = true,
			["O"] = 0.5,
			["R"] = 0.3,
		},
		["GCD_BAR"] = {
			["useBackground"] = true,
			["R"] = 0.4,
			["B"] = 0.4,
			["O"] = 0.5,
			["G"] = 0.4,
		},
		["OFFLINE"] = {
			["TG"] = 0.576,
			["B"] = 0.298,
			["TB"] = 0.576,
			["G"] = 0.298,
			["TR"] = 0.576,
			["TO"] = 0.58,
			["useOpacity"] = true,
			["useBackground"] = true,
			["useText"] = true,
			["O"] = 0.21,
			["R"] = 0.298,
		},
		["OUTRANGED"] = {
			["TG"] = 0,
			["B"] = 0,
			["TB"] = 0,
			["G"] = 0,
			["TR"] = 0,
			["TO"] = 0.5,
			["useOpacity"] = true,
			["useBackground"] = false,
			["useText"] = false,
			["O"] = 0.25,
			["R"] = 0,
		},
		["TARGET_NEUTRAL"] = {
			["TG"] = 1,
			["R"] = 1,
			["TB"] = 0,
			["G"] = 1,
			["TR"] = 1,
			["TO"] = 1,
			["B"] = 0,
			["useText"] = true,
			["useBackground"] = true,
			["O"] = 1,
			["useOpacity"] = true,
		},
		["TAPPED"] = {
			["TG"] = 0.4,
			["R"] = 0.4,
			["TB"] = 0.4,
			["G"] = 0.4,
			["TR"] = 0.4,
			["TO"] = 1,
			["B"] = 0.4,
			["useText"] = true,
			["useBackground"] = true,
			["O"] = 1,
			["useOpacity"] = true,
		},
		["TARGET"] = {
			["TG"] = 1,
			["R"] = 0,
			["TB"] = 1,
			["G"] = 1,
			["modeText"] = 1,
			["TR"] = 1,
			["B"] = 0,
			["TO"] = 1,
			["useOpacity"] = true,
			["useText"] = true,
			["useBackground"] = true,
			["O"] = 1,
			["modeBack"] = 4,
		},
		["DEBUFF2"] = {
			["TG"] = 0,
			["B"] = 0.4,
			["TB"] = 0,
			["G"] = 0.4,
			["TR"] = 1,
			["TO"] = 1,
			["useOpacity"] = true,
			["useBackground"] = true,
			["useText"] = true,
			["O"] = 1,
			["R"] = 0.8,
		},
		["AGGRO"] = {
			["useBackground"] = true,
			["useOpacity"] = true,
			["R"] = 1,
			["useText"] = false,
			["O"] = 1,
			["G"] = 0,
			["B"] = 0,
		},
		["HOT4"] = {
			["TG"] = 0.6,
			["countdownMode"] = 1,
			["B"] = 1,
			["TB"] = 1,
			["G"] = 0.3,
			["useText"] = true,
			["TR"] = 0.6,
			["TO"] = 1,
			["isFullDuration"] = false,
			["useBackground"] = true,
			["O"] = 1,
			["R"] = 0.3,
		},
		["HOT10"] = {
			["TG"] = 1,
			["countdownMode"] = 1,
			["R"] = 0.3,
			["TB"] = 0.3,
			["G"] = 1,
			["B"] = 0.3,
			["useOpacity"] = false,
			["O"] = 1,
			["TO"] = 1,
			["isClock"] = false,
			["useBackground"] = true,
			["useText"] = true,
			["isFullDuration"] = false,
			["TR"] = 0.6,
		},
		["THREAT"] = {
			["LOW"] = {
				["useBackground"] = true,
				["R"] = 0,
				["B"] = 1,
				["O"] = 1,
				["G"] = 1,
			},
			["HIGH"] = {
				["useBackground"] = true,
				["R"] = 1,
				["B"] = 1,
				["O"] = 1,
				["G"] = 0,
			},
		},
		["DEBUFF_BAR_GLOW"] = {
			["TG"] = 1,
			["R"] = 0.95,
			["TB"] = 0,
			["G"] = 0.95,
			["TR"] = 1,
			["TO"] = 1,
			["B"] = 0.32,
			["useText"] = true,
			["useBackground"] = true,
			["O"] = 1,
			["useOpacity"] = true,
		},
		["DEBUFF0"] = {
			["useBackground"] = false,
			["useText"] = false,
			["useOpacity"] = false,
		},
		["HOT5"] = {
			["TG"] = 0.6,
			["countdownMode"] = 1,
			["B"] = 1,
			["TB"] = 1,
			["G"] = 0.3,
			["useText"] = true,
			["TR"] = 1,
			["TO"] = 1,
			["isFullDuration"] = false,
			["useBackground"] = true,
			["O"] = 1,
			["R"] = 1,
		},
		["LIFE_LEFT"] = {
			["GOOD"] = {
				["useBackground"] = true,
				["R"] = 0,
				["B"] = 0,
				["O"] = 1,
				["G"] = 1,
			},
			["LOW"] = {
				["useBackground"] = true,
				["R"] = 1,
				["B"] = 0,
				["O"] = 1,
				["G"] = 0,
			},
			["FAIR"] = {
				["useBackground"] = true,
				["R"] = 1,
				["B"] = 0,
				["O"] = 1,
				["G"] = 1,
			},
		},
		["HOT_CHARGE_2"] = {
			["TG"] = 1,
			["B"] = 0.3,
			["TB"] = 0.6,
			["G"] = 1,
			["TR"] = 1,
			["TO"] = 1,
			["useText"] = true,
			["useBackground"] = true,
			["O"] = 1,
			["R"] = 1,
		},
	},
}
VUHDO_SPELL_ASSIGNMENTS = {
	["altctrl2"] = {
		[2] = "2",
		[3] = "神圣之灵",
	},
	["altctrl3"] = {
		[2] = "3",
		[3] = "防护暗影",
	},
	["ctrl2"] = {
		"ctrl-", -- [1]
		"2", -- [2]
		"治疗之环", -- [3]
	},
	["shift2"] = {
		"shift-", -- [1]
		"2", -- [2]
		"祛病术", -- [3]
	},
	["shift3"] = {
		"shift-", -- [1]
		"3", -- [2]
		"menu", -- [3]
	},
	["altctrl1"] = {
		[2] = "1",
		[3] = "真言术：韧",
	},
	["ctrl5"] = {
		"ctrl-", -- [1]
		"5", -- [2]
		"愈合祷言", -- [3]
	},
	["ctrlshift1"] = {
		[2] = "1",
		[3] = "驱散魔法",
	},
	["ctrlshift3"] = {
		[2] = "3",
		[3] = "跟随",
	},
	["1"] = {
		"", -- [1]
		"1", -- [2]
		"快速治疗", -- [3]
	},
	["3"] = {
		[2] = "3",
		[3] = "真言术：盾",
	},
	["ctrl4"] = {
		"ctrl-", -- [1]
		"4", -- [2]
		"愈合祷言", -- [3]
	},
	["shift1"] = {
		"shift-", -- [1]
		"1", -- [2]
		"驱散魔法", -- [3]
	},
	["ctrl3"] = {
		"ctrl-", -- [1]
		"3", -- [2]
		"menu", -- [3]
	},
	["alt3"] = {
		[2] = "3",
		[3] = "跟随",
	},
	["alt1"] = {
		"alt-", -- [1]
		"1", -- [2]
		"强效治疗术(等级 1", -- [3]
	},
	["alt2"] = {
		"alt-", -- [1]
		"2", -- [2]
		"强效治疗术", -- [3]
	},
	["ctrlshift2"] = {
		[2] = "2",
		[3] = "祛病术",
	},
	["2"] = {
		"", -- [1]
		"2", -- [2]
		"快速治疗(等级 3", -- [3]
	},
	["5"] = {
		"", -- [1]
		"5", -- [2]
		"恢复", -- [3]
	},
	["ctrl1"] = {
		"ctrl-", -- [1]
		"1", -- [2]
		"target", -- [3]
	},
}
VUHDO_HOSTILE_SPELL_ASSIGNMENTS = {
	["1"] = {
		"", -- [1]
		"1", -- [2]
		"target", -- [3]
	},
	["3"] = {
		"", -- [1]
		"3", -- [2]
		"focus", -- [3]
	},
	["2"] = {
		"", -- [1]
		"2", -- [2]
		"assist", -- [3]
	},
	["5"] = {
		"", -- [1]
		"5", -- [2]
		"menu", -- [3]
	},
	["4"] = {
		"", -- [1]
		"4", -- [2]
		"menu", -- [3]
	},
}
VUHDO_MM_SETTINGS = {
	["enabled"] = 1,
	["drag"] = "CIRCLE",
	["minimapPos"] = 162.133053422197,
	["position"] = 0,
}
VUHDO_PLAYER_TARGETS = {
}
VUHDO_MAINTANK_NAMES = {
}
VUHDO_BUFF_SETTINGS = {
	["能量灌注"] = {
		["missingColor"] = {
			["TG"] = 1,
			["R"] = 1,
			["TB"] = 1,
			["G"] = 1,
			["show"] = false,
			["useOpacity"] = true,
			["TO"] = 1,
			["useBackground"] = true,
			["useText"] = true,
			["TR"] = 1,
			["O"] = 1,
			["B"] = 1,
		},
		["enabled"] = false,
		["name"] = "Amaranth",
		["filter"] = {
			[999] = true,
		},
	},
	["CONFIG"] = {
		["SWATCH_EMPTY_GROUP"] = {
			["TG"] = 0.8,
			["R"] = 0,
			["TB"] = 0.8,
			["G"] = 0,
			["TR"] = 0.8,
			["TO"] = 0.6,
			["B"] = 0,
			["useBackground"] = true,
			["useText"] = true,
			["O"] = 0.5,
			["useOpacity"] = true,
		},
		["SWATCH_COLOR_BUFF_OUT"] = {
			["TG"] = 0,
			["R"] = 0,
			["TB"] = 0,
			["G"] = 0,
			["TR"] = 0.8,
			["TO"] = 1,
			["B"] = 0,
			["useBackground"] = true,
			["useText"] = true,
			["O"] = 1,
			["useOpacity"] = true,
		},
		["WHEEL_SMART_BUFF"] = true,
		["SHOW_LABEL"] = false,
		["REFRESH_SECS"] = 1.3,
		["SWATCH_COLOR_BUFF_COOLDOWN"] = {
			["TG"] = 0.6,
			["R"] = 0.3,
			["TB"] = 0.6,
			["G"] = 0.3,
			["TR"] = 0.6,
			["TO"] = 1,
			["B"] = 0.3,
			["useBackground"] = true,
			["useText"] = true,
			["O"] = 1,
			["useOpacity"] = true,
		},
		["SWATCH_COLOR_BUFF_OKAY"] = {
			["TG"] = 0.8,
			["R"] = 0,
			["TB"] = 0,
			["G"] = 0,
			["TR"] = 0,
			["TO"] = 1,
			["B"] = 0,
			["useBackground"] = true,
			["useText"] = true,
			["O"] = 1,
			["useOpacity"] = true,
		},
		["SHOW"] = true,
		["PANEL_BG_COLOR"] = {
			["useBackground"] = true,
			["B"] = 0,
			["R"] = 0,
			["G"] = 0,
			["O"] = 0.5,
			["useText"] = false,
			["useOpacity"] = false,
		},
		["SWATCH_COLOR_BUFF_LOW"] = {
			["TG"] = 0.7,
			["R"] = 0,
			["TB"] = 0,
			["G"] = 0,
			["TR"] = 1,
			["TO"] = 1,
			["B"] = 0,
			["useBackground"] = true,
			["useText"] = true,
			["O"] = 1,
			["useOpacity"] = true,
		},
		["VERSION"] = 4,
		["SCALE"] = 1,
		["BAR_COLORS_TEXT"] = true,
		["SWATCH_COLOR_OUT_RANGE"] = {
			["TG"] = 0,
			["R"] = 0,
			["TB"] = 0,
			["G"] = 0,
			["TR"] = 0,
			["TO"] = 0.5,
			["B"] = 0,
			["useBackground"] = true,
			["useText"] = true,
			["O"] = 0.5,
			["useOpacity"] = true,
		},
		["BAR_COLORS_FLAG"] = 1,
		["HIGHLIGHT_COOLDOWN"] = true,
		["HIDE_CHARGES"] = false,
		["BAR_COLORS_IN_FIGHT"] = false,
		["PANEL_MAX_BUFFS"] = 5,
		["SWATCH_MAX_ROWS"] = 2,
		["PANEL_BORDER_COLOR"] = {
			["useBackground"] = true,
			["B"] = 0,
			["R"] = 0,
			["G"] = 0,
			["O"] = 0.5,
			["useText"] = false,
			["useOpacity"] = false,
		},
		["BAR_COLORS_BACKGROUND"] = true,
		["AT_LEAST_MISSING"] = 2,
		["SWATCH_BG_COLOR"] = {
			["useBackground"] = true,
			["B"] = 0,
			["R"] = 0,
			["G"] = 0,
			["O"] = 1,
			["useText"] = false,
			["useOpacity"] = false,
		},
		["SWATCH_BORDER_COLOR"] = {
			["useBackground"] = true,
			["B"] = 0.8,
			["R"] = 0.8,
			["G"] = 0.8,
			["O"] = 0,
			["useText"] = false,
			["useOpacity"] = false,
		},
		["POSITION"] = {
			["y"] = 1.605,
			["x"] = -189.1852,
			["point"] = "LEFT",
			["relativePoint"] = "LEFT",
		},
		["REBUFF_MIN_MINUTES"] = 10,
		["REBUFF_AT_PERCENT"] = 25,
		["GROUP_SPELL_VERSION"] = "smart",
		["SHOW_EMPTY"] = false,
	},
	["暗影防护"] = {
		["missingColor"] = {
			["TG"] = 1,
			["R"] = 1,
			["TB"] = 1,
			["G"] = 1,
			["show"] = false,
			["useOpacity"] = true,
			["TO"] = 1,
			["useBackground"] = true,
			["useText"] = true,
			["TR"] = 1,
			["O"] = 1,
			["B"] = 1,
		},
		["buff"] = "暗影防护祷言",
		["filter"] = {
			[999] = true,
		},
	},
	["心灵之火"] = {
		["enabled"] = false,
		["buff"] = "心灵之火",
		["missingColor"] = {
			["TG"] = 1,
			["R"] = 1,
			["TB"] = 1,
			["G"] = 1,
			["show"] = false,
			["useOpacity"] = true,
			["TO"] = 1,
			["useBackground"] = true,
			["useText"] = true,
			["TR"] = 1,
			["O"] = 1,
			["B"] = 1,
		},
		["filter"] = {
			[999] = true,
		},
	},
	["暗影恶魔"] = {
		["missingColor"] = {
			["TG"] = 1,
			["R"] = 1,
			["TB"] = 1,
			["G"] = 1,
			["show"] = false,
			["useOpacity"] = true,
			["TO"] = 1,
			["useBackground"] = true,
			["useText"] = true,
			["TR"] = 1,
			["O"] = 1,
			["B"] = 1,
		},
		["buff"] = "暗影恶魔",
		["filter"] = {
			[999] = true,
		},
	},
	["神圣之灵"] = {
		["missingColor"] = {
			["TG"] = 1,
			["R"] = 1,
			["TB"] = 1,
			["G"] = 0.0627,
			["show"] = false,
			["useOpacity"] = true,
			["TO"] = 1,
			["useBackground"] = true,
			["useText"] = true,
			["TR"] = 1,
			["O"] = 1,
			["B"] = 0.0431,
		},
		["filter"] = {
			[999] = true,
		},
		["enabled"] = false,
		["buff"] = "精神祷言",
	},
	["防护恐惧结界"] = {
		["missingColor"] = {
			["TG"] = 1,
			["R"] = 1,
			["TB"] = 1,
			["G"] = 1,
			["show"] = false,
			["useOpacity"] = true,
			["TO"] = 1,
			["useBackground"] = true,
			["useText"] = true,
			["TR"] = 1,
			["O"] = 1,
			["B"] = 1,
		},
		["enabled"] = false,
		["name"] = "Amaranth",
		["filter"] = {
			[999] = true,
		},
	},
	["漂浮术"] = {
		["missingColor"] = {
			["TG"] = 1,
			["R"] = 1,
			["TB"] = 1,
			["G"] = 1,
			["show"] = false,
			["useOpacity"] = true,
			["TO"] = 1,
			["useBackground"] = true,
			["useText"] = true,
			["TR"] = 1,
			["O"] = 1,
			["B"] = 1,
		},
		["enabled"] = false,
		["filter"] = {
			[999] = true,
		},
	},
	["VERSION"] = 2,
	["吸血鬼的拥抱"] = {
		["missingColor"] = {
			["TG"] = 1,
			["R"] = 1,
			["TB"] = 1,
			["G"] = 1,
			["show"] = false,
			["useOpacity"] = true,
			["TO"] = 1,
			["useBackground"] = true,
			["useText"] = true,
			["TR"] = 1,
			["O"] = 1,
			["B"] = 1,
		},
		["enabled"] = false,
		["filter"] = {
			[999] = true,
		},
	},
	["真言术：韧"] = {
		["enabled"] = true,
		["buff"] = "真言术：韧",
		["missingColor"] = {
			["TG"] = 1,
			["R"] = 1,
			["TB"] = 1,
			["G"] = 0.0863,
			["show"] = true,
			["useOpacity"] = true,
			["TO"] = 1,
			["useBackground"] = true,
			["useText"] = true,
			["TR"] = 1,
			["O"] = 1,
			["B"] = 0.0667,
		},
		["filter"] = {
			[999] = true,
		},
	},
	["防护暗影"] = {
		["missingColor"] = {
			["TG"] = 1,
			["R"] = 1,
			["TB"] = 1,
			["G"] = 1,
			["show"] = false,
			["useOpacity"] = true,
			["TO"] = 1,
			["useBackground"] = true,
			["useText"] = true,
			["TR"] = 1,
			["O"] = 1,
			["B"] = 1,
		},
		["enabled"] = false,
		["filter"] = {
			[999] = true,
		},
	},
	["精神"] = {
		["missingColor"] = {
			["TG"] = 1,
			["R"] = 1,
			["TB"] = 1,
			["G"] = 1,
			["show"] = false,
			["useOpacity"] = true,
			["TO"] = 1,
			["useBackground"] = true,
			["useText"] = true,
			["TR"] = 1,
			["O"] = 1,
			["B"] = 1,
		},
		["buff"] = "精神祷言",
		["filter"] = {
			[999] = true,
		},
	},
}
VUHDO_POWER_TYPE_COLORS = {
	{
		["useOpacity"] = true,
		["B"] = 0,
		["useBackground"] = true,
		["R"] = 1,
		["G"] = 0,
		["O"] = 1,
	}, -- [1]
	{
		["TG"] = 0.5,
		["B"] = 0.25,
		["TB"] = 0.25,
		["G"] = 0.5,
		["useOpacity"] = true,
		["useBackground"] = true,
		["O"] = 1,
		["R"] = 1,
	}, -- [2]
	{
		["useOpacity"] = true,
		["B"] = 0,
		["useBackground"] = true,
		["R"] = 1,
		["G"] = 1,
		["O"] = 1,
	}, -- [3]
	{
		["useBackground"] = true,
		["R"] = 0,
		["useOpacity"] = true,
		["O"] = 1,
		["G"] = 1,
		["B"] = 1,
	}, -- [4]
	nil, -- [5]
	{
		["TG"] = 0.5,
		["B"] = 0.5,
		["TB"] = 0.5,
		["G"] = 0.5,
		["useOpacity"] = true,
		["TR"] = 0.5,
		["useBackground"] = true,
		["O"] = 1,
		["R"] = 0.5,
	}, -- [6]
	nil, -- [7]
	{
		["TG"] = 0.95,
		["R"] = 0.87,
		["TB"] = 1,
		["G"] = 0.95,
		["TR"] = 0.87,
		["TO"] = 1,
		["B"] = 1,
		["useText"] = true,
		["useBackground"] = true,
		["O"] = 1,
		["useOpacity"] = true,
	}, -- [8]
	[0] = {
		["useOpacity"] = true,
		["B"] = 1,
		["useBackground"] = true,
		["R"] = 0,
		["G"] = 0,
		["O"] = 1,
	},
	[17] = {
		["TG"] = 0.09,
		["R"] = 0.54,
		["TB"] = 0.69,
		["G"] = 0.09,
		["TR"] = 0.54,
		["TO"] = 1,
		["B"] = 0.69,
		["useText"] = true,
		["useBackground"] = true,
		["O"] = 1,
		["useOpacity"] = true,
	},
	[18] = {
		["TG"] = 0.09,
		["R"] = 0.54,
		["TB"] = 0.69,
		["G"] = 0.09,
		["TR"] = 0.54,
		["TO"] = 1,
		["B"] = 0.69,
		["useText"] = true,
		["useBackground"] = true,
		["O"] = 1,
		["useOpacity"] = true,
	},
	[14] = {
		["TG"] = 1,
		["R"] = 0,
		["TB"] = 1,
		["G"] = 1,
		["TR"] = 0,
		["TO"] = 1,
		["B"] = 1,
		["useText"] = true,
		["useBackground"] = true,
		["O"] = 1,
		["useOpacity"] = true,
	},
	[11] = {
		["TG"] = 0.56,
		["R"] = 0.09,
		["TB"] = 1,
		["G"] = 0.56,
		["TR"] = 0.09,
		["TO"] = 1,
		["B"] = 1,
		["useText"] = true,
		["useBackground"] = true,
		["O"] = 1,
		["useOpacity"] = true,
	},
	[13] = {
		["TG"] = 0.97,
		["R"] = 0.15,
		["TB"] = 1,
		["G"] = 0.97,
		["TR"] = 0.15,
		["TO"] = 1,
		["B"] = 1,
		["useText"] = true,
		["useBackground"] = true,
		["O"] = 1,
		["useOpacity"] = true,
	},
}
VUHDO_SPELLS_KEYBOARD = {
	["SPELL15"] = "",
	["SPELL6"] = "",
	["SPELL13"] = "",
	["HOSTILE_WHEEL"] = {
		["alt1"] = {
			"ALT-", -- [1]
			"-w3", -- [2]
			"", -- [3]
		},
		["altctrl2"] = {
			"ALT-CTRL-", -- [1]
			"-w10", -- [2]
			"", -- [3]
		},
		["ctrl2"] = {
			"CTRL-", -- [1]
			"-w6", -- [2]
			"", -- [3]
		},
		["2"] = {
			"", -- [1]
			"-w2", -- [2]
			"", -- [3]
		},
		["shift1"] = {
			"SHIFT-", -- [1]
			"-w7", -- [2]
			"", -- [3]
		},
		["shift2"] = {
			"SHIFT-", -- [1]
			"-w8", -- [2]
			"", -- [3]
		},
		["altshift1"] = {
			"ALT-SHIFT-", -- [1]
			"-w11", -- [2]
			"", -- [3]
		},
		["altctrl1"] = {
			"ALT-CTRL-", -- [1]
			"-w9", -- [2]
			"", -- [3]
		},
		["ctrl1"] = {
			"CTRL-", -- [1]
			"-w5", -- [2]
			"", -- [3]
		},
		["altctrlshift2"] = {
			"ALT-CTRL-SHIFT-", -- [1]
			"w16", -- [2]
			"", -- [3]
		},
		["altshift2"] = {
			"ALT-SHIFT-", -- [1]
			"-w12", -- [2]
			"", -- [3]
		},
		["alt2"] = {
			"ALT-", -- [1]
			"-w4", -- [2]
			"", -- [3]
		},
		["altctrlshift1"] = {
			"ALT-CTRL-SHIFT-", -- [1]
			"w15", -- [2]
			"", -- [3]
		},
		["ctrlshift1"] = {
			"CTRL-SHIFT-", -- [1]
			"-w13", -- [2]
			"", -- [3]
		},
		["1"] = {
			"", -- [1]
			"-w1", -- [2]
			"", -- [3]
		},
		["ctrlshift2"] = {
			"CTRL-SHIFT-", -- [1]
			"-w14", -- [2]
			"", -- [3]
		},
	},
	["SPELL3"] = "",
	["SPELL4"] = "",
	["SPELL2"] = "",
	["SPELL16"] = "",
	["INTERNAL"] = {
	},
	["SPELL7"] = "",
	["SPELL12"] = "",
	["SPELL5"] = "",
	["SPELL9"] = "",
	["SPELL10"] = "",
	["SPELL14"] = "",
	["WHEEL"] = {
		["alt1"] = {
			"ALT-", -- [1]
			"-w3", -- [2]
			"", -- [3]
		},
		["altctrl2"] = {
			"ALT-CTRL-", -- [1]
			"-w10", -- [2]
			"", -- [3]
		},
		["ctrl2"] = {
			"CTRL-", -- [1]
			"-w6", -- [2]
			"", -- [3]
		},
		["2"] = {
			"", -- [1]
			"-w2", -- [2]
			"驱散魔法", -- [3]
		},
		["shift1"] = {
			"SHIFT-", -- [1]
			"-w7", -- [2]
			"", -- [3]
		},
		["shift2"] = {
			"SHIFT-", -- [1]
			"-w8", -- [2]
			"", -- [3]
		},
		["altshift1"] = {
			"ALT-SHIFT-", -- [1]
			"-w11", -- [2]
			"", -- [3]
		},
		["altctrl1"] = {
			"ALT-CTRL-", -- [1]
			"-w9", -- [2]
			"", -- [3]
		},
		["ctrl1"] = {
			"CTRL-", -- [1]
			"-w5", -- [2]
			"", -- [3]
		},
		["altctrlshift2"] = {
			"ALT-CTRL-SHIFT-", -- [1]
			"w16", -- [2]
			"", -- [3]
		},
		["altshift2"] = {
			"ALT-SHIFT-", -- [1]
			"-w12", -- [2]
			"", -- [3]
		},
		["alt2"] = {
			"ALT-", -- [1]
			"-w4", -- [2]
			"", -- [3]
		},
		["altctrlshift1"] = {
			"ALT-CTRL-SHIFT-", -- [1]
			"w15", -- [2]
			"", -- [3]
		},
		["ctrlshift1"] = {
			"CTRL-SHIFT-", -- [1]
			"-w13", -- [2]
			"", -- [3]
		},
		["1"] = {
			"", -- [1]
			"-w1", -- [2]
			"恢复(等级 5", -- [3]
		},
		["ctrlshift2"] = {
			"CTRL-SHIFT-", -- [1]
			"-w14", -- [2]
			"", -- [3]
		},
	},
	["SPELL8"] = "",
	["SPELL1"] = "",
	["SPELL11"] = "",
}
VUHDO_SPELL_CONFIG = {
	["IS_LOAD_HOTS"] = false,
	["smartCastModi"] = "all",
	["IS_CANCEL_CURRENT"] = true,
	["IS_AUTO_FIRE"] = true,
	["IS_FIRE_CUSTOM_2"] = false,
	["IS_FIRE_TRINKET_2"] = true,
	["IS_FIRE_HOT"] = false,
	["IS_AUTO_TARGET"] = true,
	["IS_FIRE_OUT_FIGHT"] = false,
	["FIRE_CUSTOM_1_SPELL"] = "",
	["FIRE_CUSTOM_2_SPELL"] = "",
	["IS_KEEP_STANCE"] = false,
	["IS_FIRE_CUSTOM_1"] = false,
	["IS_TOOLTIP_INFO"] = 1,
}
VUHDO_BUFF_ORDER = {
	["心灵之火"] = 2,
	["防护恐惧结界"] = 4,
	["神圣之灵"] = 1,
	["真言术：韧"] = 3,
	["吸血鬼的拥抱"] = 6,
	["漂浮术"] = 5,
	["防护暗影"] = 7,
	["能量灌注"] = 8,
}
VUHDO_SPEC_LAYOUTS = {
	["1"] = "",
	["selected"] = "",
	["2"] = "",
}
VUHDO_GROUP_SIZE = 5
VUHDO_RAID = {
	["partypet4"] = {
		["zone"] = "斯坦索姆",
		["baseRange"] = false,
		["class"] = "WARRIOR",
		["sortMaxHp"] = 3233,
		["map"] = "铁炉堡",
		["threat"] = 0,
		["powermax"] = 0,
		["threatPerc"] = 0,
		["isPet"] = true,
		["name"] = "面对疾风吧",
		["number"] = 4,
		["targetUnit"] = "partypet4target",
		["group"] = 0,
		["classId"] = 40,
		["range"] = false,
		["unit"] = "partypet4",
		["debuff"] = 0,
		["healthmax"] = 3233,
		["dead"] = false,
		["connected"] = true,
		["fullName"] = "面对疾风吧",
		["power"] = 0,
		["aggro"] = false,
		["visible"] = false,
		["isAltPower"] = false,
		["isVehicle"] = false,
		["health"] = 3233,
		["className"] = "面对疾风吧",
		["afk"] = false,
		["ownerUnit"] = "party4",
		["powertype"] = 0,
		["charmed"] = false,
	},
	["player"] = {
		["zone"] = "铁炉堡",
		["baseRange"] = true,
		["class"] = "PRIEST",
		["role"] = 63,
		["sortMaxHp"] = 2087,
		["map"] = "铁炉堡",
		["threat"] = 0,
		["powermax"] = 4651,
		["mibucateg"] = "真言术：韧",
		["threatPerc"] = 0,
		["missbuff"] = 3,
		["isPet"] = false,
		["name"] = "三聚氰胺",
		["visible"] = true,
		["targetUnit"] = "target",
		["group"] = 1,
		["afk"] = false,
		["range"] = true,
		["unit"] = "player",
		["debuff"] = 7,
		["healthmax"] = 2087,
		["loghealth"] = 2087,
		["dead"] = false,
		["connected"] = true,
		["fullName"] = "三聚氰胺",
		["power"] = 4651,
		["petUnit"] = "pet",
		["mibuvariants"] = {
			"真言术：韧", -- [1]
			2, -- [2]
			{
				"真言术：韧", -- [1]
				"坚韧祷言", -- [2]
			}, -- [3]
		},
		["isAltPower"] = false,
		["number"] = 1,
		["classId"] = 28,
		["isVehicle"] = false,
		["health"] = 2087,
		["className"] = "牧师",
		["powertype"] = 0,
		["raidIcon"] = 5,
		["charmed"] = false,
		["aggro"] = false,
	},
	["party1"] = {
		["zone"] = "斯坦索姆",
		["baseRange"] = false,
		["class"] = "MAGE",
		["role"] = 62,
		["sortMaxHp"] = 3500,
		["map"] = "铁炉堡",
		["threat"] = 0,
		["powermax"] = 7228,
		["mibucateg"] = "真言术：韧",
		["threatPerc"] = 0,
		["isPet"] = false,
		["name"] = "蜂花护发素",
		["visible"] = false,
		["targetUnit"] = "party1target",
		["group"] = 1,
		["afk"] = false,
		["mibuvariants"] = {
			"真言术：韧", -- [1]
			2, -- [2]
			{
				"真言术：韧", -- [1]
				"坚韧祷言", -- [2]
			}, -- [3]
		},
		["unit"] = "party1",
		["debuff"] = 0,
		["healthmax"] = 3500,
		["loghealth"] = 3081,
		["dead"] = false,
		["connected"] = true,
		["fullName"] = "蜂花护发素",
		["power"] = 7228,
		["petUnit"] = "partypet1",
		["isAltPower"] = false,
		["number"] = 1,
		["classId"] = 24,
		["isVehicle"] = false,
		["health"] = 3390,
		["className"] = "法师",
		["powertype"] = 0,
		["raidIcon"] = 1,
		["charmed"] = false,
		["aggro"] = false,
	},
	["party3"] = {
		["zone"] = "斯坦索姆",
		["baseRange"] = false,
		["class"] = "MAGE",
		["role"] = 62,
		["sortMaxHp"] = 3490,
		["map"] = "铁炉堡",
		["threat"] = 0,
		["powermax"] = 7068,
		["mibucateg"] = "真言术：韧",
		["threatPerc"] = 0,
		["isPet"] = false,
		["name"] = "红莲业火丶",
		["visible"] = false,
		["targetUnit"] = "party3target",
		["group"] = 1,
		["afk"] = false,
		["unit"] = "party3",
		["debuff"] = 0,
		["healthmax"] = 3490,
		["loghealth"] = 3490,
		["dead"] = false,
		["connected"] = true,
		["fullName"] = "红莲业火丶",
		["power"] = 7068,
		["petUnit"] = "partypet3",
		["mibuvariants"] = {
			"真言术：韧", -- [1]
			2, -- [2]
			{
				"真言术：韧", -- [1]
				"坚韧祷言", -- [2]
			}, -- [3]
		},
		["isAltPower"] = false,
		["number"] = 3,
		["classId"] = 24,
		["isVehicle"] = false,
		["health"] = 3490,
		["className"] = "法师",
		["powertype"] = 0,
		["raidIcon"] = 3,
		["charmed"] = false,
		["aggro"] = false,
	},
	["party4"] = {
		["zone"] = "斯坦索姆",
		["baseRange"] = false,
		["class"] = "HUNTER",
		["role"] = 62,
		["sortMaxHp"] = 2698,
		["map"] = "铁炉堡",
		["threat"] = 0,
		["powermax"] = 2550,
		["mibucateg"] = "真言术：韧",
		["threatPerc"] = 0,
		["isPet"] = false,
		["name"] = "此人天生会射",
		["number"] = 4,
		["isVehicle"] = false,
		["group"] = 1,
		["classId"] = 22,
		["unit"] = "party4",
		["powertype"] = 0,
		["healthmax"] = 2698,
		["loghealth"] = 2698,
		["dead"] = false,
		["charmed"] = false,
		["fullName"] = "此人天生会射",
		["power"] = 2550,
		["aggro"] = false,
		["mibuvariants"] = {
			"真言术：韧", -- [1]
			2, -- [2]
			{
				"真言术：韧", -- [1]
				"坚韧祷言", -- [2]
			}, -- [3]
		},
		["isAltPower"] = false,
		["visible"] = false,
		["targetUnit"] = "party4target",
		["health"] = 2698,
		["className"] = "猎人",
		["afk"] = true,
		["debuff"] = 0,
		["connected"] = true,
		["petUnit"] = "partypet4",
	},
	["party2"] = {
		["zone"] = "斯坦索姆",
		["baseRange"] = false,
		["class"] = "WARRIOR",
		["role"] = 61,
		["sortMaxHp"] = 3309,
		["map"] = "铁炉堡",
		["threat"] = 0,
		["powermax"] = 100,
		["mibucateg"] = "真言术：韧",
		["threatPerc"] = 0,
		["isPet"] = false,
		["name"] = "战罗刹",
		["number"] = 2,
		["isVehicle"] = false,
		["group"] = 1,
		["classId"] = 20,
		["unit"] = "party2",
		["powertype"] = 1,
		["healthmax"] = 3309,
		["loghealth"] = 3309,
		["dead"] = false,
		["charmed"] = false,
		["fullName"] = "战罗刹",
		["power"] = 0,
		["aggro"] = false,
		["mibuvariants"] = {
			"真言术：韧", -- [1]
			2, -- [2]
			{
				"真言术：韧", -- [1]
				"坚韧祷言", -- [2]
			}, -- [3]
		},
		["isAltPower"] = false,
		["visible"] = false,
		["targetUnit"] = "party2target",
		["health"] = 3309,
		["className"] = "战士",
		["afk"] = false,
		["debuff"] = 0,
		["connected"] = true,
		["petUnit"] = "partypet2",
	},
}
VUHDO_INDICATOR_CONFIG = {
	["BOUQUETS"] = {
		["THREAT_BAR"] = "仇恨: 标记",
		["MOUSEOVER_HIGHLIGHT"] = "",
		["AGGRO_BAR"] = "",
		["BACKGROUND_BAR"] = "背景: 固态",
		["INCOMING_BAR"] = "",
		["SIDE_LEFT"] = "",
		["HEALTH_BAR_PANEL"] = {
			"", -- [1]
			"", -- [2]
			"", -- [3]
			"", -- [4]
			"", -- [5]
			"", -- [6]
			"", -- [7]
			"", -- [8]
			"", -- [9]
			"", -- [10]
		},
		["SWIFTMEND_INDICATOR"] = "Role & Summon Status Icon",
		["THREAT_MARK"] = "",
		["SIDE_RIGHT"] = "",
		["MANA_BAR"] = "法力条: 只有法力值",
		["BAR_BORDER"] = "边框: 多边 + 仇恨",
		["HEALTH_BAR"] = "血量条: (自动)",
		["DAMAGE_FLASH_BAR"] = "",
		["CLUSTER_BORDER"] = "",
	},
	["CUSTOM"] = {
		["THREAT_BAR"] = {
			["invertGrowth"] = false,
			["turnAxis"] = false,
			["HEIGHT"] = 4,
			["WARN_AT"] = 85,
			["TEXTURE"] = "VuhDo - Polished Wood",
		},
		["MOUSEOVER_HIGHLIGHT"] = {
			["TEXTURE"] = "VuhDo - Aluminium",
		},
		["AGGRO_BAR"] = {
			["TEXTURE"] = "VuhDo - Polished Wood",
		},
		["BACKGROUND_BAR"] = {
			["TEXTURE"] = "VuhDo - Minimalist",
		},
		["CLUSTER_BORDER"] = {
			["WIDTH"] = 2,
			["FILE"] = "Interface\\AddOns\\VuhDo\\Images\\white_square_16_16",
		},
		["SWIFTMEND_INDICATOR"] = {
			["SCALE"] = 1,
		},
		["MANA_BAR"] = {
			["turnAxis"] = false,
			["invertGrowth"] = false,
			["TEXTURE"] = "VuhDo - Pipe, light",
		},
		["BAR_BORDER"] = {
			["FILE"] = "Interface\\AddOns\\VuhDo\\Images\\white_square_16_16",
			["ADJUST"] = 0,
			["WIDTH"] = 1,
		},
		["HOT_BARS"] = {
			["turnAxis"] = false,
			["vertical"] = false,
			["invertGrowth"] = false,
		},
		["HEALTH_BAR"] = {
			["turnAxis"] = false,
			["vertical"] = false,
			["invertGrowth"] = false,
		},
		["SIDE_RIGHT"] = {
			["turnAxis"] = false,
			["vertical"] = true,
			["invertGrowth"] = false,
			["TEXTURE"] = "VuhDo - Plain White",
		},
		["SIDE_LEFT"] = {
			["turnAxis"] = false,
			["vertical"] = true,
			["invertGrowth"] = false,
			["TEXTURE"] = "VuhDo - Plain White",
		},
	},
	["TEXT_INDICATORS"] = {
		["OVERHEAL_TEXT"] = {
			["TEXT_PROVIDER"] = {
				"OVERHEAL_KILO_PLUS_N_K", -- [1]
				"OVERHEAL_KILO_PLUS_N_K", -- [2]
				"OVERHEAL_KILO_PLUS_N_K", -- [3]
				"OVERHEAL_KILO_PLUS_N_K", -- [4]
				"OVERHEAL_KILO_PLUS_N_K", -- [5]
				"OVERHEAL_KILO_PLUS_N_K", -- [6]
				"OVERHEAL_KILO_PLUS_N_K", -- [7]
				"OVERHEAL_KILO_PLUS_N_K", -- [8]
				"OVERHEAL_KILO_PLUS_N_K", -- [9]
				"OVERHEAL_KILO_PLUS_N_K", -- [10]
			},
		},
		["SIDE_RIGHT"] = {
			["TEXT_PROVIDER"] = {
				[0] = "",
			},
			["TEXT"] = {
				["X_ADJUST"] = 4,
				["USE_MONO"] = false,
				["Y_ADJUST"] = 0,
				["ANCHOR"] = "BOTTOM",
				["USE_OUTLINE"] = true,
				["SCALE"] = 18,
				["COLOR"] = {
					["TG"] = 1,
					["R"] = 0,
					["TB"] = 1,
					["G"] = 0,
					["TR"] = 1,
					["TO"] = 1,
					["B"] = 0,
					["useText"] = true,
					["useBackground"] = true,
					["O"] = 1,
					["useOpacity"] = true,
				},
				["FONT"] = "Interface\\AddOns\\VuhDo\\Fonts\\ariblk.ttf",
				["USE_SHADOW"] = false,
			},
		},
		["SIDE_LEFT"] = {
			["TEXT_PROVIDER"] = {
				[0] = "",
			},
			["TEXT"] = {
				["X_ADJUST"] = 3,
				["USE_MONO"] = false,
				["Y_ADJUST"] = 0,
				["ANCHOR"] = "BOTTOM",
				["USE_OUTLINE"] = true,
				["SCALE"] = 18,
				["COLOR"] = {
					["TG"] = 1,
					["R"] = 0,
					["TB"] = 1,
					["G"] = 0,
					["TR"] = 1,
					["TO"] = 1,
					["B"] = 0,
					["useText"] = true,
					["useBackground"] = true,
					["O"] = 1,
					["useOpacity"] = true,
				},
				["FONT"] = "Interface\\AddOns\\VuhDo\\Fonts\\ariblk.ttf",
				["USE_SHADOW"] = false,
			},
		},
		["MANA_BAR"] = {
			["TEXT_PROVIDER"] = {
				[0] = "",
			},
			["TEXT"] = {
				["X_ADJUST"] = 7,
				["USE_MONO"] = false,
				["Y_ADJUST"] = 2,
				["ANCHOR"] = "RIGHT",
				["USE_OUTLINE"] = false,
				["SCALE"] = 20,
				["COLOR"] = {
					["TG"] = 0.55,
					["R"] = 0,
					["TB"] = 1,
					["G"] = 0,
					["TR"] = 0.36,
					["TO"] = 1,
					["B"] = 0,
					["useText"] = true,
					["useBackground"] = true,
					["O"] = 1,
					["useOpacity"] = true,
				},
				["FONT"] = "Interface\\AddOns\\VuhDo\\Fonts\\ariblk.ttf",
				["USE_SHADOW"] = true,
			},
		},
		["THREAT_BAR"] = {
			["TEXT_PROVIDER"] = {
				[0] = "",
			},
			["TEXT"] = {
				["X_ADJUST"] = 7,
				["USE_MONO"] = false,
				["Y_ADJUST"] = 2,
				["ANCHOR"] = "RIGHT",
				["USE_OUTLINE"] = false,
				["SCALE"] = 20,
				["COLOR"] = {
					["TG"] = 0,
					["R"] = 0,
					["TB"] = 0,
					["G"] = 0,
					["TR"] = 1,
					["TO"] = 1,
					["B"] = 0,
					["useText"] = true,
					["useBackground"] = true,
					["O"] = 1,
					["useOpacity"] = true,
				},
				["FONT"] = "Interface\\AddOns\\VuhDo\\Fonts\\ariblk.ttf",
				["USE_SHADOW"] = true,
			},
		},
	},
}
