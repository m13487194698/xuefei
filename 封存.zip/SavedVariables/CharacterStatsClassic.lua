
CharacterStatsClassicCharacterDB = {
	["selectedLeftStatsCategory"] = 1,
	["selectedRightStatsCategory"] = 4,
}
