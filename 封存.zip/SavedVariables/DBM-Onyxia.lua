
DBMOnyxia_SavedStats = {
	["Onyxia"] = {
		["normalPulls"] = 17,
		["challengeKills"] = 0,
		["challengeBestRank"] = 0,
		["mythicKills"] = 0,
		["lfr25Kills"] = 0,
		["heroic25Pulls"] = 0,
		["lfr25Pulls"] = 0,
		["normal25Pulls"] = 0,
		["normalLastTime"] = 853.195,
		["normalKills"] = 14,
		["mythicPulls"] = 0,
		["heroic25Kills"] = 0,
		["heroicKills"] = 0,
		["timewalkerPulls"] = 0,
		["normal25Kills"] = 0,
		["heroicPulls"] = 0,
		["timewalkerKills"] = 0,
		["normalBestTime"] = 440.897000000001,
		["challengePulls"] = 0,
	},
}
