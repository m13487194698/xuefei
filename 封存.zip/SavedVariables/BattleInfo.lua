
BatteInfoSettings = {
	["wsp_unit_color"] = true,
	["show_number"] = true,
	["auto_leave_bg_time"] = 3,
	["show_alterac"] = true,
	["show_time_elapsed"] = true,
	["focus_quickjoin"] = false,
	["replace_enter_battle"] = true,
	["replace_hide_battle"] = true,
	["show_spirit_heal"] = true,
	["map_unit_color"] = true,
	["flash_icon"] = true,
	["stat_window"] = true,
}
BatteInfoStat = {
	{
		["start"] = 1582965704,
	}, -- [1]
	{
		["start"] = 1582965704,
	}, -- [2]
	{
		["start"] = 1582965704,
	}, -- [3]
}
